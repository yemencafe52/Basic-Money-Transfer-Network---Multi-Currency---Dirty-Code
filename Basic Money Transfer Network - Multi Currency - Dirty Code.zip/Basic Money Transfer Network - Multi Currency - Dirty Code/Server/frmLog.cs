﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YMT
{
    public partial class frmLog : Form
    {
        public frmLog()
        {
            InitializeComponent();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == (Keys.Shift | Keys.Escape))
            {
                {
                    this.Close();
                }
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void frmLog_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            while ((LogManager.log_info.Count > 0) && (إيقافالتحديثالتلقائيللسجلToolStripMenuItem.Checked == false))
            {
                ListViewItem lvi = new ListViewItem(LogManager.log_info[0].MSG.MSG);
                lvi.SubItems.Add(LogManager.log_info[0].IP.ToString());
                lvi.SubItems.Add(LogManager.log_info[0].Branch.BranchNumber.ToString());
                lvi.SubItems.Add(LogManager.log_info[0].StationInfo.Number.ToString());
               lvi.SubItems.Add(LogManager.log_info[0].UserInfo.Number.ToString());
                lvi.SubItems.Add(LogManager.log_info[0].Time.ToString());
                lvi.SubItems.Add(LogManager.log_info[0].Note.ToString());

                if (LogManager.log_info[0].MSG.Type == MSGTYPE.Info)
                {
                    lvi.ForeColor = Color.Black;
                }
                else if (LogManager.log_info[0].MSG.Type == MSGTYPE.Warning)
                {
                    lvi.ForeColor = Color.Orange;
                }
                else if (LogManager.log_info[0].MSG.Type == MSGTYPE.Error)
                {
                    lvi.ForeColor = Color.Red;
                }
              

                LogManager.log_info.RemoveAt(0);
                listView1.Items.Add(lvi);

                //if (إيقافالتحديثالتلقائيللسجلToolStripMenuItem.Checked == false)
                //{
                    listView1.EnsureVisible(listView1.Items.Count - 1);
                //}
                
            }

            while (SystemLogManager.log_info.Count > 0)
            {
                ListViewItem lvi = new ListViewItem(SystemLogManager.log_info[0].Message.MSG);
                lvi.SubItems.Add(SystemLogManager.log_info[0].Time.ToString());
                //lvi.SubItems.Add(SystemLogManager.log_info[0].Note.ToString());

                if (SystemLogManager.log_info[0].Message.Type == MSGTYPE.Info)
                {
                    lvi.ForeColor = Color.Black;
                }
                else if (SystemLogManager.log_info[0].Message.Type == MSGTYPE.Warning)
                {
                    lvi.ForeColor = Color.Orange;
                }
                else if (SystemLogManager.log_info[0].Message.Type == MSGTYPE.Error)
                {
                    lvi.ForeColor = Color.Red;
                }

                listView2.Items.Add(lvi);

                listView2.EnsureVisible(listView2.Items.Count - 1);

                SystemLogManager.log_info.RemoveAt(0);

            }
            
        }

        private void إيقافالتحديثالتلقائيللسجلToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (إيقافالتحديثالتلقائيللسجلToolStripMenuItem.Checked)
            {
                إيقافالتحديثالتلقائيللسجلToolStripMenuItem.Checked = false;
            }
            else
            {
                إيقافالتحديثالتلقائيللسجلToolStripMenuItem.Checked = true;
            }
        }

        private void frmLog_FormClosing(object sender, FormClosingEventArgs e)
        {
            Utilities.fl = null;
        }

        private void مسحالسجلToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
        }
    }
}
