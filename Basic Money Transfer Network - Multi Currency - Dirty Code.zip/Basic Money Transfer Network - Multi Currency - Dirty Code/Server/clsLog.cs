﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace YMT
{
    public static class SystemLogManager
    {
        private static object mylocker = new object();

        public static List<SystemLog> log_info = new List<SystemLog>();

        public static bool CreateNewSystemEvent(SystemLog log)
        {
            lock (mylocker)
            {
                bool res = false;

                try
                {  
                    log_info.Add(log);
                    File.AppendAllText(Application.StartupPath + "\\sys.log", "[" + log.Time + "]" + ":" + log.Message.MSG + " >> " + log.Note + "\r\n", Encoding.UTF8);
                    res = true;
                }
                catch
                {
                    res = false;
                }

                return res;
            }

        }
    }

    public class SystemLog
    {
        private MSGINFO msg;
        private DateTime time;
        private string note;

        public SystemLog(MSGINFO msg,DateTime time,string note= "")
        {
            this.msg = msg;
            this.time = time;
            this.note = note;
        }


        public MSGINFO Message
        {
            get
            {
                return this.msg;
            }
        }

        public DateTime Time
        {
            get
            {
                return this.time;
            }
        }

        public string Note
        {
            get
            {
                return this.note;
            }
        }
    }

    public enum MSGTYPE
    {
        Info = 0, 
        Warning ,
        Error
    }

    public class MSGINFO
    {
        private byte msg_id;
        private string msg;
        private MSGTYPE type;

        public MSGINFO(byte id,string msg,MSGTYPE type = MSGTYPE.Info)
        {
            this.msg_id = id;
            this.msg = msg;
            this.type = type;
        }

        public MSGINFO(byte id)
        {
            List<MSGINFO> msgs = LogManager.MSGS;
            MSGINFO msg = msgs.Find(p => p.msg_id == id);
            this.msg_id = id;
            this.msg = msg.msg;
            this.type = msg.type;
        }

        public MSGTYPE Type
        {
            get
            {
                return this.type;
            }
        }

        public byte MSGID
        {
            get
            {
                return this.msg_id;
            }
        }

        public string MSG
        {
            get
            {
                return this.msg;
            }
        }

    }
    public class Log
    {
        private uint id;
        private MSGINFO msg;
        private string ip;
        private BranchInfo branch;
        private Station station;
        private User user;
        private DateTime time;
        private string note;

        public Log(MSGINFO msg,string ip,BranchInfo branch,Station station, User user, DateTime time,string note = "",uint id=0)
        {
            this.msg = msg;
            this.ip = ip;
            this.station = station;
            this.branch = branch;
            this.user = user;
            this.time = time;
            this.id = id;
            this.note = note;
        }

        public uint ID
        {
            get
            {
                return id;
            }
        }

        public MSGINFO MSG
        {
            get
            {
                return msg;
            }
        }

        public BranchInfo Branch
        {
            get
            {
                return branch;
            }
        }

        public User UserInfo
        {
            get
            {
                return user;
            }
        }

        public DateTime Time
        {
            get
            {
                return time;
            }
        }


        public Station StationInfo
        {
            get
            {
                return this.station;
            }
        }

        public string IP
        {
            get
            {
                return this.ip;
            }
        }


        public string Note
        {
            get
            {
                return this.note;
            }
        }


    }

    public static class LogManager
    {
        private static List<MSGINFO> msgs = GetALLMSG();

        public static List<Log> log_info = new List<Log>();

        public static List<MSGINFO> MSGS
        {
            get
            {
                return msgs;
            }
        }

        public static bool CreateNewEvent(Log log)
        {   
            lock (Utilities.mylocker)
            {
                bool res = false;

                try
                {
                    log_info.Add(log);
                    ADataBase db = new ADataBase();
                    string sql = @"insert into tblLOG (msg_id,branch_no,station_no,user_no,log_time,log_note,log_ip) values(" + log.MSG.MSGID + "," + log.Branch.BranchNumber + ", " + log.StationInfo.Number + "," + log.UserInfo.Number + ",'" + log.Time + "','" + log.Note + "','" +log.IP + "')";

                    if (db.ExcuteSQLNonQuery(sql) == 1)
                    {   
                        res = true;
                    }
                    else
                    {
                        throw new Exception("");
                    }

                }
                catch (Exception ex)
                {
                    
                }

                

                return res;
            }

        }


        public static List<MSGINFO> GetALLMSG()
        {
            List<MSGINFO> msgs = new List<MSGINFO>();
            msgs.Add(new MSGINFO(1,"تم ارسال الحوالة",MSGTYPE.Info));
            msgs.Add(new MSGINFO(2, "تعذر إرسال الحوالة", MSGTYPE.Error));
            msgs.Add(new MSGINFO(3, "استعلام عن حوالة", MSGTYPE.Info));
            msgs.Add(new MSGINFO(4, "تعذر العثور على الحوالة", MSGTYPE.Warning));
            msgs.Add(new MSGINFO(5, "تم استلام الحوالة", MSGTYPE.Info));
            msgs.Add(new MSGINFO(6, "تعذر استلام الحوالة", MSGTYPE.Error));

            return msgs;
        }
    }

}

