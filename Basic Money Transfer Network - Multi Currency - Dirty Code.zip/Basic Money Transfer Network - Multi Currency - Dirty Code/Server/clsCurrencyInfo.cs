﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace YMT
{
    public class CurrencyInfo
    {
        private byte cur_no;
        private string cur_name;
        private string cur_bit_name;
        private decimal cur_exchange;
        private string cur_symbol;
        private Exception exception_info = null;

        public byte CurrencyNumber
        {
            get
            {
                return this.cur_no;
            }
        }

        public decimal CurrencyExchange
        {
            get
            {
                return Math.Round( this.cur_exchange,4);
            }
            set
            {
                this.cur_exchange = Math.Round(value, 4); ;
            }
        }

        public string CurrencySymbol
        {
            get
            {
                return this.cur_symbol;
            }
            set
            {
                this.cur_symbol = value;
            }
        }

        public string CurrencyName
        {
            get
            {
                return this.cur_name;
            }
            set
            {
                this.cur_name = value;
            }
        }

        public string CurrencyBitName
        {
            get
            {
                return this.cur_bit_name;
            }
            set
            {
                this.cur_bit_name = value;
            }
        }

        public Exception ExceptionInfo
        {
            get { return this.exception_info; }
            set
            {
                this.exception_info = value;
            }
        }

        public CurrencyInfo()
        {
            this.cur_no = (byte)CurrencyManager.GenerateNewCurrencyID();
        }

        public CurrencyInfo(byte cur_no, string cur_name, string cur_bit_name, decimal cur_exchange, string cur_symbol)
        {
            this.cur_no = cur_no;
            this.cur_name = cur_name;
            this.cur_symbol = cur_symbol;
            this.cur_exchange = cur_exchange;
            this.cur_bit_name = cur_bit_name;
        }

        public CurrencyInfo(byte[] ar)
        {
            try
            {
                int index = 0;
                byte[] art = new byte[1];
                Array.Copy(ar, 0, art, 0, 1);
                index += 1;

                this.cur_no = art[0];


                int l = BitConverter.ToInt32(ar, 1);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.cur_name = Encoding.UTF8.GetString(art);


                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.cur_symbol = Encoding.UTF8.GetString(art);

                this.cur_exchange = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.cur_bit_name = Encoding.UTF8.GetString(art);

                l = BitConverter.ToInt32(ar, index);
                index += 4;

                if (l == 0)
                {
                    this.exception_info = null;
                }
                else
                {
                    art = new byte[l];
                    Array.Copy(ar, index, art, 0, l);
                    index += l;
                    this.exception_info = DeserializeX(art);
                }
            }
            catch(Exception ex)
            {
                this.cur_no = 0;
                this.cur_name = "";
                this.cur_exchange = 0;
                this.cur_bit_name = "";
                this.cur_symbol = "";
                this.exception_info = new Exception("");
            }

        }


        public byte[] ToBytes()
        {
            
            List<byte> ar = new List<byte>();

            ar.Add(this.cur_no);

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.cur_name).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.cur_name));

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.cur_symbol).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.cur_symbol));

            ar.AddRange(BitConverter.GetBytes((double)(this.cur_exchange)));

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.cur_bit_name).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.cur_bit_name));

            if(this.exception_info == null)
            {
                int x = 0;
                ar.AddRange(BitConverter.GetBytes(x));
            }
            else
            {
                byte[] e = SerializeX(this.exception_info);
                ar.AddRange(BitConverter.GetBytes(e.Length));
                ar.AddRange(e);
            }
            return ar.ToArray();
        }


        private Exception DeserializeX(byte[] ar)
        {

            Stream stream = new MemoryStream(ar);
            BinaryFormatter formatter = new BinaryFormatter();
            Exception ex = (Exception)formatter.Deserialize(stream);
            stream.Close();

            return ex;
        }
        private static byte[] SerializeX<T>(T obj)
        {
            using (MemoryStream memStream = new MemoryStream())
            {
                BinaryFormatter binSerializer = new BinaryFormatter();
                binSerializer.Serialize(memStream, obj);
                return memStream.ToArray();
            }
        }

        public CurrencyInfo(byte cur_no)
        {
            lock (Utilities.mylocker)
            {

                ADataBase ADB = new ADataBase();

                try
                {
                    string sql = "select cur_bit_name, cur_no,cur_name,cur_exchange,cur_symbol from tblCurrency where cur_no=" + cur_no;
                    if (ADB.ExcuteSQLQuery(sql))
                    {
                        if (ADB.GetDataReader.Read())
                        {
                            this.cur_no = Convert.ToByte(ADB.GetDataReader["cur_no"]);
                            this.cur_name = Convert.ToString(ADB.GetDataReader["cur_name"]);
                            this.cur_bit_name = Convert.ToString(ADB.GetDataReader["cur_bit_name"]);
                            this.cur_symbol = Convert.ToString(ADB.GetDataReader["cur_symbol"]);
                            this.cur_exchange = Convert.ToDecimal(ADB.GetDataReader["cur_exchange"]);
                        }
                        else
                        {
                            if (ADB.ExceptionInfo != null)
                            {
                                throw ADB.ExceptionInfo;
                            }
                            else
                            {
                                throw new Exception("");
                            }
                        }
                    }
                    else
                    {
                        if (ADB.ExceptionInfo != null)
                        {
                            throw  ADB.ExceptionInfo;
                        }
                        else
                        {
                             throw new Exception("");
                        }
                    }
                    ADB.CloseConnection();
                }

                catch (Exception ex)
                {
                    ADB.CloseConnection();
                    this.exception_info = ex;
                    SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تعذر قراءة بيانات العملة.", MSGTYPE.Info), DateTime.Now, cur_no.ToString()));
                }
            }
        }
    }

    static class CurrencyManager
    {
        private static CurrencyInfo defualt_currency = new CurrencyInfo(1);
        public static CurrencyInfo DefualtCurrency
        {
            get
            {
               return defualt_currency;
            }

        }
        public static bool CreateNewCurrency(CurrencyInfo currency)
        {

            lock (Utilities.mylocker)
            {
                bool res = false;

                try
                {
                    if (currency.CurrencyExchange == 0)
                    {
                        throw new Exception();
                    }

                    ADataBase db = new ADataBase();
                    string sql = @"insert into tblCurrency (cur_no,cur_name,cur_symbol,cur_exchange,cur_bit_name) values(" + currency.CurrencyNumber + ",'" + currency.CurrencyName + "','" + currency.CurrencySymbol + "'," + currency.CurrencyExchange + ",'" + currency.CurrencyBitName + "')";
                    if (db.ExcuteSQLNonQuery(sql) == 1)
                    {
                        res = true;
                        SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تم إنشاء عملة جديدة.", MSGTYPE.Info), DateTime.Now, "NUMBER=" + currency.CurrencyNumber + ",NAME=" + currency.CurrencyName + ",SYMBOL=" + currency.CurrencySymbol + ",BIT_NAME" + currency.CurrencyBitName + ",EXCHANGE=" + currency.CurrencyExchange));
                    }
                    else
                    {
                        throw new Exception("");
                    }

                    

                }
                catch (Exception ex)
                {
                    SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تعذر إنشاء عملة جديدة.", MSGTYPE.Error), DateTime.Now, "NUMBER=" + currency.CurrencyNumber + ",NAME=" + currency.CurrencyName + ",SYMBOL=" + currency.CurrencySymbol + ",BIT_NAME" + currency.CurrencyBitName + ",EXCHANGE=" + currency.CurrencyExchange));
                    currency.ExceptionInfo = ex;
                }

                return res;
            }
        }

        public static bool UpdateCurrency(CurrencyInfo currency)
        {

            lock (Utilities.mylocker)
            {
                bool res = false;

                try
                {
                    ADataBase db = new ADataBase();
                    string sql = @"update tblCurrency set cur_exchange=" + currency.CurrencyExchange + ",cur_name='" + currency.CurrencyName + "',cur_bit_name='" + currency.CurrencyBitName + "',cur_symbol='" + currency.CurrencySymbol + "' where cur_no=" + currency.CurrencyNumber;
                    if (db.ExcuteSQLNonQuery(sql) == 1)
                    {

                        res = true;
                        SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تم تعديل العملة .", MSGTYPE.Info), DateTime.Now, "NUMBER=" + currency.CurrencyNumber + ",NAME=" + currency.CurrencyName + ",SYMBOL=" + currency.CurrencySymbol + ",BIT_NAME" + currency.CurrencyBitName + ",EXCHANGE=" + currency.CurrencyExchange));
                    }
                    else
                    {
                        throw new Exception("");
                    }

                   

                }
                catch (Exception ex)
                {
                    SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تعذر تعديل العملة .", MSGTYPE.Error), DateTime.Now, "NUMBER=" + currency.CurrencyNumber + ",NAME=" + currency.CurrencyName + ",SYMBOL=" + currency.CurrencySymbol + ",BIT_NAME" + currency.CurrencyBitName + ",EXCHANGE=" + currency.CurrencyExchange));
                    currency.ExceptionInfo = ex;
                }

                return res;
            }

        }





        internal static int GenerateNewCurrencyID()
        {
            lock (Utilities.mylocker)
            {
                int res = 1;
                try
                {
                    ADataBase ADB = new ADataBase();

                    string sql = "select (max(cur_no)+1) as res from tblCurrency";
                    if (ADB.ExcuteSQLQuery(sql))
                    {
                        if (ADB.GetDataReader.Read())
                        {
                            res = Convert.ToInt32(ADB.GetDataReader["res"].ToString());
                        }
                    }
                    ADB.CloseConnection();
                }
                catch
                {
                    res = -1;
                }

                return res;
            }
        }



        public static bool DeleteCurrency(CurrencyInfo currency)
        {

            lock (Utilities.mylocker)
            {

                bool res = false;

                try
                {

                    if (!(CanDeleteCurrency(currency)))
                    {
                        throw new Exception("");
                    }

                    ADataBase db = new ADataBase();
                    string sql = @"delete from tblCurrency where cur_no=" + currency.CurrencyNumber;
                    if (db.ExcuteSQLNonQuery(sql) == 1)
                    {
                        SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تم حذف العملة .", MSGTYPE.Info), DateTime.Now, "NUMBER=" + currency.CurrencyNumber + ",NAME=" + currency.CurrencyName + ",SYMBOL=" + currency.CurrencySymbol + ",BIT_NAME" + currency.CurrencyBitName + ",EXCHANGE=" + currency.CurrencyExchange));
                        res = true;
                    }
                    else
                    {
                        SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, " تعذر حذف العملة .", MSGTYPE.Error), DateTime.Now, "NUMBER=" + currency.CurrencyNumber + ",NAME=" + currency.CurrencyName + ",SYMBOL=" + currency.CurrencySymbol + ",BIT_NAME" + currency.CurrencyBitName + ",EXCHANGE=" + currency.CurrencyExchange));
                        throw new Exception("");
                    }

                }
                catch (Exception ex)
                {
                    currency.ExceptionInfo = ex;
                }

                return res;
            }

        }


        public static bool CanDeleteCurrency(CurrencyInfo currency)
        {

            lock (Utilities.mylocker)
            {
                bool res = false;

                try
                {


                    ADataBase db = new ADataBase();
                    string sql = @"select count(*) as res from tblTransctions where cur_no=" + currency.CurrencyNumber;

                    if (db.ExcuteSQLQuery(sql))
                    {
                        if (db.GetDataReader.Read())
                        {
                            if (Convert.ToInt32(db.GetDataReader["res"].ToString()) == 0)
                            {
                                res = true;
                            }

                        }

                        db.CloseConnection();
                    }
                    else
                    {
                        db.CloseConnection();
                        throw new Exception("");
                    }

                    if (res)
                    {
                        res = false;

                        sql = @"select count(*) as res from tblLedger where cur_no=" + currency.CurrencyNumber;
                        if (db.ExcuteSQLQuery(sql))
                        {
                            if (db.GetDataReader.Read())
                            {
                                if (Convert.ToInt32(db.GetDataReader["res"].ToString()) == 0)
                                {
                                    res = true;
                                }

                            }

                            db.CloseConnection();
                        }
                        else
                        {
                            db.CloseConnection();
                            throw new Exception("");
                        }
                    }

                }
                catch (Exception ex)
                {
                    currency.ExceptionInfo = ex;
                }

                return res;
            }

        }

        public static List<CurrencyInfo> GetALLCurrency()
        {

            lock (Utilities.mylocker)
            {
                List<CurrencyInfo> currencies = new List<CurrencyInfo>();
                try
                {
                    ADataBase ADB = new ADataBase();

                    string sql = "select cur_no from tblCurrency";
                    if (ADB.ExcuteSQLQuery(sql))
                    {
                        while (ADB.GetDataReader.Read())
                        {
                            currencies.Add(new CurrencyInfo(Convert.ToByte(ADB.GetDataReader["cur_no"])));
                        }
                    }
                    ADB.CloseConnection();
                }
                catch (Exception ex)
                {
                    SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تعذر قراءة بيانات العملات.", MSGTYPE.Error), DateTime.Now));
                }

                return currencies;
            }
        }
    }
}
