﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Data;


namespace YMT
{
    internal class OugGoingReports
    {
        internal DSet.OGTDataTable GetOutGoingTransction(DateTime from, DateTime to)
        {
            
            DSet.OGTDataTable ogt = new DSet.OGTDataTable();
            try
            {
                string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,  tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,   tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblCurrency.cur_no AS Expr1, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr2, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM (tblTransferOutGoing INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no)" + " where (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + from.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + to.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
                using (OleDbDataAdapter da = new OleDbDataAdapter(sql, new OleDbConnection(Utilities.connection_string)))
                {
                    da.Fill(ogt);
                    da.Dispose();
                }
            }
            catch
            {

            }

            return ogt;
        }

        internal DSet.OGTDataTable GetOutGoingTransction(DateTime from, DateTime to, User user)
        {
            DSet.OGTDataTable ogt = new DSet.OGTDataTable();
            try
            {
                string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,  tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,   tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblCurrency.cur_no AS Expr1, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr2, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM (tblTransferOutGoing INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where user_no=" + user.Number + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + from.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + to.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
                using (OleDbDataAdapter da = new OleDbDataAdapter(sql, new OleDbConnection(Utilities.connection_string)))
                {
                    da.Fill(ogt);
                    da.Dispose();
                }
            }
            catch
            {

            }

            return ogt;
        }

        internal DSet.OGTDataTable GetOutGoingTransction(DateTime from, DateTime to, BranchInfo branch, bool x)
        {
            DSet.OGTDataTable ogt = new DSet.OGTDataTable();
            try
            {
                string sql = "";

                if (x)
                {
                    sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,  tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,   tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblCurrency.cur_no AS Expr1, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr2, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM (tblTransferOutGoing INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where branch_no=" + branch.BranchNumber + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + from.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + to.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
                }
                else
                {
                    sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,  tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,   tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblCurrency.cur_no AS Expr1, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr2, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM (tblTransferOutGoing INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where to_dest_branch=" + branch.BranchNumber + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + from.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + to.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
                }

                using (OleDbDataAdapter da = new OleDbDataAdapter(sql, new OleDbConnection(Utilities.connection_string)))
                {
                    da.Fill(ogt);
                    da.Dispose();
                }
            }
            catch
            {

            }

            return ogt;
        }

        internal DSet.OGTDataTable GetOutGoingTransction(DateTime from, DateTime to, BranchInfo branch, User user, bool x)
        {
            DSet.OGTDataTable ogt = new DSet.OGTDataTable();
            try
            {

                string sql = "";

                if (x)
                {
                    sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,  tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,   tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblCurrency.cur_no AS Expr1, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr2, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM (tblTransferOutGoing INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where user_no=" + user.Number + " and branch_no=" + branch.BranchNumber + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + from.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + to.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
                }
                else
                {
                    sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,  tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,   tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblCurrency.cur_no AS Expr1, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr2, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM (tblTransferOutGoing INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where user_no=" + user.Number + " and to_dest_branch=" + branch.BranchNumber + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + from.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + to.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
                }

                using (OleDbDataAdapter da = new OleDbDataAdapter(sql, new OleDbConnection(Utilities.connection_string)))
                {
                    da.Fill(ogt);
                    da.Dispose();
                }
            }
            catch
            {

            }

            return ogt;
        }


        internal DSet.OGTDataTable GetOutGoingTransction(DateTime from, DateTime to, BranchInfo src, BranchInfo dst)
        {
            DSet.OGTDataTable ogt = new DSet.OGTDataTable();
            try
            {
                string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,  tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,   tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblCurrency.cur_no AS Expr1, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr2, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM (tblTransferOutGoing INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where to_dest_branch=" + dst.BranchNumber + " and branch_no=" + src.BranchNumber + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + from.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + to.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";

                using (OleDbDataAdapter da = new OleDbDataAdapter(sql, new OleDbConnection(Utilities.connection_string)))
                {
                    da.Fill(ogt);
                    da.Dispose();
                }
            }
            catch
            {

            }

            return ogt;
        }

        internal DSet.OGTDataTable GetOutGoingTransction(DateTime from, DateTime to, BranchInfo src, BranchInfo dst, User user)
        {
            DSet.OGTDataTable ogt = new DSet.OGTDataTable();
            try
            {
                string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,  tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,   tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblCurrency.cur_no AS Expr1, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr2, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM (tblTransferOutGoing INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where user_no=" + user.Number + " and to_dest_branch=" + dst.BranchNumber + " and branch_no=" + src.BranchNumber + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + from.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + to.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";

                using (OleDbDataAdapter da = new OleDbDataAdapter(sql, new OleDbConnection(Utilities.connection_string)))
                {
                    da.Fill(ogt);
                    da.Dispose();
                }
            }
            catch
            {

            }

            return ogt;
        }

        internal List<TransferOutGoing> GetOutGoingTransctionByDate(DateTime from, DateTime to)
        {
            lock (Utilities.mylocker)
            {
                List<TransferOutGoing> ogtl = new List<TransferOutGoing>();

                bool res = false;
                try
                {
                    ADataBase ADB = new ADataBase();

                    string sql = "select to_dest_branch,h,branch_no,ogt_v1, to_no,to_type,to_date,to_amount,to_famount,to_trans_commation,to_reciver_commation,to_sender_name,to_reciver_name,user_no,cur_no,cur_exchange,to_trans_fcommation,to_reciver_fcommation from tblTransferOutGoing where (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + from.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + to.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
                    if (ADB.ExcuteSQLQuery(sql))
                    {
                        while (ADB.GetDataReader.Read())
                        {
                            TransferOutGoing ogt = new TransferOutGoing(Convert.ToInt32(ADB.GetDataReader["to_no"]), (MoneyTransferType)Convert.ToByte(ADB.GetDataReader["to_type"]), Convert.ToDateTime(ADB.GetDataReader["to_date"]), Convert.ToDecimal(ADB.GetDataReader["to_amount"]), Convert.ToDecimal(ADB.GetDataReader["to_famount"]), Convert.ToDecimal(ADB.GetDataReader["to_trans_commation"]), Convert.ToDecimal(ADB.GetDataReader["to_reciver_commation"]), Convert.ToString(ADB.GetDataReader["to_sender_name"]), Convert.ToString(ADB.GetDataReader["to_reciver_name"]), new User(Convert.ToByte(ADB.GetDataReader["user_no"])), new CurrencyInfo(Convert.ToByte(ADB.GetDataReader["cur_no"])), Convert.ToDecimal(ADB.GetDataReader["cur_exchange"]), Convert.ToDecimal(ADB.GetDataReader["to_trans_fcommation"]), Convert.ToDecimal(ADB.GetDataReader["to_reciver_fcommation"]), new BranchInfo(Convert.ToByte(ADB.GetDataReader["branch_no"])), new BranchInfo(Convert.ToByte(ADB.GetDataReader["to_dest_branch"])), Convert.ToString(ADB.GetDataReader["h"]));
                            ogtl.Add(ogt);
                            //if (this.hash != this.GetCurrentHASH)
                            //{
                            //    this.exception_info = new Exception();
                            //}

                            //break;
                        }


                    }

                    ADB.CloseConnection();

                }
                catch
                {
                }
                return ogtl;

            }
        }


        internal List<int> GetOutGoingTransctionNumbers()
        {
            lock (Utilities.mylocker)
            {
                List<int> numbers = new List<int>();

                bool res = false;
                try
                {
                    ADataBase ADB = new ADataBase();

                    string sql = "select to_no from tblTransferOutGoing";
                    if (ADB.ExcuteSQLQuery(sql))
                    {
                        while (ADB.GetDataReader.Read())
                        {
                            int n = (Convert.ToInt32(ADB.GetDataReader["to_no"]));
                            numbers.Add(n);
                        }
                    }

                    ADB.CloseConnection();

                }
                catch
                {
                }

                return numbers;

            }
        }

    }

    internal class InComingReports
    {
        
        internal DSet.ICTDataTable GetInComingTransction(DateTime from, DateTime to)
        {
            DSet.ICTDataTable ict = new DSet.ICTDataTable();
            try
            {
                string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,   tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,  tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblTransferInComing.ti_no, tblTransferInComing.to_no AS Expr1, tblTransferInComing.user_no AS Expr2, tblTransferInComing.ti_date, tblTransferInComing.branch_no AS Expr3, tblTransferInComing.h AS Expr4, tblCurrency.cur_no AS Expr5, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr6, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM ((tblTransferOutGoing INNER JOIN tblTransferInComing ON tblTransferOutGoing.to_no = tblTransferInComing.to_no) INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no)" + " where (datevalue(format(tblTransferInComing.ti_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + from.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + to.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
                using (OleDbDataAdapter da = new OleDbDataAdapter(sql, new OleDbConnection(Utilities.connection_string)))
                {
                    da.Fill(ict);
                    da.Dispose();
                }
            }
            catch
            {

            }

            return ict;
        }

        internal DSet.ICTDataTable GetInComingTransction(DateTime from, DateTime to, User user)
        {
            DSet.ICTDataTable ict = new DSet.ICTDataTable();
            try
            {
                string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,   tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,  tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblTransferInComing.ti_no, tblTransferInComing.to_no AS Expr1, tblTransferInComing.user_no AS Expr2, tblTransferInComing.ti_date, tblTransferInComing.branch_no AS Expr3, tblTransferInComing.h AS Expr4, tblCurrency.cur_no AS Expr5, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr6, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM ((tblTransferOutGoing INNER JOIN tblTransferInComing ON tblTransferOutGoing.to_no = tblTransferInComing.to_no) INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no)" + " where (tblTransferInComing.user_no=" + user.Number + ") and (datevalue(format(tblTransferInComing.ti_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + from.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + to.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";

                using (OleDbDataAdapter da = new OleDbDataAdapter(sql, new OleDbConnection(Utilities.connection_string)))
                {
                    da.Fill(ict);
                    da.Dispose();
                }
            }
            catch
            {

            }

            return ict;
        }

        internal DSet.ICTDataTable GetInComingTransction(DateTime from, DateTime to, BranchInfo branch, bool x)
        {
            DSet.ICTDataTable ict = new DSet.ICTDataTable();
            try
            {
                string sql = "";

                if (x)
                {
                    sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,   tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,  tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblTransferInComing.ti_no, tblTransferInComing.to_no AS Expr1, tblTransferInComing.user_no AS Expr2, tblTransferInComing.ti_date, tblTransferInComing.branch_no AS Expr3, tblTransferInComing.h AS Expr4, tblCurrency.cur_no AS Expr5, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr6, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM ((tblTransferOutGoing INNER JOIN tblTransferInComing ON tblTransferOutGoing.to_no = tblTransferInComing.to_no) INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no)" + " where (tblTransferOutGoing.branch_no=" + branch.BranchNumber + ") and (datevalue(format(tblTransferInComing.ti_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + from.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + to.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";   
                }
                else
                {
                    sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,   tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,  tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblTransferInComing.ti_no, tblTransferInComing.to_no AS Expr1, tblTransferInComing.user_no AS Expr2, tblTransferInComing.ti_date, tblTransferInComing.branch_no AS Expr3, tblTransferInComing.h AS Expr4, tblCurrency.cur_no AS Expr5, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr6, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM ((tblTransferOutGoing INNER JOIN tblTransferInComing ON tblTransferOutGoing.to_no = tblTransferInComing.to_no) INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no)" + " where (tblTransferInComing.branch_no=" + branch.BranchNumber + ") and (datevalue(format(tblTransferInComing.ti_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + from.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + to.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
                }

                using (OleDbDataAdapter da = new OleDbDataAdapter(sql, new OleDbConnection(Utilities.connection_string)))
                {
                    da.Fill(ict);
                    da.Dispose();
                }
            }
            catch
            {

            }

            return ict;
        }

        internal DSet.ICTDataTable GetInComingTransction(DateTime from, DateTime to, BranchInfo branch, User user, bool x)
        {
            DSet.ICTDataTable ict = new DSet.ICTDataTable();
            try
            {

                string sql = "";

                if (x)
                {
                    sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,   tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,  tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblTransferInComing.ti_no, tblTransferInComing.to_no AS Expr1, tblTransferInComing.user_no AS Expr2, tblTransferInComing.ti_date, tblTransferInComing.branch_no AS Expr3, tblTransferInComing.h AS Expr4, tblCurrency.cur_no AS Expr5, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr6, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM ((tblTransferOutGoing INNER JOIN tblTransferInComing ON tblTransferOutGoing.to_no = tblTransferInComing.to_no) INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no)" + " where (tblTransferInComing.user_no=" + user.Number + ") and (tblTransferOutGoing.branch_no=" + branch.BranchNumber + ") and (datevalue(format(tblTransferInComing.ti_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + from.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + to.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
                }
                else
                {
                    sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,   tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,  tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblTransferInComing.ti_no, tblTransferInComing.to_no AS Expr1, tblTransferInComing.user_no AS Expr2, tblTransferInComing.ti_date, tblTransferInComing.branch_no AS Expr3, tblTransferInComing.h AS Expr4, tblCurrency.cur_no AS Expr5, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr6, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM ((tblTransferOutGoing INNER JOIN tblTransferInComing ON tblTransferOutGoing.to_no = tblTransferInComing.to_no) INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no)" + " where (tblTransferInComing.user_no=" + user.Number + ") and (tblTransferInComing.branch_no=" + branch.BranchNumber + ") and (datevalue(format(tblTransferInComing.ti_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + from.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + to.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
                }

                using (OleDbDataAdapter da = new OleDbDataAdapter(sql, new OleDbConnection(Utilities.connection_string)))
                {
                    da.Fill(ict);
                    da.Dispose();
                }
            }
            catch
            {

            }

            return ict;
        }

        internal DSet.ICTDataTable GetInComingTransction(DateTime from, DateTime to, BranchInfo src, BranchInfo dst)
        {
            DSet.ICTDataTable ict = new DSet.ICTDataTable();
            try
            {
                string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,   tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,  tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblTransferInComing.ti_no, tblTransferInComing.to_no AS Expr1, tblTransferInComing.user_no AS Expr2, tblTransferInComing.ti_date, tblTransferInComing.branch_no AS Expr3, tblTransferInComing.h AS Expr4, tblCurrency.cur_no AS Expr5, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr6, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM ((tblTransferOutGoing INNER JOIN tblTransferInComing ON tblTransferOutGoing.to_no = tblTransferInComing.to_no) INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no)" + " where (tblTransferInComing.branch_no=" + dst.BranchNumber + ") and (tblTransferOutGoing.branch_no=" + src.BranchNumber + ") and (datevalue(format(tblTransferInComing.ti_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + from.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + to.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";

                using (OleDbDataAdapter da = new OleDbDataAdapter(sql, new OleDbConnection(Utilities.connection_string)))
                {
                    da.Fill(ict);
                    da.Dispose();
                }
            }
            catch
            {

            }

            return ict;
        }

        internal DSet.ICTDataTable GetInComingTransction(DateTime from, DateTime to, BranchInfo src, BranchInfo dst, User user)
        {
            DSet.ICTDataTable ict = new DSet.ICTDataTable();
            try
            {
                string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,   tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,  tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblTransferInComing.ti_no, tblTransferInComing.to_no AS Expr1, tblTransferInComing.user_no AS Expr2, tblTransferInComing.ti_date, tblTransferInComing.branch_no AS Expr3, tblTransferInComing.h AS Expr4, tblCurrency.cur_no AS Expr5, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr6, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM ((tblTransferOutGoing INNER JOIN tblTransferInComing ON tblTransferOutGoing.to_no = tblTransferInComing.to_no) INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no)" + " where (tblTransferInComing.user_no=" + user.Number + ") and (tblTransferInComing.branch_no=" + dst.BranchNumber + ") and (tblTransferOutGoing.branch_no=" + src.BranchNumber + ") and (datevalue(format(tblTransferInComing.ti_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + from.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + to.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";

                using (OleDbDataAdapter da = new OleDbDataAdapter(sql, new OleDbConnection(Utilities.connection_string)))
                {
                    da.Fill(ict);
                    da.Dispose();
                }
            }
            catch
            {

            }

            return ict;
        }

        internal List<int> GetInComingTransctionNumbers()
        {
            lock (Utilities.mylocker)
            {
                List<int> numbers = new List<int>();

                bool res = false;
                try
                {
                    ADataBase ADB = new ADataBase();

                    string sql = "select to_no from tblTransferInComing";
                    if (ADB.ExcuteSQLQuery(sql))
                    {
                        while (ADB.GetDataReader.Read())
                        {
                            int n = (Convert.ToInt32(ADB.GetDataReader["to_no"]));
                            numbers.Add(n);
                        }
                    }

                    ADB.CloseConnection();

                }
                catch
                {
                }

                return numbers;

            }
        }
    }


    internal class LogReport
    {
        internal DSet.tblLogDataTable GetLog(DateTime from, DateTime to)
        {
            DSet.tblLogDataTable log = new DSet.tblLogDataTable();
            try
            {
                string sql = "SELECT tblMSG.msg_id, tblMSG.msg_name, tblMSG.msg_type, tblLOG.log_id,tblLOG.log_ip, tblLOG.msg_id AS Expr1, tblLOG.branch_no, tblLOG.station_no, tblLOG.user_no, tblLOG.log_time, tblLOG.log_note FROM (tblMSG INNER JOIN tblLOG ON tblMSG.msg_id = tblLOG.msg_id)" + " where (datevalue(format(tblLOG.log_time,\"yyyy/MM/dd\")) between datevalue(format(\"" + from.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + to.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";

                using (OleDbDataAdapter da = new OleDbDataAdapter(sql, new OleDbConnection(Utilities.connection_string)))
                {
                    da.Fill(log);
                    da.Dispose();
                }
            }
            catch
            {

            }

            return log;
        }
    }
}

