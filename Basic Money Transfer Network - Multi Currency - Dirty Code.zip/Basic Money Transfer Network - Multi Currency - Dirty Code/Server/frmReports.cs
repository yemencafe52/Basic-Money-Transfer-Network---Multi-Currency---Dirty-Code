﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace YMT
{
    public partial class frmReports : Form
    {
        public frmReports()
        {
            InitializeComponent();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == (Keys.Shift | Keys.Escape))
            {
                {
                    this.Close();
                }
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void frmReports_Load(object sender, EventArgs e)
        {


            dateTimePicker5.Format = DateTimePickerFormat.Custom;
            dateTimePicker5.CustomFormat = "yyyy/MM/dd";

            dateTimePicker6.Format = DateTimePickerFormat.Custom;
            dateTimePicker6.CustomFormat = "yyyy/MM/dd";


            dateTimePicker6.Enabled = false;
            dateTimePicker5.Enabled = false;

            dateTimePicker6.Value = new DateTime(DateTime.Now.Year, 1, 1);
            dateTimePicker5.Value = new DateTime(DateTime.Now.Year, 12, 31);//DateTime.Parse(DateTime.Now.ToString("yyyy/MM/dd"));

           

            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.Items.Add("صادر");
            comboBox1.Items.Add("وارد");
            comboBox1.SelectedIndex = 0;

            comboBox3.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox3.Items.Add("تحليلي");
            comboBox3.Items.Add("تفصيلي");
            comboBox3.SelectedIndex = 0;

            List<BranchInfo> branchies = BranchInfoManager.GetALLBranchInfo();

            comboBox4.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox4.Items.Add("الكل");

            foreach (BranchInfo b in branchies)
            {
                comboBox4.Items.Add(b.BranchNumber);
            }

            if (comboBox4.Items.Count > 0)
            {
                comboBox4.SelectedIndex = 0;
            }

            comboBox5.DropDownStyle = ComboBoxStyle.DropDownList;

            comboBox5.Items.Add("الكل");

            foreach (BranchInfo b in branchies)
            {
                comboBox5.Items.Add(b.BranchNumber);
            }

            if (comboBox5.Items.Count > 0)
            {
                comboBox5.SelectedIndex = 0;
            }


            List<User> users = Users.GetUsers();

            comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;

            comboBox2.Items.Add("الكل");

            foreach (User u in users)
            {
                comboBox2.Items.Add(u.Number);
            }

            if (comboBox2.Items.Count > 0)
            {
                comboBox2.SelectedIndex = 0;
            }



        }

        private void button2_Click(object sender, EventArgs e)
        {
            Print();
        }

        private void Print()
        {

            frmReportViewer frmRV = new frmReportViewer();
            
            DataTable dt = new DataTable();

            try
            {
                if (comboBox1.SelectedIndex == 0)
                {
                    OugGoingReports r = new OugGoingReports();

                    if (comboBox4.SelectedIndex == 0)
                    {
                        if (comboBox5.SelectedIndex == 0)
                        {
                            if (comboBox2.SelectedIndex == 0)
                            {
                                dt = r.GetOutGoingTransction(dateTimePicker6.Value, dateTimePicker5.Value);
                            }
                            else
                            {
                                dt = r.GetOutGoingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new User(byte.Parse(comboBox2.Text)));
                            }
                        }
                        else
                        {
                            if (comboBox2.SelectedIndex == 0)
                            {
                                dt = r.GetOutGoingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new BranchInfo(byte.Parse(comboBox5.Text)), false);
                            }
                            else
                            {
                                dt = r.GetOutGoingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new BranchInfo(byte.Parse(comboBox5.Text)), new User(byte.Parse(comboBox2.Text)), false);
                            }
                        }
                    }

                    else
                    {
                        if (comboBox5.SelectedIndex == 0)
                        {
                            if (comboBox2.SelectedIndex == 0)
                            {
                                dt = r.GetOutGoingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new BranchInfo(byte.Parse(comboBox4.Text)), true);
                            }
                            else
                            {
                                dt = r.GetOutGoingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new BranchInfo(byte.Parse(comboBox4.Text)), new User(byte.Parse(comboBox2.Text)), true);
                            }
                        }
                        else
                        {
                            if (comboBox2.SelectedIndex == 0)
                            {
                                dt = r.GetOutGoingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new BranchInfo(byte.Parse(comboBox4.Text)), new BranchInfo(byte.Parse(comboBox5.Text)));
                            }
                            else
                            {
                                dt = r.GetOutGoingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new BranchInfo(byte.Parse(comboBox4.Text)), new BranchInfo(byte.Parse(comboBox5.Text)), new User(byte.Parse(comboBox2.Text)));
                            }
                        }
                    }

                    if (dt.Rows.Count == 0)
                    {
                        MessageBox.Show("لا توجد نتائج لعرضها.", "", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information, System.Windows.Forms.MessageBoxDefaultButton.Button1, System.Windows.Forms.MessageBoxOptions.RtlReading);
                        return;
                    }


                    Microsoft.Reporting.WinForms.ReportDataSource rpt = new Microsoft.Reporting.WinForms.ReportDataSource("OGT", dt);

                    frmRV.reportViewer1.LocalReport.DataSources.Clear();

                    if (comboBox3.SelectedIndex == 0)
                    {
                        frmRV.reportViewer1.LocalReport.ReportEmbeddedResource = "YMT.rptOGTDetials.rdlc";
                    }
                    else
                    {
                        frmRV.reportViewer1.LocalReport.ReportEmbeddedResource = "YMT.rptTotalOGTReport.rdlc";
                    }

                    frmRV.reportViewer1.LocalReport.DataSources.Add(rpt);
                    frmRV.reportViewer1.RefreshReport();
                    frmRV.Show();
                }
                else
                {
                    InComingReports r = new InComingReports();

                    if (comboBox4.SelectedIndex == 0)
                    {
                        if (comboBox5.SelectedIndex == 0)
                        {
                            if (comboBox2.SelectedIndex == 0)
                            {
                                dt = r.GetInComingTransction(dateTimePicker6.Value, dateTimePicker5.Value);
                            }
                            else
                            {
                                dt = r.GetInComingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new User(byte.Parse(comboBox2.Text)));
                            }
                        }
                        else
                        {
                            if (comboBox2.SelectedIndex == 0)
                            {
                                dt = r.GetInComingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new BranchInfo(byte.Parse(comboBox5.Text)), false);
                            }
                            else
                            {
                                dt = r.GetInComingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new BranchInfo(byte.Parse(comboBox5.Text)), new User(byte.Parse(comboBox2.Text)), false);
                            }
                        }
                    }

                    else
                    {
                        if (comboBox5.SelectedIndex == 0)
                        {
                            if (comboBox2.SelectedIndex == 0)
                            {
                                dt = r.GetInComingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new BranchInfo(byte.Parse(comboBox4.Text)), true);
                            }
                            else
                            {
                                dt = r.GetInComingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new BranchInfo(byte.Parse(comboBox4.Text)), new User(byte.Parse(comboBox2.Text)), true);
                            }
                        }
                        else
                        {
                            if (comboBox2.SelectedIndex == 0)
                            {
                                dt = r.GetInComingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new BranchInfo(byte.Parse(comboBox4.Text)), new BranchInfo(byte.Parse(comboBox5.Text)));
                            }
                            else
                            {
                                dt = r.GetInComingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new BranchInfo(byte.Parse(comboBox4.Text)), new BranchInfo(byte.Parse(comboBox5.Text)), new User(byte.Parse(comboBox2.Text)));
                            }
                        }
                    }

                    if (dt.Rows.Count == 0)
                    {
                        MessageBox.Show("لا توجد نتائج لعرضها.", "", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information, System.Windows.Forms.MessageBoxDefaultButton.Button1, System.Windows.Forms.MessageBoxOptions.RtlReading);
                        return;
                    }


                    Microsoft.Reporting.WinForms.ReportDataSource rpt = new Microsoft.Reporting.WinForms.ReportDataSource("ICT", dt);

                    frmRV.reportViewer1.LocalReport.DataSources.Clear();

                    if (comboBox3.SelectedIndex == 0)
                    {
                        frmRV.reportViewer1.LocalReport.ReportEmbeddedResource = "YMT.rptICTDetials.rdlc";
                    }
                    else
                    {
                        frmRV.reportViewer1.LocalReport.ReportEmbeddedResource = "YMT.rptTotalICTReport.rdlc";
                    }

                    frmRV.reportViewer1.LocalReport.DataSources.Add(rpt);
                    frmRV.reportViewer1.RefreshReport();
                    frmRV.Show();
                }

            }
            catch
            {
                MessageBox.Show("تعذر عرض التقرير..", "", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error, System.Windows.Forms.MessageBoxDefaultButton.Button1, System.Windows.Forms.MessageBoxOptions.RtlReading);
            }

        }

        private void comboBox7_SelectedIndexChanged(object sender, EventArgs e)
        {

        }



        //private void Print()
        //{

        //    frmReportViewer frmRV = new frmReportViewer();
        //    Reports r = new Reports();
        //    DataTable ogt = r.GetOutGoingTransction(dateTimePicker6.Value, dateTimePicker5.Value);

        //    if (ogt.Rows.Count == 0)
        //    {
        //        MessageBox.Show("لا توجد نتائج لعرضها.", "", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information, System.Windows.Forms.MessageBoxDefaultButton.Button1, System.Windows.Forms.MessageBoxOptions.RtlReading);
        //        return;
        //    }


        //    Microsoft.Reporting.WinForms.ReportDataSource rpt = new Microsoft.Reporting.WinForms.ReportDataSource("OGT", ogt);

        //    frmRV.reportViewer1.LocalReport.DataSources.Clear();

        //    frmRV.reportViewer1.LocalReport.ReportEmbeddedResource = "YMT.rptOGTDetials.rdlc";
        //    frmRV.reportViewer1.LocalReport.DataSources.Add(rpt);
        //    frmRV.reportViewer1.RefreshReport();
        //    frmRV.Show();


        //    return;
        //    try
        //    {


        //        //if (comboBox1.SelectedIndex == 0)
        //        //{

        //        //    List<TransferOutGoing> ogtl= Reports.GetOutGoingTransction(dateTimePicker6.Value, dateTimePicker5.Value);

        //        //    if (ogtl.Count == 0)
        //        //    {
        //        //        MessageBox.Show("لا توجد نتائج لعرضها.", "", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information, System.Windows.Forms.MessageBoxDefaultButton.Button1, System.Windows.Forms.MessageBoxOptions.RtlReading);
        //        //        return;
        //        //    }


        //        //    Microsoft.Reporting.WinForms.ReportDataSource rpt = new Microsoft.Reporting.WinForms.ReportDataSource("OGT2", ogtl);

        //        //    frmRV.reportViewer1.LocalReport.DataSources.Clear();

        //        //    frmRV.reportViewer1.LocalReport.ReportEmbeddedResource = "YMT.rptOGTDetials2.rdlc";
        //        //    frmRV.reportViewer1.LocalReport.DataSources.Add(rpt);
        //        //    frmRV.reportViewer1.RefreshReport();
        //        //    frmRV.Show();
        //        //    return;


        //        //}
        //        //else
        //        //{

        //        //}

        //        DSet ds = new DSet();
        //        frmRV = new frmReportViewer();
        //        ADataBase d = new ADataBase();
        //        OleDbDataAdapter da = null;

        //        if (comboBox1.SelectedIndex == 0)
        //        {
        //            if (comboBox3.SelectedIndex == 0)
        //            {
        //                if (comboBox4.SelectedIndex == 0)
        //                {
        //                    if (comboBox5.SelectedIndex == 0)
        //                    {
        //                        if (comboBox2.SelectedIndex == 0)
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,  tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,   tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblCurrency.cur_no AS Expr1, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr2, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM (tblTransferOutGoing INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no)" + " where (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                        else
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,  tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,   tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblCurrency.cur_no AS Expr1, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr2, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM (tblTransferOutGoing INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where user_no=" + comboBox2.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                    }
        //                    else
        //                    {
        //                        if (comboBox2.SelectedIndex == 0)
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,  tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,   tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblCurrency.cur_no AS Expr1, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr2, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM (tblTransferOutGoing INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where to_dest_branch=" + comboBox5.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                        else
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,  tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,   tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblCurrency.cur_no AS Expr1, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr2, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM (tblTransferOutGoing INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where user_no=" + comboBox2.Text + " and to_dest_branch=" + comboBox5.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                    }
        //                }
        //                else
        //                {
        //                    if (comboBox5.SelectedIndex == 0)
        //                    {
        //                        if (comboBox2.SelectedIndex == 0)
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,  tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,   tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblCurrency.cur_no AS Expr1, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr2, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM (tblTransferOutGoing INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where branch_no=" + comboBox4.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                        else
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,  tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,   tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblCurrency.cur_no AS Expr1, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr2, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM (tblTransferOutGoing INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where user_no=" + comboBox2.Text + " and branch_no=" + comboBox4.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                    }
        //                    else
        //                    {
        //                        if (comboBox2.SelectedIndex == 0)
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,  tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,   tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblCurrency.cur_no AS Expr1, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr2, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM (tblTransferOutGoing INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where to_dest_branch=" + comboBox5.Text + " and branch_no=" + comboBox4.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                        else
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,  tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,   tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblCurrency.cur_no AS Expr1, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr2, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM (tblTransferOutGoing INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where user_no=" + comboBox2.Text + " and to_dest_branch=" + comboBox5.Text + " and branch_no=" + comboBox4.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                    }
        //                }

        //                da.Fill(ds, ds.Tables["OGT"].TableName);

        //                if (ds.Tables["OGT"].Rows.Count == 0)
        //                {
        //                    MessageBox.Show("لا توجد نتائج لعرضها.", "", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information, System.Windows.Forms.MessageBoxDefaultButton.Button1, System.Windows.Forms.MessageBoxOptions.RtlReading);
        //                    return;
        //                }


        //                //Microsoft.Reporting.WinForms.ReportDataSource rpt = new Microsoft.Reporting.WinForms.ReportDataSource("OGT", ds.Tables["OGT"]);

        //                frmRV.reportViewer1.LocalReport.DataSources.Clear();

        //                frmRV.reportViewer1.LocalReport.ReportEmbeddedResource = "YMT.rptOGTDetials.rdlc";
        //                frmRV.reportViewer1.LocalReport.DataSources.Add(rpt);
        //                frmRV.reportViewer1.RefreshReport();
        //                frmRV.Show();

        //            }
        //            else
        //            {
        //                if (comboBox4.SelectedIndex == 0)
        //                {
        //                    if (comboBox5.SelectedIndex == 0)
        //                    {
        //                        if (comboBox2.SelectedIndex == 0)
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,  tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,   tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblCurrency.cur_no AS Expr1, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr2, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM (tblTransferOutGoing INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no)" + " where (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                        else
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,  tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,   tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblCurrency.cur_no AS Expr1, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr2, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM (tblTransferOutGoing INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where user_no=" + comboBox2.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                    }
        //                    else
        //                    {
        //                        if (comboBox2.SelectedIndex == 0)
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,  tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,   tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblCurrency.cur_no AS Expr1, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr2, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM (tblTransferOutGoing INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where to_dest_branch=" + comboBox5.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                        else
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,  tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,   tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblCurrency.cur_no AS Expr1, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr2, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM (tblTransferOutGoing INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where user_no=" + comboBox2.Text + " and to_dest_branch=" + comboBox5.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                    }
        //                }
        //                else
        //                {
        //                    if (comboBox5.SelectedIndex == 0)
        //                    {
        //                        if (comboBox2.SelectedIndex == 0)
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,  tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,   tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblCurrency.cur_no AS Expr1, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr2, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM (tblTransferOutGoing INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where branch_no=" + comboBox4.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                        else
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,  tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,   tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblCurrency.cur_no AS Expr1, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr2, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM (tblTransferOutGoing INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where user_no=" + comboBox2.Text + " and branch_no=" + comboBox4.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                    }
        //                    else
        //                    {
        //                        if (comboBox2.SelectedIndex == 0)
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,  tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,   tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblCurrency.cur_no AS Expr1, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr2, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM (tblTransferOutGoing INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where to_dest_branch=" + comboBox5.Text + " and branch_no=" + comboBox4.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                        else
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,  tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,   tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblCurrency.cur_no AS Expr1, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr2, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM (tblTransferOutGoing INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where user_no=" + comboBox2.Text + " and to_dest_branch=" + comboBox5.Text + " and branch_no=" + comboBox4.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                    }
        //                }

        //                da.Fill(ds, ds.Tables["OGT"].TableName);

        //                if (ds.Tables["OGT"].Rows.Count == 0)
        //                {
        //                    MessageBox.Show("لا توجد نتائج لعرضها.", "", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information, System.Windows.Forms.MessageBoxDefaultButton.Button1, System.Windows.Forms.MessageBoxOptions.RtlReading);
        //                    return;
        //                }


        //                //Microsoft.Reporting.WinForms.ReportDataSource rpt = new Microsoft.Reporting.WinForms.ReportDataSource("OGT", ds.Tables["OGT"]);

        //                frmRV.reportViewer1.LocalReport.DataSources.Clear();

        //                frmRV.reportViewer1.LocalReport.ReportEmbeddedResource = "YMT.rptTotalOGTReport.rdlc";
        //                frmRV.reportViewer1.LocalReport.DataSources.Add(rpt);
        //                frmRV.reportViewer1.RefreshReport();
        //                frmRV.Show();

        //            }
        //        }
        //        else
        //        {
        //            if (comboBox3.SelectedIndex == 0)
        //            {
        //                if (comboBox4.SelectedIndex == 0)
        //                {
        //                    if (comboBox5.SelectedIndex == 0)
        //                    {
        //                        if (comboBox2.SelectedIndex == 0)
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,   tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,  tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblTransferInComing.ti_no, tblTransferInComing.to_no AS Expr1, tblTransferInComing.user_no AS Expr2, tblTransferInComing.ti_date, tblTransferInComing.branch_no AS Expr3, tblTransferInComing.h AS Expr4, tblCurrency.cur_no AS Expr5, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr6, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM ((tblTransferOutGoing INNER JOIN tblTransferInComing ON tblTransferOutGoing.to_no = tblTransferInComing.to_no) INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no)" + " where (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                        else
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,   tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,  tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblTransferInComing.ti_no, tblTransferInComing.to_no AS Expr1, tblTransferInComing.user_no AS Expr2, tblTransferInComing.ti_date, tblTransferInComing.branch_no AS Expr3, tblTransferInComing.h AS Expr4, tblCurrency.cur_no AS Expr5, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr6, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM ((tblTransferOutGoing INNER JOIN tblTransferInComing ON tblTransferOutGoing.to_no = tblTransferInComing.to_no) INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where tblTransferInComing.user_no=" + comboBox2.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                    }
        //                    else
        //                    {
        //                        if (comboBox2.SelectedIndex == 0)
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,   tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,  tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblTransferInComing.ti_no, tblTransferInComing.to_no AS Expr1, tblTransferInComing.user_no AS Expr2, tblTransferInComing.ti_date, tblTransferInComing.branch_no AS Expr3, tblTransferInComing.h AS Expr4, tblCurrency.cur_no AS Expr5, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr6, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM ((tblTransferOutGoing INNER JOIN tblTransferInComing ON tblTransferOutGoing.to_no = tblTransferInComing.to_no) INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where tblTransferInComing.branch_no=" + comboBox5.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                        else
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,   tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,  tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblTransferInComing.ti_no, tblTransferInComing.to_no AS Expr1, tblTransferInComing.user_no AS Expr2, tblTransferInComing.ti_date, tblTransferInComing.branch_no AS Expr3, tblTransferInComing.h AS Expr4, tblCurrency.cur_no AS Expr5, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr6, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM ((tblTransferOutGoing INNER JOIN tblTransferInComing ON tblTransferOutGoing.to_no = tblTransferInComing.to_no) INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where tblTransferInComing.user_no=" + comboBox2.Text + " and tblTransferInComing.branch_no=" + comboBox5.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                    }
        //                }
        //                else
        //                {
        //                    if (comboBox5.SelectedIndex == 0)
        //                    {
        //                        if (comboBox2.SelectedIndex == 0)
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,   tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,  tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblTransferInComing.ti_no, tblTransferInComing.to_no AS Expr1, tblTransferInComing.user_no AS Expr2, tblTransferInComing.ti_date, tblTransferInComing.branch_no AS Expr3, tblTransferInComing.h AS Expr4, tblCurrency.cur_no AS Expr5, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr6, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM ((tblTransferOutGoing INNER JOIN tblTransferInComing ON tblTransferOutGoing.to_no = tblTransferInComing.to_no) INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where tblTransferOutGoing.branch_no=" + comboBox4.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                        else
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,   tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,  tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblTransferInComing.ti_no, tblTransferInComing.to_no AS Expr1, tblTransferInComing.user_no AS Expr2, tblTransferInComing.ti_date, tblTransferInComing.branch_no AS Expr3, tblTransferInComing.h AS Expr4, tblCurrency.cur_no AS Expr5, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr6, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM ((tblTransferOutGoing INNER JOIN tblTransferInComing ON tblTransferOutGoing.to_no = tblTransferInComing.to_no) INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where tblTransferInComing.user_no=" + comboBox2.Text + " and tblTransferOutGoing.branch_no=" + comboBox4.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                    }
        //                    else
        //                    {
        //                        if (comboBox2.SelectedIndex == 0)
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,   tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,  tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblTransferInComing.ti_no, tblTransferInComing.to_no AS Expr1, tblTransferInComing.user_no AS Expr2, tblTransferInComing.ti_date, tblTransferInComing.branch_no AS Expr3, tblTransferInComing.h AS Expr4, tblCurrency.cur_no AS Expr5, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr6, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM ((tblTransferOutGoing INNER JOIN tblTransferInComing ON tblTransferOutGoing.to_no = tblTransferInComing.to_no) INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where tblTransferInComing.branch_no=" + comboBox5.Text + " and tblTransferOutGoing.branch_no=" + comboBox4.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                        else
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,   tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,  tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblTransferInComing.ti_no, tblTransferInComing.to_no AS Expr1, tblTransferInComing.user_no AS Expr2, tblTransferInComing.ti_date, tblTransferInComing.branch_no AS Expr3, tblTransferInComing.h AS Expr4, tblCurrency.cur_no AS Expr5, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr6, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM ((tblTransferOutGoing INNER JOIN tblTransferInComing ON tblTransferOutGoing.to_no = tblTransferInComing.to_no) INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where tblTransferInComing.user_no=" + comboBox2.Text + " and tblTransferInComing.branch_no=" + comboBox5.Text + " and branch_no=" + comboBox4.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                    }
        //                }

        //                da.Fill(ds, ds.Tables["ICT"].TableName);

        //                if (ds.Tables["ICT"].Rows.Count == 0)
        //                {
        //                    MessageBox.Show("لا توجد نتائج لعرضها.", "", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information, System.Windows.Forms.MessageBoxDefaultButton.Button1, System.Windows.Forms.MessageBoxOptions.RtlReading);
        //                    return;
        //                }


        //                //Microsoft.Reporting.WinForms.ReportDataSource rpt = new Microsoft.Reporting.WinForms.ReportDataSource("ICT", ds.Tables["ICT"]);

        //                frmRV.reportViewer1.LocalReport.DataSources.Clear();

        //                frmRV.reportViewer1.LocalReport.ReportEmbeddedResource = "YMT.rptICTDetials.rdlc";
        //                frmRV.reportViewer1.LocalReport.DataSources.Add(rpt);
        //                frmRV.reportViewer1.RefreshReport();
        //                frmRV.Show();

        //            }
        //            else
        //            {
        //                if (comboBox4.SelectedIndex == 0)
        //                {
        //                    if (comboBox5.SelectedIndex == 0)
        //                    {
        //                        if (comboBox2.SelectedIndex == 0)
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,   tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,  tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblTransferInComing.ti_no, tblTransferInComing.to_no AS Expr1, tblTransferInComing.user_no AS Expr2, tblTransferInComing.ti_date, tblTransferInComing.branch_no AS Expr3, tblTransferInComing.h AS Expr4, tblCurrency.cur_no AS Expr5, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr6, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM ((tblTransferOutGoing INNER JOIN tblTransferInComing ON tblTransferOutGoing.to_no = tblTransferInComing.to_no) INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no)" + " where (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                        else
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,   tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,  tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblTransferInComing.ti_no, tblTransferInComing.to_no AS Expr1, tblTransferInComing.user_no AS Expr2, tblTransferInComing.ti_date, tblTransferInComing.branch_no AS Expr3, tblTransferInComing.h AS Expr4, tblCurrency.cur_no AS Expr5, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr6, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM ((tblTransferOutGoing INNER JOIN tblTransferInComing ON tblTransferOutGoing.to_no = tblTransferInComing.to_no) INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where tblTransferInComing.user_no=" + comboBox2.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                    }
        //                    else
        //                    {
        //                        if (comboBox2.SelectedIndex == 0)
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,   tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,  tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblTransferInComing.ti_no, tblTransferInComing.to_no AS Expr1, tblTransferInComing.user_no AS Expr2, tblTransferInComing.ti_date, tblTransferInComing.branch_no AS Expr3, tblTransferInComing.h AS Expr4, tblCurrency.cur_no AS Expr5, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr6, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM ((tblTransferOutGoing INNER JOIN tblTransferInComing ON tblTransferOutGoing.to_no = tblTransferInComing.to_no) INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where tblTransferInComing.branch_no=" + comboBox5.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                        else
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,   tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,  tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblTransferInComing.ti_no, tblTransferInComing.to_no AS Expr1, tblTransferInComing.user_no AS Expr2, tblTransferInComing.ti_date, tblTransferInComing.branch_no AS Expr3, tblTransferInComing.h AS Expr4, tblCurrency.cur_no AS Expr5, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr6, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM ((tblTransferOutGoing INNER JOIN tblTransferInComing ON tblTransferOutGoing.to_no = tblTransferInComing.to_no) INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where tblTransferInComing.user_no=" + comboBox2.Text + " and tblTransferInComing.branch_no=" + comboBox5.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                    }
        //                }
        //                else
        //                {
        //                    if (comboBox5.SelectedIndex == 0)
        //                    {
        //                        if (comboBox2.SelectedIndex == 0)
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,   tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,  tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblTransferInComing.ti_no, tblTransferInComing.to_no AS Expr1, tblTransferInComing.user_no AS Expr2, tblTransferInComing.ti_date, tblTransferInComing.branch_no AS Expr3, tblTransferInComing.h AS Expr4, tblCurrency.cur_no AS Expr5, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr6, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM ((tblTransferOutGoing INNER JOIN tblTransferInComing ON tblTransferOutGoing.to_no = tblTransferInComing.to_no) INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where tblTransferOutGoing.branch_no=" + comboBox4.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                        else
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,   tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,  tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblTransferInComing.ti_no, tblTransferInComing.to_no AS Expr1, tblTransferInComing.user_no AS Expr2, tblTransferInComing.ti_date, tblTransferInComing.branch_no AS Expr3, tblTransferInComing.h AS Expr4, tblCurrency.cur_no AS Expr5, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr6, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM ((tblTransferOutGoing INNER JOIN tblTransferInComing ON tblTransferOutGoing.to_no = tblTransferInComing.to_no) INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where tblTransferInComing.user_no=" + comboBox2.Text + " and tblTransferOutGoing.branch_no=" + comboBox4.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                    }
        //                    else
        //                    {
        //                        if (comboBox2.SelectedIndex == 0)
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,   tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,  tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblTransferInComing.ti_no, tblTransferInComing.to_no AS Expr1, tblTransferInComing.user_no AS Expr2, tblTransferInComing.ti_date, tblTransferInComing.branch_no AS Expr3, tblTransferInComing.h AS Expr4, tblCurrency.cur_no AS Expr5, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr6, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM ((tblTransferOutGoing INNER JOIN tblTransferInComing ON tblTransferOutGoing.to_no = tblTransferInComing.to_no) INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where tblTransferInComing.branch_no=" + comboBox5.Text + " and tblTransferOutGoing.branch_no=" + comboBox4.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                        else
        //                        {
        //                            string sql = "SELECT tblTransferOutGoing.to_no, tblTransferOutGoing.to_type, tblTransferOutGoing.to_date, tblTransferOutGoing.to_amount, tblTransferOutGoing.to_famount, tblTransferOutGoing.to_trans_commation,   tblTransferOutGoing.to_reciver_commation, tblTransferOutGoing.to_sender_name, tblTransferOutGoing.to_reciver_name, tblTransferOutGoing.user_no, tblTransferOutGoing.cur_no, tblTransferOutGoing.cur_exchange,  tblTransferOutGoing.to_trans_fcommation, tblTransferOutGoing.to_reciver_fcommation, tblTransferOutGoing.ogt_v1, tblTransferOutGoing.branch_no, tblTransferOutGoing.h, tblTransferOutGoing.to_dest_branch,  tblTransferInComing.ti_no, tblTransferInComing.to_no AS Expr1, tblTransferInComing.user_no AS Expr2, tblTransferInComing.ti_date, tblTransferInComing.branch_no AS Expr3, tblTransferInComing.h AS Expr4, tblCurrency.cur_no AS Expr5, tblCurrency.cur_name, tblCurrency.cur_exchange AS Expr6, tblCurrency.cur_symbol, tblCurrency.cur_bit_name FROM ((tblTransferOutGoing INNER JOIN tblTransferInComing ON tblTransferOutGoing.to_no = tblTransferInComing.to_no) INNER JOIN tblCurrency ON tblTransferOutGoing.cur_no = tblCurrency.cur_no) where tblTransferInComing.user_no=" + comboBox2.Text + " and tblTransferInComing.branch_no=" + comboBox5.Text + " and branch_no=" + comboBox4.Text + " and (datevalue(format(tblTransferOutGoing.to_date,\"yyyy/MM/dd\")) between datevalue(format(\"" + dateTimePicker6.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")) and datevalue(format(\"" + dateTimePicker5.Value.ToString("yyyy/MM/dd") + "\",\"yyyy/MM/d\")))";
        //                            d.ExcuteSQLQuery(sql);
        //                            da = new OleDbDataAdapter(sql, Utilities.connection_string);
        //                        }
        //                    }
        //                }

        //                da.Fill(ds, ds.Tables["ICT"].TableName);

        //                if (ds.Tables["ICT"].Rows.Count == 0)
        //                {
        //                    MessageBox.Show("لا توجد نتائج لعرضها.", "", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information, System.Windows.Forms.MessageBoxDefaultButton.Button1, System.Windows.Forms.MessageBoxOptions.RtlReading);
        //                    return;
        //                }


        //                //Microsoft.Reporting.WinForms.ReportDataSource rpt = new Microsoft.Reporting.WinForms.ReportDataSource("ICT", ds.Tables["ICT"]);

        //                frmRV.reportViewer1.LocalReport.DataSources.Clear();

        //                frmRV.reportViewer1.LocalReport.ReportEmbeddedResource = "YMT.rptTotalICTReport.rdlc";
        //                frmRV.reportViewer1.LocalReport.DataSources.Add(rpt);
        //                frmRV.reportViewer1.RefreshReport();
        //                frmRV.Show();

        //            }
        //        }
        //    }

        //    catch
        //    {
        //    }

        //}
    }
}
