﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography;

namespace YMT
{
   public enum MoneyTransferType
    {
        IN = 0,
        OUT = 1
    }

    public class TransferIncomingManager
    {

        public static int ID
        {
            get
            {
                return ++id;
            }
        }

        internal static int id = GenerateNewTransctionID2();

        internal static int GenerateNewTransctionID()
        {
            lock (Utilities.mylocker)
            {
                return ++id;
                int res = 1;
                try
                {
                    ADataBase ADB = new ADataBase();

                    string sql = "select (max(ti_no)+1) as res from tblTransferInComing";
                    if (ADB.ExcuteSQLQuery(sql))
                    {
                        if (ADB.GetDataReader.Read())
                        {
                            res = Convert.ToInt32(ADB.GetDataReader["res"].ToString());
                        }
                    }
                    ADB.CloseConnection();
                }
                catch
                {
                    res = 1;
                }


                return res;
            }
        }

        internal static int GenerateNewTransctionID2()
        {
            lock (Utilities.mylocker)
            {
                int res = 1;
                try
                {
                    ADataBase ADB = new ADataBase();

                    string sql = "select (max(ti_no)+1) as res from tblTransferInComing";
                    if (ADB.ExcuteSQLQuery(sql))
                    {
                        if (ADB.GetDataReader.Read())
                        {
                            res = Convert.ToInt32(ADB.GetDataReader["res"].ToString());
                        }
                    }
                    ADB.CloseConnection();
                }
                catch
                {
                    res = 1;
                }


                return res;
            }
        }

        public static bool CreateNewIncomingTransction(TransferIncoming ti)
        {
            lock (Utilities.mylocker)
            {
                bool res = false;

                try
                {

                    ADataBase db = new ADataBase();
                    //string hash = ti.GetCurrentHASH;

                    string sql = @"insert into tblTransferInComing(ti_no,to_no,user_no,ti_date,branch_no,h) values(" + ti.TransferIncomingNumber + ","+ + ti.TransferOutGoingInfo.Number + "," + ti.UserInfo.Number + ",'" + ti.Date + "'," + ti.Branch.BranchNumber + ",'" + ti.GetHash + "'" + ")";

                    if (db.ExcuteSQLNonQuery(sql) == 1)
                    {
                       
                        res = true;
                    }
                    else
                    {
                        throw new Exception("");
                    }

                }
                catch (Exception ex)
                {
                    ti.ExceptionInfo = ex;
                }


                return res;
            }
        }

    }

    public class TransferIncoming
    {
        private int ti_no;
        private TransferOutGoing to_no;
        private User user;
        private DateTime ti_date;
        private BranchInfo branch_no;
        private string hash = "";
        private Exception exception_info;

        public TransferIncoming(int ti_no, TransferOutGoing to_no, User user, DateTime ti_date, BranchInfo branch, string hash = null)
        {
            this.ti_no = ti_no;
            this.to_no = to_no;
            this.user = user;
            this.ti_date = ti_date;
            this.branch_no = branch;

            if (hash != null)
            {
                this.hash = hash;
            }
            else
            {
                this.hash = GetCurrentHASH;
            }

        }

        public TransferIncoming(int number)
        {

            lock (Utilities.mylocker)
            {
                ADataBase ADB = new ADataBase();

                string sql = "select ti_no,to_no,user_no,ti_date,branch_no,h from tblTransferInComing where to_no=" + number;
                if (ADB.ExcuteSQLQuery(sql))
                {
                    if (ADB.GetDataReader.Read())
                    {
                        this.ti_no = Convert.ToInt32(ADB.GetDataReader["ti_no"]);
                        this.to_no = new TransferOutGoing(Convert.ToInt32(ADB.GetDataReader["to_no"]));
                        this.user = new User(Convert.ToByte(ADB.GetDataReader["user_no"]));
                        this.ti_date = Convert.ToDateTime(ADB.GetDataReader["ti_date"]);
                        this.branch_no = new BranchInfo(Convert.ToByte(ADB.GetDataReader["branch_no"]));
                        this.hash = (Convert.ToString(ADB.GetDataReader["h"]));

                        //if (this.hash != this.GetCurrentHASH)
                        //{
                        //    this.exception_info = new Exception("");
                        //}
                    }
                    else
                    {
                        if (ADB.ExceptionInfo != null)
                        {
                            this.exception_info = ADB.ExceptionInfo;
                        }
                        else
                        {
                            this.exception_info = new Exception("");
                        }
                    }
                }
                else
                {
                    if (ADB.ExceptionInfo != null)
                    {
                        this.exception_info = ADB.ExceptionInfo;
                    }
                    else
                    {
                        this.exception_info = new Exception("");
                    }
                }

                ADB.CloseConnection();
            }
        }
        public int TransferIncomingNumber
        {
            get
            {
                return this.ti_no;
            }
            set
            {
                this.ti_no = value;
            }
        }

        public TransferOutGoing TransferOutGoingInfo
        {
            get
            {
                return this.to_no;
            }
            set
            {
                this.to_no = value;
            }
        }

        public DateTime Date
        {
            get
            {
                return this.ti_date;
            }
            set
            {
                this.ti_date = value;
            }
        }

        public Exception ExceptionInfo
        {
            get
            {
                return this.exception_info;
            }
            set
            {
                this.exception_info = value;
            }
        }

        public User UserInfo
        {
            get
            {
                return this.user;
            }
            set
            {
                this.user = value;
            }
        }

        public BranchInfo Branch
        {
            get
            {
                return this.branch_no;
            }
            set
            {
                this.branch_no = value;
            }
        }

        private string GetMD5Hash(byte[] ar)
        {

            using (MD5 md5Hash = MD5.Create())
            {
                // Convert the input string to a byte array and compute the hash. 
                byte[] data = md5Hash.ComputeHash(ar);

                StringBuilder sBuilder = new StringBuilder();

                // Loop through each byte of the hashed data  
                // and format each one as a hexadecimal string. 
                for (int i = 0; i < data.Length; i++)
                {
                    sBuilder.Append(data[i].ToString("x2"));
                }

                // Return the hexadecimal string. 
                return sBuilder.ToString();

            }
        }

        public string GetCurrentHASH
        {
            get
            {
                return this.GetMD5Hash(this.HashBytes());
            }
        }

        public string GetHash
        {
            get
            {
                return this.hash;
            }
        }

        public TransferIncoming(byte[] ar)
        {
            try
            {
                int index = 0;
                int l = 1;
                byte[] art = new byte[1];

                this.ti_no = BitConverter.ToInt32(ar, index);
                index += 4;

                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.to_no = new TransferOutGoing(art);

                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.user = new User(art);

                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.branch_no = new BranchInfo(art);


                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.hash = Encoding.UTF8.GetString(art); 


                this.ti_date = DateTime.FromOADate(BitConverter.ToDouble(ar, index));
                index += 8;

                l = BitConverter.ToInt32(ar, index);
                index += 4;

                if (l == 0)
                {
                    this.exception_info = null;
                }
                else
                {
                    art = new byte[l];
                    Array.Copy(ar, index, art, 0, l);
                    index += l;
                    this.exception_info = DeserializeX(art);
                }
            }
            catch (Exception ex)
            {
                this.exception_info = new Exception("");
            }

        }

        public byte[] ToBytes()
        {
            List<byte> ar = new List<byte>();

            ar.AddRange(BitConverter.GetBytes(this.ti_no));

            ar.AddRange(BitConverter.GetBytes(this.to_no.ToBytes().Count()));
            ar.AddRange(this.to_no.ToBytes());

            ar.AddRange(BitConverter.GetBytes(this.user.ToBytes().Count()));
            ar.AddRange(this.user.ToBytes());

            ar.AddRange(BitConverter.GetBytes(this.branch_no.ToBytes().Count()));
            ar.AddRange(this.branch_no.ToBytes());

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.hash).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.hash));

            ar.AddRange(BitConverter.GetBytes((double)this.ti_date.ToOADate()));

            if (this.exception_info == null)
            {
                int x = 0;
                ar.AddRange(BitConverter.GetBytes(x));
            }
            else
            {
                byte[] e = SerializeX(this.exception_info);
                ar.AddRange(BitConverter.GetBytes(e.Length));
                ar.AddRange(e);
            }
            return ar.ToArray();
        }

        public byte[] HashBytes()
        {
            List<byte> ar = new List<byte>();

            ar.AddRange(BitConverter.GetBytes(this.ti_no));

             ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.to_no.GetHash).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.to_no.GetHash));

            ar.AddRange(BitConverter.GetBytes(this.user.Number));
            
            ar.AddRange(BitConverter.GetBytes(this.branch_no.BranchNumber));
            
            //ar.AddRange(BitConverter.GetBytes((double)this.ti_date.ToOADate()));

            return ar.ToArray();
        }

        
        private Exception DeserializeX(byte[] ar)
        {

            Stream stream = new MemoryStream(ar);
            BinaryFormatter formatter = new BinaryFormatter();
            Exception ex = (Exception)formatter.Deserialize(stream);
            stream.Close();

            return ex;
        }

        private static byte[] SerializeX<T>(T obj)
        {
            using (MemoryStream memStream = new MemoryStream())
            {
                BinaryFormatter binSerializer = new BinaryFormatter();
                binSerializer.Serialize(memStream, obj);
                return memStream.ToArray();
            }
        }
    }

    public class TransferOutGoing
    {
        private int to_no;
        private MoneyTransferType type;
        private DateTime to_date;
       
        private decimal to_amount;
        private decimal to_famount;
        private decimal to_trans_commation;
      
        private decimal to_reciver_commation;
        private string to_sender_name;
        private string to_reciver_name;
        private User user;

        private CurrencyInfo currency;
        private decimal cur_exchange;
        private decimal to_trans_fcommation;
        private decimal to_reciver_fcommation;
        
        private Exception exception_info = null;
        private int ogt_v1;
        
        private BranchInfo branch = null;
        private string hash = "";

        private BranchInfo dest_branch = null;


        public TransferOutGoing(int number)
        {
            lock (Utilities.mylocker)
            {

                ADataBase ADB = new ADataBase();

                string sql = "select to_dest_branch,h,branch_no,ogt_v1, to_no,to_type,to_date,to_amount,to_famount,to_trans_commation,to_reciver_commation,to_sender_name,to_reciver_name,user_no,cur_no,cur_exchange,to_trans_fcommation,to_reciver_fcommation from tblTransferOutGoing  where to_no=" + number;
                if (ADB.ExcuteSQLQuery(sql))
                {
                    if (ADB.GetDataReader.Read())
                    {
                        this.to_no = Convert.ToInt32(ADB.GetDataReader["to_no"]);
                        this.type = (MoneyTransferType)Convert.ToByte(ADB.GetDataReader["to_type"]);

                        this.to_date = Convert.ToDateTime(ADB.GetDataReader["to_date"]);

                        this.to_amount = Convert.ToDecimal(ADB.GetDataReader["to_amount"]);
                        this.to_famount = Convert.ToDecimal(ADB.GetDataReader["to_famount"]);
                        this.to_trans_commation = Convert.ToDecimal(ADB.GetDataReader["to_trans_commation"]);
                        this.to_trans_fcommation = Convert.ToDecimal(ADB.GetDataReader["to_trans_fcommation"]);

                        this.to_reciver_commation = Convert.ToDecimal(ADB.GetDataReader["to_reciver_commation"]);
                        this.to_reciver_fcommation = Convert.ToDecimal(ADB.GetDataReader["to_reciver_fcommation"]);

                        this.to_sender_name = Convert.ToString(ADB.GetDataReader["to_sender_name"]);
                        this.to_reciver_name = Convert.ToString(ADB.GetDataReader["to_reciver_name"]);
                        this.user = new User(Convert.ToByte(ADB.GetDataReader["user_no"]));

                        this.currency = new CurrencyInfo(Convert.ToByte(ADB.GetDataReader["cur_no"]));
                        this.cur_exchange = Convert.ToDecimal(ADB.GetDataReader["cur_exchange"]);
                        this.branch = new BranchInfo(Convert.ToByte(ADB.GetDataReader["branch_no"]));
                        this.dest_branch = new BranchInfo(Convert.ToByte(ADB.GetDataReader["to_dest_branch"]));
                        this.hash = Convert.ToString(ADB.GetDataReader["h"]);

                        this.ogt_v1 = Convert.ToInt32(ADB.GetDataReader["ogt_v1"]);

                        //if (this.hash != this.GetCurrentHASH)
                        //{
                        //    this.exception_info = new Exception();
                        //}

                    }
                    else
                    {
                        if (ADB.ExceptionInfo != null)
                        {
                            this.exception_info = ADB.ExceptionInfo;
                        }
                        else
                        {
                            this.exception_info = new Exception("");
                        }
                    }
                }
                else
                {
                    if (ADB.ExceptionInfo != null)
                    {
                        this.exception_info = ADB.ExceptionInfo;
                    }
                    else
                    {
                        this.exception_info = new Exception("");
                    }
                }

                ADB.CloseConnection();
            }
        }

        public TransferOutGoing(byte[] ar)
        {
            try
            {
                int index = 0;
                int l = 1;
                byte[] art = new byte[1];


                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.dest_branch = new BranchInfo(art);


                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.hash = Encoding.UTF8.GetString(art);


                this.to_no = BitConverter.ToInt32(ar, index);
                index += 4;

                art = new byte[1];
                Array.Copy(ar, index, art, 0, 1);
                index += 1;

                this.type = (MoneyTransferType)art[0];

                this.to_amount = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                this.to_famount = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                this.to_reciver_commation = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                this.to_reciver_fcommation = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                this.to_trans_commation = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                this.to_trans_fcommation = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                this.ogt_v1 = BitConverter.ToInt32(ar, index);
                index += 4;


                this.cur_exchange = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;


                this.to_date = DateTime.FromOADate(BitConverter.ToDouble(ar, index));
                index += 8;

                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.user = new User((art));

                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.branch = new BranchInfo((art));

                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.currency = new CurrencyInfo((art));

                l = BitConverter.ToInt32(ar, index);
                index += 4;


                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.to_sender_name = Encoding.UTF8.GetString(art);


                l = BitConverter.ToInt32(ar, index);
                index += 4;


                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.to_reciver_name = Encoding.UTF8.GetString(art);



                l = BitConverter.ToInt32(ar, index);
                index += 4;

                if (l == 0)
                {
                    this.exception_info = null;
                }
                else
                {
                    art = new byte[l];
                    Array.Copy(ar, index, art, 0, l);
                    index += l;
                    this.exception_info = DeserializeX(art);
                }
            }
            catch (Exception ex)
            {
                this.exception_info = new Exception("");
            }

        }


        public byte[] ToBytes()
        {

            List<byte> ar = new List<byte>();

            int l = this.branch.ToBytes().Count();

            ar.AddRange(BitConverter.GetBytes(l));
            ar.AddRange((this.branch.ToBytes()));


            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.hash).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.hash));

            ar.AddRange(BitConverter.GetBytes(to_no));
            ar.Add(((byte)this.type));

            ar.AddRange(BitConverter.GetBytes((double)to_amount));
            ar.AddRange(BitConverter.GetBytes((double)to_famount));
            ar.AddRange(BitConverter.GetBytes((double)to_reciver_commation));
            ar.AddRange(BitConverter.GetBytes((double)to_reciver_fcommation));
            ar.AddRange(BitConverter.GetBytes((double)to_trans_commation));
            ar.AddRange(BitConverter.GetBytes((double)to_trans_fcommation));

            ar.AddRange(BitConverter.GetBytes(this.ogt_v1));
            

            ar.AddRange(BitConverter.GetBytes((double)this.cur_exchange));

            
            ar.AddRange(BitConverter.GetBytes((double)to_date.ToOADate()));
            
            ar.AddRange(BitConverter.GetBytes(user.ToBytes().Count()));
            ar.AddRange((user.ToBytes()));

            ar.AddRange(BitConverter.GetBytes(this.branch.ToBytes().Count()));
            ar.AddRange((this.branch.ToBytes()));

            ar.AddRange(BitConverter.GetBytes(this.currency.ToBytes().Count()));
            ar.AddRange((this.currency.ToBytes()));

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.to_sender_name).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.to_sender_name));

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.to_reciver_name).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.to_reciver_name));



            if (this.exception_info == null)
            {
                int x = 0;
                ar.AddRange(BitConverter.GetBytes(x));
            }
            else
            {
                byte[] e = SerializeX(this.exception_info);
                ar.AddRange(BitConverter.GetBytes(e.Length));
                ar.AddRange(e);
            }
            return ar.ToArray();
        }



        private byte[] HashBytes()
        {
            List<byte> ar = new List<byte>();

            ar.AddRange(BitConverter.GetBytes(to_no));
            ar.Add(((byte)this.type));

            ar.AddRange(BitConverter.GetBytes((double)Amount));
            ar.AddRange(BitConverter.GetBytes((double)FAmount));
            ar.AddRange(BitConverter.GetBytes((double)OutGoingTransferReciverCommation));
            ar.AddRange(BitConverter.GetBytes((double)OutGoingTransferReciverFCommation));
            ar.AddRange(BitConverter.GetBytes((double)OutGoingTransferCommation));
            ar.AddRange(BitConverter.GetBytes((double)OutGoingTransferFCommation));

            ar.AddRange(BitConverter.GetBytes(this.ogt_v1));

            ar.AddRange(BitConverter.GetBytes((int)this.UserInfo.Number));
            ar.AddRange(BitConverter.GetBytes((int)this.branch.BranchNumber));
            ar.AddRange(BitConverter.GetBytes((int)this.dest_branch.BranchNumber));

            ar.AddRange(BitConverter.GetBytes((int)this.currency.CurrencyNumber));
            ar.AddRange(BitConverter.GetBytes((double)this.Exchange));

           // ar.AddRange(BitConverter.GetBytes((double)to_date.ToOADate()));

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.to_sender_name).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.to_sender_name));

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.to_reciver_name).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.to_reciver_name));

            return ar.ToArray();

        }


        private Exception DeserializeX(byte[] ar)
        {

            Stream stream = new MemoryStream(ar);
            BinaryFormatter formatter = new BinaryFormatter();
            Exception ex = (Exception)formatter.Deserialize(stream);
            stream.Close();

            return ex;

        }

        private static byte[] SerializeX<T>(T obj)
        {
            using (MemoryStream memStream = new MemoryStream())
            {
                BinaryFormatter binSerializer = new BinaryFormatter();
                binSerializer.Serialize(memStream, obj);
                return memStream.ToArray();
            }
        }


        public TransferOutGoing(int to_no, MoneyTransferType type, DateTime to_date, decimal to_amount, decimal to_famount, decimal to_trans_commation, decimal to_reciver_commation, string to_sender_name, string to_reciver_name, User user, CurrencyInfo currency, decimal cur_exchange, decimal to_trans_fcommation, decimal to_reciver_fcommation,BranchInfo branch,BranchInfo dest,string hash = null)
        {

            this.to_no = to_no;
            this.type = type;
            this.to_date = to_date;
          
            this.to_amount = to_amount;
            this.to_famount = to_famount;
            this.to_trans_commation = to_trans_commation;
            this.to_trans_fcommation = to_trans_fcommation;
           
            this.to_reciver_commation = to_reciver_commation;
            this.to_reciver_fcommation = to_reciver_fcommation;
            this.user = user;
            this.to_sender_name = to_sender_name;
            this.to_reciver_name = to_reciver_name;
            this.currency = currency;
            this.cur_exchange = cur_exchange;
        
            this.branch = branch;
            this.dest_branch = dest;

            if (hash != null)
            {
                this.hash = hash;
            }
            else
            {
                this.hash = this.GetCurrentHASH;
            }


        }

        public int Number
        {
            get
            {
                return this.to_no;
            }
            set
            {
                this.to_no = value;
            }
        }

        public MoneyTransferType Type
        {
            get
            {
                return this.type;
            }
            set
            {
                this.type = value;
            }
        }

        public DateTime Date
        {
            get
            {
                return this.to_date;
            }
            set
            {
                this.to_date = value;
            }
        }

        public decimal Amount
        {
            get
            {
                return Math.Round(this.to_amount, 4);
            }
            set
            {
                this.to_amount = Math.Round(value,4);
            }
        }

        public decimal FAmount
        {
            get
            {
                return Math.Round(this.to_famount,4);
            }
            set
            {
                this.to_famount = Math.Round(value,4);
            }
        }

        public decimal OutGoingTransferCommation
        {
            get
            {
                return Math.Round(this.to_trans_commation,4);
            }
            set
            {
                this.to_trans_commation = Math.Round(value,4);
            }
        }

        public decimal OutGoingTransferFCommation
        {
            get
            {
                return Math.Round(this.to_trans_fcommation,4);
            }
            set
            {
                this.to_trans_fcommation = Math.Round(value,4);
            }
        }

        public decimal OutGoingTransferReciverCommation
        {
            get
            {
                return Math.Round(this.to_reciver_commation,4);
            }
            set
            {
                this.to_reciver_commation = Math.Round(value,4);
            }
        }

        public decimal OutGoingTransferReciverFCommation
        {
            get
            {
                return Math.Round(this.to_reciver_fcommation,4);
            }
            set
            {
                this.to_reciver_fcommation = Math.Round(value,4);
            }
        }

        public string SenderName
        {
            get
            {
                return this.to_sender_name;
            }
            set
            {
                this.to_sender_name = value;
            }
        }

        public string ReciverName
        {
            get
            {
                return this.to_reciver_name;
            }
            set
            {
                this.to_reciver_name = value;
            }
        }


        public User UserInfo
        {
            get
            {
                return this.user;
            }
            set
            {
                this.user = value;
            }
        }

        public CurrencyInfo Currency
        {
            get
            {
                return this.currency;
            }
            set
            {
                this.currency = value;
            }
        }

        public decimal Exchange
        {
            get
            {
                return Math.Round(this.cur_exchange,4);
            }
            set
            {
                this.cur_exchange = Math.Round(value,4);
            }
        }

      
        public int OV_1
        {
            get
            {
                return this.ogt_v1;
            }
            set
            {
                this.ogt_v1 = value;
            }
        }


        public BranchInfo Branch
        {
            get
            {
               return this.branch;
            }
            set
            {
                this.branch = value;
            }
        }


        public BranchInfo DestinationBranch
        {
            get
            {
                return this.dest_branch;
            }
            set
            {
                this.dest_branch = value;
            }
        }

        public Exception ExceptionInfo
        {
            get
            {
                return this.exception_info;
            }
            set
            {
                this.exception_info = value;
            }
        }

        private string GetMD5Hash(byte[] ar)
        {

            using (MD5 md5Hash = MD5.Create())
            {
                // Convert the input string to a byte array and compute the hash. 
                byte[] data = md5Hash.ComputeHash(ar);

                StringBuilder sBuilder = new StringBuilder();

                // Loop through each byte of the hashed data  
                // and format each one as a hexadecimal string. 
                for (int i = 0; i < data.Length; i++)
                {
                    sBuilder.Append(data[i].ToString("x2"));
                }

                // Return the hexadecimal string. 
                return sBuilder.ToString();

            }
        }

        public string GetCurrentHASH
        {
            get
            {
                return this.GetMD5Hash(this.HashBytes());
            }
        }

        public string GetHash
        {
            get
            {
                return this.hash;
            }
        }
    }


    internal static class TransferOutGoingManager
    {
        //static int[] tr = new int(){10000000};

        static int x = GenerateNewTransctionID2();

        public static bool CreateNewOutGoingTransction(TransferOutGoing ogt)
        {
            bool res = false;
            
            lock (Utilities.mylocker)
            {
                try
                {

                    ADataBase db = new ADataBase();

                    //string hash = ogt.GetCurrentHASH;

                    string sql = @"insert into tblTransferOutGoing (to_no,to_type,to_date,to_amount,to_famount,to_trans_commation,to_reciver_commation,to_sender_name,to_reciver_name,user_no,cur_no,cur_exchange,to_trans_fcommation,to_reciver_fcommation,ogt_v1,branch_no,h,to_dest_branch)values(" + ogt.Number + "," + (byte)ogt.Type + ",'" + ogt.Date + "'," + ogt.Amount + "," + ogt.FAmount + "," + ogt.OutGoingTransferCommation + "," + ogt.OutGoingTransferReciverCommation + ",'" + ogt.SenderName + "','" + ogt.ReciverName + "'," + ogt.UserInfo.Number + "," + ogt.Currency.CurrencyNumber + "," + ogt.Exchange + "," + ogt.OutGoingTransferFCommation + "," + ogt.OutGoingTransferReciverFCommation + "," + ogt.OV_1 + "," + ogt.Branch.BranchNumber + ",'" + ogt.GetHash + "'," + ogt.DestinationBranch.BranchNumber + ")";

                    if (db.ExcuteSQLNonQuery(sql) == 1)
                    {
                        //LogManager.CreateNewEvent(new Log(new MSGINFO(0, "تم إضافة الحوالة"), ogt.Branch, ogt.UserInfo, DateTime.Now));
                        res = true;

                    }
                    else
                    {
                        throw new Exception("");
                    }

                }
                catch (Exception ex)
                {
                    ogt.ExceptionInfo = ex;
                }
            }
            return res;
        }


        //internal static int GenerateNewTransctionID()
        //{
        //    lock (Utilities.mylocker)
        //    {
        //        int res = 1;
        //        try
        //        {
        //            ADataBase ADB = new ADataBase();

        //            string sql = "select (max(to_no)+1) as res from tblTransferOutGoing";
        //            if (ADB.ExcuteSQLQuery(sql))
        //            {
        //                if (ADB.GetDataReader.Read())
        //                {
        //                    res = Convert.ToInt32(ADB.GetDataReader["res"].ToString());
        //                }
        //            }
        //            ADB.CloseConnection();
        //        }
        //        catch
        //        {
        //            res = 1;
        //        }


        //        return res;
        //    }
        //}

        internal static int GenerateNewTransctionID()
        {
            lock (Utilities.mylocker)
            {
                return ++x;

                int res = 10000000;
                try
                {
                    ADataBase ADB = new ADataBase();

                    string sql = "select (max(to_no)+1) as res from tblTransferOutGoing";
                    if (ADB.ExcuteSQLQuery(sql))
                    {
                        if (ADB.GetDataReader.Read())
                        {
                            res = Convert.ToInt32(ADB.GetDataReader["res"].ToString());
                        }
                    }
                    ADB.CloseConnection();
                }
                catch
                {
                    //res = -1;
                }


                return res;
            }
        }

        internal static int GenerateNewTransctionID2()
        {
            lock (Utilities.mylocker)
            {
                
                int res = 10000000;
               
                try
                {
                    ADataBase ADB = new ADataBase();

                    string sql = "select (max(to_no)+1) as res from tblTransferOutGoing";
                    if (ADB.ExcuteSQLQuery(sql))
                    {
                        if (ADB.GetDataReader.Read())
                        {
                            res = Convert.ToInt32(ADB.GetDataReader["res"].ToString());
                        }
                    }
                    ADB.CloseConnection();
                }
                catch
                {
                   // res = 1;
                }


                return res;
            }
        }


        public static bool UpdateOutGoingTransction(TransferOutGoing ogt)
        {
            bool res = false;
            return res;
        }

        public static bool DeleteOutGoingTransction(TransferOutGoing ogt)
        {
            bool res = false;
            return res;
        }
    }
}
