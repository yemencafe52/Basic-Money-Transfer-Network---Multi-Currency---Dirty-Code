﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace YMT
{
    public partial class frmStationManager : Form
    {
        private bool op;
        private Station station = null;

        public frmStationManager()
        {
            InitializeComponent();
        }

        public frmStationManager(Station station)
        {
            InitializeComponent();
            this.station = station;
        }

        private void DisplayInfo(Station station)
        {
            DisableALL();
            button8.Enabled = true;
            button6.Enabled = true;

            comboBox1.SelectedValue = station.Branch.BranchNumber;
            textBox1.Text = station.Name;
            textBox2.Text = station.Password;

            if (station.State == StationState.ENABLE)
            {
                checkBox2.Checked = true;
            }
            else
            {
                checkBox2.Checked = false;
            }
        }


        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {  
            if (keyData == (Keys.Control | Keys.N))
            {
                button9.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.E))
            {
                button8.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.S))
            {
                button7.PerformClick();
                return true;
            }

           

            if (keyData == (Keys.Shift | Keys.Escape))
            {
                if (button7.Enabled)
                {
                    button6.PerformClick();
                }
                else
                {
                    this.Close();
                }
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }


        private void frmStationManager_Load(object sender, EventArgs e)
        {
            List<BranchInfo> branchies = BranchInfoManager.GetALLBranchInfo();

            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.DisplayMember = "BranchNumber";
            comboBox1.ValueMember = "BranchNumber";
            comboBox1.DataSource = branchies;

            if (comboBox1.Items.Count > 0)
            {
                comboBox1.SelectedIndex = 0;
            }

            if (this.station != null)
            {
                DisplayInfo(this.station);
            }
            else
            {
                DisableALL();
                button9.Enabled = true;
                button6.Enabled = true;
            }

           
        }

        private void button9_Click(object sender, EventArgs e)
        {
            AddNew();
        }

        private void AddNew()
        {
            DisableALL();
            button6.Enabled = true;
            button7.Enabled = true;
            textBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Enabled = true;

            button2.Enabled = true;
            comboBox1.Enabled = true;
            
          
            op = true;
            textBox1.Focus();
          
        }

        private void Save()
        {
            try
            {
                if (Server.IsRunning)
                {
                    MessageBox.Show("يجب إيقاف السيرفر أولاً.", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                    return;
                }

                if (string.IsNullOrEmpty(textBox1.Text))
                {
                    textBox1.Focus();
                    return;
                }

                if (string.IsNullOrEmpty(textBox2.Text))
                {
                    textBox2.Focus();
                    return;
                }

                
                if (op)
                {
                    if (string.IsNullOrEmpty(textBox3.Text))
                    {
                        textBox3.Focus();
                        return;
                    }

                    FileStream fs = new FileStream(textBox3.Text, FileMode.Open);
                    long size = fs.Length;
                    byte[] ar = new byte[size];
                    fs.Read(ar, 0, ar.Length);
                    fs.Close();

                    string id = Convert.ToBase64String(ar);
                    string hash = Utilities.GetMD5Hash(id);

                    BranchInfo branch = new BranchInfo(byte.Parse(comboBox1.SelectedValue.ToString()));

                    Station station = new Station(branch, hash, textBox1.Text, textBox2.Text);
                    station.State = StationState.ENABLE;


                    if (StationManager.CreateNewStation(station))
                    {
                        Reset();
                        MessageBox.Show("تمت العملية بنجاح  .", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                    }
                    else
                    {
                        MessageBox.Show("تعذر على النظام تنفيذ العملية  .", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                    }
                }
                else
                {
                    //Station station = new Station(new byte[]{33,33,33});

                    if (checkBox2.Checked)
                    {
                        this.station.State = StationState.ENABLE;
                    }
                    else
                    {
                        this.station.State = StationState.DISABLE;
                    }

                    Station s = new Station(this.station.Branch, this.station.HWID,textBox1.Text,textBox2.Text, this.station.Number, this.station.State);
                   
                    if (StationManager.UpdateStation(s))
                    {
                        Reset();
                        MessageBox.Show("تمت العملية بنجاح  .", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                    }
                    else
                    {
                        MessageBox.Show("تعذر على النظام تنفيذ العملية  .", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                    }
                }
            }

            catch
            {
                MessageBox.Show("تعذر على النظام تنفيذ العملية  .", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
            }
        }


        private void DisableALL()
        {


            button2.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = false;
            button2.Enabled = false;
            comboBox1.Enabled = false;

            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            checkBox2.Enabled = false;
          
        }

        private void Delete()
        {
            return;
        }

        private void Update()
        {

            DisableALL();
            button6.Enabled = true;
            button7.Enabled = true;
            textBox1.Enabled = true;
            textBox2.Enabled = true;
           
            checkBox2.Enabled = true ;
            op = false;

            textBox1.Focus();
        }


        private void Reset()
        {
            DisableALL();
           
            button9.Enabled = true;
            button8.Enabled = true;


        }

        private void button8_Click(object sender, EventArgs e)
        {
            Update();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Save();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
          
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.FileName = "YMT"; // Default file name
            dlg.DefaultExt = ".bin"; // Default file extension
            dlg.Filter = "YMT (.bin)|*.bin"; // Filter files by extension 

            // Show open file dialog box
            DialogResult res = dlg.ShowDialog();

            // Process open file dialog box results 
            if (res == System.Windows.Forms.DialogResult.OK)
            {
                 textBox3.Text  = dlg.FileName;
            }
        }

        

    }
}
