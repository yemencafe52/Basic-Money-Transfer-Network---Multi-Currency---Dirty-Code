﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YMT
{
    public partial class frmBranchInfo : Form
    {
        bool op = false;
        private BranchInfo branch = null;

        public frmBranchInfo()
        {
            InitializeComponent();
        }

        public frmBranchInfo(BranchInfo b)
        {
            InitializeComponent();
            this.branch = b;
        }


        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {

            if (keyData == (Keys.Control | Keys.F))
            {
                //bindingNavigator3.Focus();
                return true;
            }

            if (keyData == (Keys.Control | Keys.N))
            {
                button9.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.E))
            {
                button8.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.S))
            {
                button7.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.Delete))
            {
                button1.PerformClick();
                return true;
            }

            if (keyData == (Keys.Shift | Keys.Escape))
            {
                if (button7.Enabled)
                {
                    button6.PerformClick();
                }
                else
                {
                    this.Close();
                }
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }


        private void frmBranchInfo_Load(object sender, EventArgs e)
        {
            Inti();

            if (this.branch != null)
            {
                DisplayInfo(this.branch);
            }
        }

        private void ClearALL()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            
            textBox5.Text = "";
            numericUpDown1.Value = 0;
            

        }

        private void DisableALL()
        {
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox5.Enabled = false;

            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = false;
            numericUpDown1.Enabled = false;
            

            linkLabel1.Enabled = false;

        }

        private void Update()
        {
            DisableALL();
            
            textBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Enabled = true;
            textBox5.Enabled = true;

            button6.Enabled = true;
            button7.Enabled = true;
            linkLabel1.Enabled = true;
            op = false;
        }

        private void Save()
        {
            //if(string.IsNullOrEmpty(textBox1.Text))
            //{
            //    textBox1.Focus();
            //    return;
            //}

            if (Server.IsRunning)
            {
                MessageBox.Show("يجب إيقاف السيرفر أولاً.", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                return;
            }

            if (op)
            {
                BranchInfo b = new BranchInfo((byte)numericUpDown1.Value,textBox1.Text,textBox2.Text,textBox3.Text,textBox5.Text);
                b.BranchName = textBox1.Text;
                b.BranchAddress = textBox2.Text;
                b.BranchPhone = textBox3.Text;
                b.BrancMobile = textBox5.Text;
                b.BranchFlag = pictureBox1.Image;

                if (BranchInfoManager.CreateNewBranch(b))
                {
                    MessageBox.Show("تمت العملية بنجاح  .", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                    Inti();
                }
                else
                {
                    MessageBox.Show("تعذر على النظام تنفيذ العملية  .", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                }
            }
            else
            {
                BranchInfo b = new BranchInfo((byte)numericUpDown1.Value);
                b.BranchName = textBox1.Text;
                b.BranchAddress = textBox2.Text;
                b.BranchPhone = textBox3.Text;
                b.BrancMobile = textBox5.Text;
                b.BranchFlag = pictureBox1.Image;

                if (BranchInfoManager.UpdateBranchInfo(b))
                {
                    MessageBox.Show("تمت العملية بنجاح  .", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                    Inti();
                }
                else
                {
                    MessageBox.Show("تعذر على النظام تنفيذ العملية  .", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                }
            }
        }

        private void Cancel()
        {
            this.Close();
            //Inti();
        }

        private void Inti()
        {

            DisableALL();
           
            button9.Enabled = true;
            button8.Enabled = true;
           
        }

        private void DisplayInfo(BranchInfo b)
        {

            DisableALL();
            button8.Enabled = true;
            numericUpDown1.Value = b.BranchNumber;
            textBox1.Text = b.BranchName;
            textBox2.Text = b.BranchAddress;
            textBox3.Text = b.BranchPhone;
            textBox5.Text = b.BrancMobile;
            pictureBox1.Image = b.BranchFlag;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Update();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Save();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Cancel();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {

                OpenFileDialog ofd = new OpenFileDialog();
                
                
                ofd.Filter =
                    "صورة  (*.jpg)|*.jpg";
                ofd.InitialDirectory =
                    Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

                
                DialogResult result = ofd.ShowDialog();


                if (result == DialogResult.OK)
                {
                    pictureBox1.Load(ofd.FileNames[0]);
                }         
            }
            catch
            {
                MessageBox.Show("تعذر تغيير الشعار .", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            AddNew();
        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void AddNew()
        {
            
            DisableALL();
            ClearALL();
            textBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Enabled = true;
            textBox5.Enabled = true;

            button6.Enabled = true;
            button7.Enabled = true;
            linkLabel1.Enabled = true;
            numericUpDown1.Value = (decimal)BranchInfoManager.GenerateNewBranchNumber();
            op = true;
        }

    }
}
