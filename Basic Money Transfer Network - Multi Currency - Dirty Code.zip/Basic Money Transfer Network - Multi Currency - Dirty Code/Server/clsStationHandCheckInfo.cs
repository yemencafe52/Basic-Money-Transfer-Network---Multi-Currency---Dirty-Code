﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace YMT
{
    class StationHandCheckInfo
    {
        private string network_name;
        private string ip;
        private Station station;
        private Exception exception =null;
     
        public StationHandCheckInfo(string nn,string ip,Station station)
        {
            this.network_name = nn;
            this.ip = ip;
            this.station = station;
        }

        public string NetworkName
        {
            get
            {
                return this.network_name;
            }
        }

        public string DNS
        {
            get
            {
                return this.ip;
            }
        }

        public Exception ExceptionInfo
        {
            get
            {
                return this.exception;
            }
        }

        public Station StationInfo
        {
            get
            {
                return this.station;
            }
        }

        public StationHandCheckInfo(byte[] ar)
        {
            try
            {
                int index = 0;
                byte[] art = new byte[0];
                int l = 0;

                l = BitConverter.ToInt32(ar, index);
                index += 4;

                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.network_name = Encoding.UTF8.GetString(art);

                l = BitConverter.ToInt32(ar, index);
                index += 4;

                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.ip = Encoding.UTF8.GetString(art);

                l = BitConverter.ToInt32(ar, index);
                index += 4;

                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.station = new Station(art);


                l = BitConverter.ToInt32(ar, index);
                index += 4;

                if (l == 0)
                {
                    this.exception = null;
                }
                else
                {
                    art = new byte[l];
                    Array.Copy(ar, index, art, 0, l);
                    index += l;
                    this.exception = DeserializeX(art);
                }

            }
            catch
            {
                this.network_name = "";
                this.ip = "";
                this.station = null;
                this.exception = new Exception("");
            }

        }

        public byte[] ToBytes()
        {
            List<byte> ar = new List<byte>();

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.network_name).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.network_name));

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.ip).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.ip));


            ar.AddRange(BitConverter.GetBytes((this.station.ToBytes().Count())));
            ar.AddRange(((this.station.ToBytes())));

            if (this.exception == null)
            {
                int x = 0;
                ar.AddRange(BitConverter.GetBytes(x));
            }
            else
            {
                byte[] e = SerializeX(this.exception);
                ar.AddRange(BitConverter.GetBytes(e.Length));
                ar.AddRange(e);
            }

            return ar.ToArray();

        }

        private Exception DeserializeX(byte[] ar)
        {

            Stream stream = new MemoryStream(ar);
            BinaryFormatter formatter = new BinaryFormatter();
            Exception ex = (Exception)formatter.Deserialize(stream);
            stream.Close();

            return ex;
        }

        private static byte[] SerializeX<T>(T obj)
        {
            using (MemoryStream memStream = new MemoryStream())
            {
                BinaryFormatter binSerializer = new BinaryFormatter();
                binSerializer.Serialize(memStream, obj);
                return memStream.ToArray();
            }
        }
    }
}
