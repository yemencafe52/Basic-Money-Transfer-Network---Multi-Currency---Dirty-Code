﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace YMT
{
    public partial class frmLogin : Form
    {
        private bool is_logined = false;
        private int counter = 0;
        private string sw = "";
       // private User user;

        internal bool IsLogined
        {
            get
            {
                return this.is_logined;
            }
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {

            if (keyData == (Keys.Shift | Keys.Escape))
            {

                this.Close();
                return true;

            }

            if (keyData == (Keys.Shift | Keys.S))
            {
                if (this.sw.Length == 0)
                {
                    this.sw += "S";
                    return true;
                }
            }

            if (keyData == (Keys.Shift | Keys.H))
            {

                this.sw += "H";
                return true;
            }

            if (keyData == (Keys.Shift | Keys.O))
            {

                this.sw += "O";
                return true;
            }

            if (keyData == (Keys.Shift | Keys.W))
            {

                this.sw += "W";
                return true;
            }

            if (keyData == (Keys.Shift | Keys.Space))
            {

                this.sw += "_";
                return true;
            }


            if (keyData == (Keys.Shift | Keys.S))
            {

                this.sw += "S";
                return true;
            }

            if (keyData == (Keys.Shift | Keys.I))
            {

                this.sw += "I";
                return true;
            }

            if (keyData == (Keys.Shift | Keys.D))
            {

                this.sw += "D";

                if (this.sw == "SHOW_SID")
                {
                    //button4.Visible = true;
                }

                return true;
            }




            return base.ProcessCmdKey(ref msg, keyData);
        }

        //internal User GetUser
        //{
        //    get
        //    {
        //        return this.user;
        //    }
        //}


        public frmLogin()
        {
            InitializeComponent();

        }

        public frmLogin(bool reLogin)
        {
            InitializeComponent();
            
        }


        private void frmLogin_Load(object sender, EventArgs e)
        {
            comboBox1.Text = DateTime.Now.Year.ToString();
            button1.Focus();
            //Utilities.ReadAU(Application.StartupPath + "\\dat.auf");
            comboBox2.SelectedIndex = 0;
           
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            //if (string.IsNullOrEmpty(comboBox1.Text))
            //{
            //    MessageBox.Show("الرجاء إدخال  السنة المالية .", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
            //    comboBox1.Focus();
            //    return;
            //}

            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("الرجاء إدخال اسم المستخدم.", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                textBox1.Focus();
                return;
            }

            if (string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("الرجاء إدخال  كلمة المرور.", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                textBox2.Focus();
                return;
            }

            //if (!(numericUpDown1.Value > 0))
            //{
            //    MessageBox.Show("الرجال ادخل رقم الفرع.", " ", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
            //    return;
            //}

            BranchInfo branch = new BranchInfo(1);

            //if(branch.ExceptionInfo != null)
            //{
            //    MessageBox.Show("رقم الفرع غير صحيح.", " ", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
            //    return;
            //}

            BranchInfoManager.GetBranchInfo = branch;

            //int p = 0;

            //if (!(int.TryParse((comboBox1.Text),out p)))
            //{
            //    MessageBox.Show("تعذر على النظام قراءة بيانات السنة المالية..", " ", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
            //    return;
            //}

            if ((Users.Login(textBox1.Text, textBox2.Text, ref Utilities.user)))
            {
                this.is_logined = true;
                this.Close();
            }
            else
            {
                counter++;
                if (counter >= 3)
                {
                    MessageBox.Show("غير مخول لك بالولوج .", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("اسم المستخدم أو كلمة المرور غير صحيحة .", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                }
            }


        }

        private void comboBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == '\b')
            {
                e.Handled = false;
                return;
            }

            if (!(char.IsDigit(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        //private void button4_Click(object sender, EventArgs e)
        //{

        //    try
        //    {
        //        // Configure save file dialog box
        //        SaveFileDialog dlg = new SaveFileDialog();
        //        dlg.FileName = "YMS"; // Default file name
        //        dlg.DefaultExt = ".bin"; // Default file extension
        //        dlg.Filter = "YMS INFO (.bin)|*.bin"; // Filter files by extension 

        //        // Show save file dialog box
        //        DialogResult res = dlg.ShowDialog();

        //        // Process save file dialog box results 
        //        if (res == System.Windows.Forms.DialogResult.OK)
        //        {
        //            // Save document 
        //            string filename = dlg.FileName;
        //            FileStream fs = new FileStream(filename, FileMode.OpenOrCreate);
        //            byte[] ar = FingerPrint.Hash();
        //            fs.Write(ar, 0, ar.Length);
        //            fs.Close();

        //            MessageBox.Show("SID has been saved succssfuly", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //        }
                
        //    }
        //    catch
        //    {
        //        MessageBox.Show("Falied to save SID", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //    }

        //}

        ////private void button3_Click(object sender, EventArgs e)
        //{
        //    ReadInfo();
        //}

        //private void ReadInfo()
        //{
        //    if (Utilities.ReadAU(Application.StartupPath + "\\dat.auf"))
        //    {
        //        comboBox2.Enabled = false;
        //        comboBox2.DataSource = null;
        //        comboBox2.Items.Clear();
        //        List<StationHandCheckInfo> shc = new List<StationHandCheckInfo>();
        //        shc.Add(Utilities.SHC);
               
        //        comboBox2.ValueMember = "DNS";
        //        comboBox2.DisplayMember = "NetworkName";
        //        comboBox2.DataSource = shc;

        //        if (comboBox2.Items.Count > 0)
        //        {
        //            comboBox2.Enabled = true;
        //            comboBox2.SelectedIndex = 0;

        //        }

        //    }
        //    else
        //    {
        //        MessageBox.Show(" تعذر على النظام قراءة البيانات", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //    }
        //}

        //private void frmLogin_Shown(object sender, EventArgs e)
        //{
        //    ReadInfo();
        //}
    }
}
