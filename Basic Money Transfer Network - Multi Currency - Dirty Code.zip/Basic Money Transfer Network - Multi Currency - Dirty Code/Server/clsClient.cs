﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;
using System.Net.Sockets;

namespace YMT
{

    public class SocketCommender
    {

        internal bool CheckConnection(IPAddress ip)
        {
            bool res = false;

            try
            {
                Socket s = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                s.Connect(ip, 888);
                s.Close();
                res = true;

            }
            catch
            {

            }
            return res;
        }

        internal bool GetObject(Command cmd, ref byte[] data)
        {
            bool res = false;
            int revbyte = 0;
            int revtotal = 0;
            int bf_size = 0;

            byte[] buffer = new byte[1024];

            List<byte> packge = new List<byte>();

            try
            {

                Socket s = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                try
                {
                    s.Connect(Utilities.ip, 888);

                    buffer = new byte[1024 * 8];


                    s.Send(new SecPacket(new Packet(cmd), Utilities.SHC.StationInfo.Password).ToBytes(Utilities.SHC.StationInfo.Number));
                    s.ReceiveTimeout = 30000;

                    while (s.Connected)
                    {
                        revbyte = s.Receive(buffer);

                        if (revbyte == 0)
                        {
                            throw new Exception();
                        }

                        revtotal += revbyte;

                        byte[] art = new byte[revbyte];
                        Array.Copy(buffer, 0, art, 0, revbyte);

                        packge.AddRange(art);

                        if (packge.Count >= 8)
                        {
                            bf_size = BitConverter.ToInt32(buffer, 0);

                            byte[] bf = new byte[bf_size];

                            packge.CopyTo(0, bf, 0, bf_size);

                            packge.RemoveRange(0, bf_size);

                            SecPacket sp = new SecPacket(bf, Utilities.SHC.StationInfo.Password);

                            Packet packet = sp.PlanPacket();

                            switch (packet.GetCommand.GetCommandType)
                            {
                                case CommandType.HandCheck:
                                    {
                                        break;
                                    }

                                case CommandType.Logined:
                                    {
                                        if (Utilities.user != null)
                                        {

                                            s.Send(new Packet(cmd).PacketToBytes());

                                            break;
                                        }
                                        else
                                        {
                                            res = true;
                                            data = packet.GetCommand.GetParametersInfo[0].GetBytesArray;
                                            s.Send(new Packet(new Command(CommandType.Logout)).PacketToBytes());
                                            s.Close();
                                            break;
                                        }

                                    }

                                case CommandType.BranchInfo:
                                    {
                                        res = true;
                                        data = packet.GetCommand.GetParametersInfo[0].GetBytesArray;
                                        s.Send(new Packet(new Command(CommandType.Logout)).PacketToBytes());
                                        s.Close();
                                        break;
                                    }


                                case CommandType.UpdateMoneyTransction:
                                    {
                                        res = true;
                                        data = packet.GetCommand.GetParametersInfo[0].GetBytesArray;
                                        s.Send(new Packet(new Command(CommandType.Logout)).PacketToBytes());
                                        s.Close();
                                        break;
                                    }

                                case CommandType.IncomingTransction:
                                    {
                                        res = true;
                                        data = packet.GetCommand.GetParametersInfo[0].GetBytesArray;
                                        s.Send(new Packet(new Command(CommandType.Logout)).PacketToBytes());
                                        s.Close();
                                        break;
                                    }

                                case CommandType.EndPing:
                                    {
                                        res = true;
                                        data = packet.GetCommand.GetParametersInfo[0].GetBytesArray;
                                        s.Send(new Packet(new Command(CommandType.Logout)).PacketToBytes());
                                        s.Close();
                                        break;
                                    }


                                case CommandType.GetCurrencyALLInfo:
                                    {
                                        res = true;
                                        data = packet.GetCommand.GetParametersInfo[0].GetBytesArray;
                                        s.Send(new Packet(new Command(CommandType.Logout)).PacketToBytes());
                                        s.Close();
                                        break;
                                    }

                                case CommandType.GetALLBranchies:
                                    {
                                        res = true;
                                        data = packet.GetCommand.GetParametersInfo[0].GetBytesArray;
                                        s.Send(new Packet(new Command(CommandType.Logout)).PacketToBytes());
                                        s.Close();
                                        break;
                                    }


                                case CommandType.AddNewMoneyTransction:
                                    {
                                        res = true;
                                        data = packet.GetCommand.GetParametersInfo[0].GetBytesArray;
                                        s.Send(new Packet(new Command(CommandType.Logout)).PacketToBytes());
                                        s.Close();
                                        break;
                                    }

                                case CommandType.NewTransctionID:
                                    {
                                        res = true;
                                        data = packet.GetCommand.GetParametersInfo[0].GetBytesArray;
                                        s.Send(new Packet(new Command(CommandType.Logout)).PacketToBytes());
                                        s.Close();
                                        break;
                                    }


                                case CommandType.CurrencyInfo:
                                    {
                                        res = true;
                                        data = packet.GetCommand.GetParametersInfo[0].GetBytesArray;
                                        s.Send(new Packet(new Command(CommandType.Logout)).PacketToBytes());
                                        s.Close();
                                        break;
                                    }

                                case CommandType.Commission:
                                    {
                                        res = true;
                                        data = packet.GetCommand.GetParametersInfo[0].GetBytesArray;
                                        s.Send(new Packet(new Command(CommandType.Logout)).PacketToBytes());
                                        s.Close();
                                        break;
                                    }

                                case CommandType.CommissionByInfo:
                                    {
                                        res = true;
                                        data = packet.GetCommand.GetParametersInfo[0].GetBytesArray;
                                        s.Send(new Packet(new Command(CommandType.Logout)).PacketToBytes());
                                        s.Close();
                                        break;
                                    }


                                case CommandType.MonyTransferInfo:
                                    {
                                        res = true;
                                        data = packet.GetCommand.GetParametersInfo[0].GetBytesArray;
                                        s.Send(new Packet(new Command(CommandType.Logout)).PacketToBytes());
                                        s.Close();
                                        break;
                                    }

                            }

                        }

                    }

                }
                catch
                {
                    data = new byte[1];
                    res = false;
                }

            }
            catch
            {
                data = new byte[1];
            }

            return res;
        }

    }

}
