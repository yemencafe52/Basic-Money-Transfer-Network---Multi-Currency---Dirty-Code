﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.IO;
using System.Data.OleDb;

using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;


namespace YMT
{
    public class BranchInfo
    {
        private byte branch_no;
        private string branch_name;
        private string branch_address;
        private string branch_phone;
        private string branch_mobile;
        private Image branch_flag;
        private Exception exception_info = null;

        public byte BranchNumber
        {
            get
            {
                return this.branch_no;
            }
            set
            {
                this.branch_no = value;
            }
        }

        public string BranchName
        {
            get
            {
                return this.branch_name;
            }
            set
            {
                this.branch_name = value;
            }
        }

        public string BranchAddress
        {
            get
            {
                return this.branch_address;
            }
            set
            {
                this.branch_address = value;
            }
        }

        public string BranchPhone
        {
            get
            {
                return this.branch_phone;
            }
            set
            {
                this.branch_phone = value;
            }
        }

        public string BrancMobile
        {
            get
            {
                return this.branch_mobile;
            }
            set
            {
                this.branch_mobile = value;
            }
        }

        public Image BranchFlag
        {
            get
            {
                return this.branch_flag;
            }
            set
            {
                this.branch_flag = value;
            }
        }

        public Exception ExceptionInfo
        {
            get { return this.exception_info; }
            set
            {
                this.exception_info = value;
            }

        }

        public BranchInfo(byte number,string branch_name,string branch_address,string branch_phone,string branch_mobile,byte[] branch_flag = null)
        {
            this.branch_no = number;
            this.branch_name = branch_name;
            this.branch_address = branch_address;
            this.branch_phone = branch_phone;
            this.branch_mobile = branch_mobile;
            //this.branch_flag = new Bitmap(new Stream(branch_flag));
        }

        public BranchInfo(byte number)
        {

            lock (Utilities.mylocker)
            {
                try
                {
                    ADataBase ADB = new ADataBase();

                    string sql = @"select branch_no,branch_name,branch_address,branch_phone,branch_mobile,branch_flag from tblBranchInfo where branch_no=" + number;
                    if (ADB.ExcuteSQLQuery(sql))
                    {
                        if (ADB.GetDataReader.Read())
                        {
                            this.branch_no = Convert.ToByte(ADB.GetDataReader["branch_no"]);
                            this.branch_name = Convert.ToString(ADB.GetDataReader["branch_name"]);
                            this.branch_address = Convert.ToString(ADB.GetDataReader["branch_address"]);
                            this.branch_phone = Convert.ToString(ADB.GetDataReader["branch_phone"]);
                            this.branch_mobile = Convert.ToString(ADB.GetDataReader["branch_mobile"]);
                           // byte[] img = (byte[])ADB.GetDataReader["branch_flag"];

                            try
                            {
                               // MemoryStream ms = new MemoryStream(img);
                               // this.branch_flag = new Bitmap(ms);
                            }
                            catch
                            {

                            }

                        }
                        else
                        {
                           throw new Exception();
                        }
                    }
                    else
                    {
                        throw new Exception();
                    }

                    ADB.CloseConnection();

                }
                catch (Exception ex)
                {
                    SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تعذر قراءة بيانات النقطة .", MSGTYPE.Error), DateTime.Now, number.ToString()));
                    this.exception_info = ex;
                }
            }
        }


        public BranchInfo(byte[] ar)
        {
            try
            {
                int index = 0;
                byte[] art = new byte[1];
                Array.Copy(ar, index, art, 0, 1);
                index += 1;

                this.branch_no = art[0];

                int l = BitConverter.ToInt32(ar, 1);
                index += 4;


                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.branch_name = Encoding.UTF8.GetString(art);


                l = BitConverter.ToInt32(ar, index);
                index += 4;

                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.branch_address = Encoding.UTF8.GetString(art);

              
                l = BitConverter.ToInt32(ar, index);
                index += 4;

                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.branch_phone = Encoding.UTF8.GetString(art);

                l = BitConverter.ToInt32(ar, index);
                index += 4;

                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.branch_mobile = Encoding.UTF8.GetString(art);

                l = BitConverter.ToInt32(ar, index);
                index += 4;

                if (l == 0)
                {
                    this.exception_info = null;
                }
                else
                {
                    art = new byte[l];
                    Array.Copy(ar, index, art, 0, l);
                    index += l;
                    this.exception_info = DeserializeX(art);
                }
            }
            catch (Exception ex)
            {
                this.branch_no = 0;
                this.branch_address = "";
                this.branch_phone = "";
                this.branch_mobile = "";
                this.exception_info = new Exception("");

            }

        }


        public byte[] ToBytes()
        {

            List<byte> ar = new List<byte>();

            ar.Add(this.branch_no);

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.branch_name).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.branch_name));

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.branch_address).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.branch_address));

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.branch_phone).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.branch_phone));

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.branch_mobile).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.branch_mobile));

            if (this.exception_info == null)
            {
                int x = 0;
                ar.AddRange(BitConverter.GetBytes(x));
            }
            else
            {
                byte[] e = SerializeX(this.exception_info);
                ar.AddRange(BitConverter.GetBytes(e.Length));
                ar.AddRange(e);
            }
            return ar.ToArray();
        }


        private Exception DeserializeX(byte[] ar)
        {

            Stream stream = new MemoryStream(ar);
            BinaryFormatter formatter = new BinaryFormatter();
            Exception ex = (Exception)formatter.Deserialize(stream);
            stream.Close();

            return ex;

        }

        private static byte[] SerializeX<T>(T obj)
        {
            using (MemoryStream memStream = new MemoryStream())
            {
                BinaryFormatter binSerializer = new BinaryFormatter();
                binSerializer.Serialize(memStream, obj);
                return memStream.ToArray();
            }
        }
    }


    public static class BranchInfoManager
    {

        private static BranchInfo branch = new BranchInfo(1);
        public static BranchInfo GetBranchInfo
        {
            get
            {
                return branch;
            }
            set
            {
                branch = value;
            }

        }

        internal static byte GenerateNewBranchNumber()
        {

            lock (Utilities.mylocker)
            {
                int res = 1;

                try
                {
                    ADataBase ADB = new ADataBase();

                    string sql = "select (max(branch_no)+1) as res from tblBranchInfo";
                    if (ADB.ExcuteSQLQuery(sql))
                    {
                        if (ADB.GetDataReader.Read())
                        {
                            res = Convert.ToInt32(ADB.GetDataReader["res"].ToString());
                        }
                    }
                    ADB.CloseConnection();
                }
                catch
                {
                    res = 1;

                }

                return (byte)res;
            }
        }

        public static bool CreateNewBranch(BranchInfo branch)
        {

            lock (Utilities.mylocker)
            {
                bool res = false;

                try
                {
                    ADataBase db = new ADataBase();
                    string sql = @"insert into tblBranchInfo (branch_no,branch_name,branch_address,branch_phone,branch_mobile) values(" + branch.BranchNumber + ",'" + branch.BranchName + "','" + branch.BranchAddress + "','" + branch.BranchPhone + "','" + branch.BrancMobile + "')";
                    if (db.ExcuteSQLNonQuery(sql) == 1)
                    {
                        SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تم إنشاء نقطة جديدة.", MSGTYPE.Info), DateTime.Now, "NUMBER=" + branch.BranchNumber + ",NAME=" + branch.BranchName + ",ADDRESS=" + branch.BranchAddress + ",PHONE=" + branch.BranchPhone));
                        res = true;
                    }
                    else
                    {   
                        throw new Exception("");
                    }

                }
                catch (Exception ex)
                {
                    branch.ExceptionInfo = ex;
                    SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تعذر إنشاء نقطة جديدة.", MSGTYPE.Error), DateTime.Now, "NUMBER=" + branch.BranchNumber + ",NAME=" + branch.BranchName + ",ADDRESS=" + branch.BranchAddress + ",PHONE=" + branch.BranchPhone));               
                }

                return res;
            }

        }

        public static bool UpdateBranchInfo(BranchInfo branch)
        {

            lock (Utilities.mylocker)
            {
                bool res = false;

                //if(!(BranchInfoManager.UpdateBranchFlag(branch)))
                //{
                //    return res;
                //}

                try
                {
                    ADataBase db = new ADataBase();
                    string sql = @"update tblBranchInfo set branch_name='" + branch.BranchName + "',branch_address='" + branch.BranchAddress + "',branch_phone='" + branch.BranchPhone + "',branch_mobile='" + branch.BrancMobile + "' where branch_no=" + branch.BranchNumber;
                    if (db.ExcuteSQLNonQuery(sql) == 1)
                    {
                        SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تم تعديل بيانات النقطة.", MSGTYPE.Info), DateTime.Now, "NUMBER=" + branch.BranchNumber + ",NAME=" + branch.BranchName + ",ADDRESS=" + branch.BranchAddress + ",PHONE=" + branch.BranchPhone));               
                        res = true;
                    }
                    else
                    {   
                        throw new Exception("");
                    }

                }
                catch (Exception ex)
                {
                    branch.ExceptionInfo = ex;
                    SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تعذر تعديل بيانات النقطة.", MSGTYPE.Error), DateTime.Now, "NUMBER=" + branch.BranchNumber + ",NAME=" + branch.BranchName + ",ADDRESS=" + branch.BranchAddress + ",PHONE=" + branch.BranchPhone));               
                }

                return res;
            }

        }

        public static bool UpdateBranchFlag(BranchInfo branch)
        {

            lock (Utilities.mylocker)
            {
                bool res = false;

                try
                {
                    OleDbConnection con = new OleDbConnection(Utilities.connection_string);
                    OleDbCommand cmd = new OleDbCommand();
                    string sql = @"update tblBranchInfo set branch_flag=@img where branch_no=" + branch.BranchNumber;
                    con.Open();

                    cmd = new OleDbCommand();

                    cmd.Connection = con;
                    cmd.CommandText = sql;

                    cmd.Parameters.AddWithValue("@img", branch.BranchFlag);
                    if (cmd.ExecuteNonQuery() == 1)
                    {
                        res = true;
                    }
                    con.Close();

                }
                catch (Exception ex)
                {
                    branch.ExceptionInfo = ex;
                }

                return res;
            }
        }

        public static List<BranchInfo> GetALLBranchInfo()
        {

            lock (Utilities.mylocker)
            {
                List<BranchInfo> branchies = new List<BranchInfo>();
                try
                {
                    ADataBase ADB = new ADataBase();

                    string sql = "select branch_no from tblBranchInfo";
                    if (ADB.ExcuteSQLQuery(sql))
                    {
                        while (ADB.GetDataReader.Read())
                        {
                            branchies.Add(new BranchInfo(Convert.ToByte(ADB.GetDataReader["branch_no"])));
                        }
                    }
                    ADB.CloseConnection();
                    
                }
                catch (Exception ex)
                {
                    SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تعذر قراءة بيانات النقاط.", MSGTYPE.Error), DateTime.Now));
                }

                return branchies;
            }
        }
    }
}