﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace YMT
{
    public partial class frmStations : Form
    {
        public frmStations()
        {
            InitializeComponent();
        }


        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {

            if (keyData == (Keys.Control | Keys.F))
            {
                
                return true;
            }

            if (keyData == (Keys.Control | Keys.N))
            {

                toolStripButton5.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.E))
            {
                toolStripButton4.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.R))
            {
                toolStripButton2.PerformClick();
                return true;
            }


            if (keyData == (Keys.Shift | Keys.Escape))
            {
                {
                    this.Close();
                }
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }


        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            frmStationManager fsm = new frmStationManager();
            fsm.ShowDialog();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (Server.IsRunning)
            {
                MessageBox.Show("يجب إيقاف السيرفر أولاً.", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                return;
            }

            Station s = null;
            try
            {
                
                if (LV.SelectedItems.Count > 0)
                {
                    int index = int.Parse(LV.SelectedItems[0].Text.ToString());
                    s = new Station(index);

                    // Configure save file dialog box
                    SaveFileDialog dlg = new SaveFileDialog();
                    dlg.FileName = "YMS"; // Default file name
                    dlg.DefaultExt = ".auf"; // Default file extension
                    dlg.Filter = "YMS INFO (.auf)|*.auf"; // Filter files by extension 

                    // Show save file dialog box
                    DialogResult res = dlg.ShowDialog();

                    // Process save file dialog box results 
                    if (res == System.Windows.Forms.DialogResult.OK)
                    {
                        StationHandCheckInfo shc = new StationHandCheckInfo(Utilities.network_name, Utilities.ip, new Station(s.Branch,"",s.Name,s.Password,s.Number,s.State));
                        byte[] ar = Utilities.EncryptData(shc.ToBytes(), "123");

                        // Save document 
                        string filename = dlg.FileName;
                        FileStream fs = new FileStream(filename, FileMode.OpenOrCreate);

                        fs.Write(ar, 0, ar.Length);
                        fs.Close();
                        SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "AU FILE has been exprted.", MSGTYPE.Info), DateTime.Now,s.Number.ToString()));
                        MessageBox.Show("AU file has been saved succssfuly", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }

            }
            catch
            {
                SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "falied to export AU FILE.", MSGTYPE.Info), DateTime.Now, s.Number.ToString()));
                MessageBox.Show("   تعذر تنفيذ العملية", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void frmStations_Load(object sender, EventArgs e)
        {
            Reset();
        }


        private void Reset()
        {
            List<Station> stations = StationManager.GetALLStations();
            DisplayResults(stations);
        }
        private void DisplayResults(List<Station> stations)
        {

            LV.Items.Clear();
            foreach (Station s in stations)
            {
                ListViewItem lvi = new ListViewItem(s.Number.ToString()); ;

                lvi.SubItems.Add(s.Name.ToString());
                lvi.SubItems.Add(s.HWID);
                

                if (s.State == StationState.ENABLE)
                {
                    lvi.SubItems.Add("قيد الخدمة");
                }
                else
                {
                    lvi.SubItems.Add("موقفة");
                }

                lvi.SubItems.Add(s.Branch.BranchNumber.ToString());
                LV.Items.Add(lvi);

            }

            toolStripStatusLabel2.Text = LV.Items.Count.ToString();

        }

        private void LV_DoubleClick(object sender, EventArgs e)
        {
            if (LV.SelectedItems.Count > 0)
            {
                int index = int.Parse(LV.SelectedItems[0].Text.ToString());
                Station s = new Station(index);
                frmStationManager fcm = new frmStationManager(s);
                fcm.ShowDialog();
                //Reset();
            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            Reset();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            LV_DoubleClick(sender, e);
        }
    }
}
