﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YMT
{
    public class NetworkInformation
    {
        private byte id;
        private string name;
        private string address;
        private string phone;
        private string ip1;
        private string ip2 = "";
        private string ip3 = "";

        private int max_session = 10;
        private int max_req_per_session = 10;
        private string backup_path = "D:\backup";

        private byte transction_number_lenght = 8;
   

        private Exception exception_info = null;

        public NetworkInformation(byte id,string name,string address,string phone,string ip)
        {
            this.id = id;
            this.name = name;
            this.address = address;
            this.phone = phone;
            this.ip1 = ip;
            this.ip2 = "";
            this.ip3 = "";

        }

        public NetworkInformation(byte id)
        {
            lock (Utilities.mylocker)
            {
                ADataBase db = new ADataBase();

                try
                {
                    string sql = @"select network_id,network_name,network_address,network_phone,network_ip from tblNetworkInfo where network_id=" + id;
                    if (db.ExcuteSQLQuery(sql))
                    {
                        if (db.GetDataReader.Read())
                        {
                            this.id = Convert.ToByte(db.GetDataReader["network_id"]);
                            this.name = Convert.ToString(db.GetDataReader["network_name"]);
                            this.address = Convert.ToString(db.GetDataReader["network_address"]);
                            this.phone = Convert.ToString(db.GetDataReader["network_phone"]);
                            this.ip1 = Convert.ToString(db.GetDataReader["network_ip"]);
                            db.CloseConnection();
                        }
                        else
                        {
                            throw new Exception(".");
                        }

                    }
                    else
                    {
                        throw new Exception(".");
                    }
                }
                catch (Exception ex)
                {
                    this.exception_info = ex;
                    db.CloseConnection();
                }
            }

        }

        public byte ID
        {
            get
            {
                return this.id;
            }
        }

        public string Name
        {
            get
            {
                return this.name;
            }
        }

        public string Address
        {
            get
            {
                return this.address;
            }
        }

        public string Phone
        {
            get
            {
                return this.phone;
            }
        }

        public string DNS
        {
            get
            {
                return this.ip1;
            }
        }

        public string DNS2
        {
            get
            {
                return this.ip1;
            }
        }


        public string DNS3
        {
            get
            {
                return this.ip1;
            }
        }

        public int MaxSessions
        {
            get
            {
                return this.max_session;
            }
        }

        public int MaxRequestsPerSession
        {
            get
            {
                return this.max_session;
            }
        }

    }

    internal static class NetworkInformationManager
    {
        static public bool UpdateNetworkInformation(NetworkInformation info)
        {
            lock (Utilities.mylocker)
            {   
                ADataBase db = new ADataBase();
                string sql = "update tblNetworkInfo set network_name='" + info.Name + "',network_address='" + info.Address + "',network_phone='" + info.Phone + "',network_ip='" + info.DNS + "' where network_id=1";

                if (db.ExcuteSQLNonQuery(sql) == 1)
                    return true;
                else
                    return false;
            }

        }
    }
}
