﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace YMT
{
    public partial class frmOutGoingTransction : Form
    {
        private bool op = false;
        TransferOutGoing ogt = null;

        public frmOutGoingTransction()
        {
            InitializeComponent();

            
            if (!(Utilities.user.CanAdd))
            {
                button9.Visible = false;
            }

            if (!(Utilities.user.CanEdit))
            {
                button8.Visible = false;
            }
            Reset();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {

            if (keyData == (Keys.Control | Keys.F))
            {
                button5.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.P))
            {
                button2.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.N))
            {
                button9.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.E))
            {
                button8.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.S))
            {
                button7.PerformClick();
                return true;
            }

            if (keyData == (Keys.Shift | Keys.Escape))
            {
                if (button7.Enabled)
                {
                    button6.PerformClick();
                }
                else
                {
                    this.Close();
                }
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void frmOutGoingTransction_Load(object sender, EventArgs e)
        {
            comboBox6.Items.Add("داخلي");
            comboBox6.Items.Add("خارجي");
            comboBox6.SelectedIndex = 0;
            comboBox6.Enabled = false;
            dateTimePicker1.CustomFormat = "yyyy/MM/dd";

            List<CurrencyInfo> currencies = CurrencyManager.GetALLCurrency();
            
            comboBox2.DisplayMember = "CurrencyName";
            comboBox2.ValueMember = "CurrencyNumber";
            comboBox2.DataSource = currencies;

            if (comboBox2.Items.Count > 0)
            {
                comboBox2.SelectedIndex = 0;
            }

            List<BranchInfo> branchies = BranchInfoManager.GetALLBranchInfo();

            comboBox1.DisplayMember = "BranchNumber";
            comboBox1.ValueMember = "BranchNumber";
            comboBox1.DataSource = branchies;

            if (comboBox1.Items.Count > 0)
            {
                comboBox1.SelectedIndex = 0;
            }

        }

        private void ClearALL()
        {
            numericUpDown1.Value = 0;
            numericUpDown2.Value = 0;
            numericUpDown4.Value = 0;
            textBox1.Text = "";
            textBox2.Text = "";
            comboBox2.SelectedIndex = 0;
            comboBox6.SelectedIndex = 0;
            comboBox1.SelectedIndex = 0;
          
        }

        private void AddNew()
        {
            ClearALL();
            DisableALL();
            dateTimePicker1.Value = DateTime.Now;
            numericUpDown1.Enabled = true;

            button1.Enabled = true;
            button6.Enabled = true;
            button7.Enabled = true;
        
            textBox1.Enabled = true;
            textBox2.Enabled = true;
            
            comboBox1.Enabled = true;
            comboBox2.Enabled = true;
            
            numericUpDown4.Value = TransferOutGoingManager.GenerateNewTransctionID();
            op = true;

        }

        private void Save()
        {

            try
            {

                if (!(numericUpDown1.Value > 0))
                {
                    numericUpDown1.Focus();
                    return;
                }

                if (!(numericUpDown2.Value > 0))
                {
                    button1.Focus();
                    //numericUpDown2.Focus();
                    return;
                }

                if (!(numericUpDown4.Value > 0))
                {
                    numericUpDown4.Focus();
                    return;
                }

                if (string.IsNullOrEmpty(textBox1.Text))
                {
                    textBox1.Focus();
                    return;
                }

                if (string.IsNullOrEmpty(textBox2.Text))
                {
                    textBox2.Focus();
                    return;
                }

                CurrencyInfo c = new CurrencyInfo(Convert.ToByte(comboBox2.SelectedValue));
                BranchInfo des_branch = new BranchInfo(Convert.ToByte(comboBox1.SelectedValue.ToString())); ;

                TransferOutGoing ogt = new TransferOutGoing((int)numericUpDown4.Value, MoneyTransferType.OUT, dateTimePicker1.Value, (numericUpDown1.Value * c.CurrencyExchange), numericUpDown1.Value, (numericUpDown2.Value * c.CurrencyExchange), ((numericUpDown2.Value * c.CurrencyExchange) / ((decimal)2)), textBox1.Text, textBox2.Text, Utilities.user, c, c.CurrencyExchange, numericUpDown2.Value, (numericUpDown2.Value / ((decimal)2)), BranchInfoManager.GetBranchInfo, BranchInfoManager.GetBranchInfo);

                Commission com = new Commission(BranchInfoManager.GetBranchInfo, des_branch, c, numericUpDown1.Value);
                if (com.ExceptionInfo != null)
                {
                    MessageBox.Show(" العملية المطلوبة غير مدعومة . .", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                    return;
                }

                decimal rec_commation = 0;

                if (com.CommissionTypeInfo == CommissionType.Preceint)
                {
                    decimal v1 = (numericUpDown1.Value / ((decimal)100)) * ((decimal)com.CommissionValue);
                    numericUpDown2.Value = v1;

                    if (com.CommissionTypeInfo2 == CommissionType.Preceint)
                    {
                        rec_commation = (numericUpDown2.Value / ((decimal)(100)) * com.CommissionValue2);
                    }
                    else
                    {
                        rec_commation = com.CommissionValue2;
                    }


                    label1.Text = "%" + com.CommissionValue.ToString("0.##");

                    numericUpDown3.Value = (numericUpDown1.Value + v1);
                }
                else
                {
                    numericUpDown2.Value = com.CommissionValue;

                    if (com.CommissionTypeInfo2 == CommissionType.Preceint)
                    {
                        rec_commation = (numericUpDown2.Value / ((decimal)(100)) * com.CommissionValue2);
                    }
                    else
                    {
                        rec_commation = com.CommissionValue2;
                    }

                    numericUpDown3.Value = ((numericUpDown1.Value + com.CommissionValue));

                    label1.Text = "";
                }

                ogt.Number = (int)numericUpDown4.Value;
                ogt.Type = MoneyTransferType.OUT;
                ogt.Date = dateTimePicker1.Value;
                ogt.Amount = (numericUpDown1.Value * c.CurrencyExchange);
                ogt.FAmount = numericUpDown1.Value;
                ogt.OutGoingTransferCommation = (numericUpDown2.Value * c.CurrencyExchange);
                ogt.OutGoingTransferReciverCommation = (rec_commation * c.CurrencyExchange);
                ogt.SenderName = textBox1.Text;
                ogt.ReciverName = textBox2.Text;
                ogt.UserInfo = Utilities.user;
                ogt.Currency = c;
                ogt.Exchange = c.CurrencyExchange;

                ogt.OutGoingTransferFCommation = numericUpDown2.Value;

                ogt.OutGoingTransferReciverFCommation = rec_commation; ;

                ogt.Branch = BranchInfoManager.GetBranchInfo;

                ogt.DestinationBranch = des_branch;
                TransferOutGoing ogt2 = new TransferOutGoing(ogt.Number, ogt.Type, ogt.Date, ogt.Amount, ogt.FAmount, ogt.OutGoingTransferCommation, ogt.OutGoingTransferReciverCommation, ogt.SenderName, ogt.ReciverName, ogt.UserInfo, ogt.Currency, ogt.Exchange, ogt.OutGoingTransferFCommation, ogt.OutGoingTransferReciverFCommation, ogt.Branch, ogt.DestinationBranch);
                if (op)
                {
                    DialogResult res = MessageBox.Show("هل تريد إعتماد الحوالة فعلاً؟", "تاكيد الإعتماد", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);

                    if (res == System.Windows.Forms.DialogResult.No)
                    {
                        return;
                    }

                    if (TransferOutGoingManager.CreateNewOutGoingTransction(ogt2))
                    {
                        Reset();
                        MessageBox.Show("تمت العملية بنجاح  .", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                    }
                    else
                    {
                        MessageBox.Show("تعذر على النظام تنفيذ العملية  .", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                    }

                }
            }
            catch
            {
                MessageBox.Show(" أوبس ,,, حدث شيء بطريقة خاطئة :(.", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
            }
        }


        private void DisableALL()
        {

            numericUpDown1.Enabled = false;
            numericUpDown2.Enabled = false;
            numericUpDown4.Enabled = false;

            button1.Enabled = false;
            button2.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = false;
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            comboBox2.Enabled = false;
            numericUpDown3.Enabled = false;
            comboBox6.Enabled = false;
            comboBox1.Enabled = false;
            dateTimePicker1.Enabled = false;

        }

        private void Delete()
        {
            return;
        }

        private void Update()
        {

            DisableALL();
            
            op = false;

            textBox1.Focus();
            button6.Enabled = true;

        }

        private void Reset()
        {
            DisableALL();
            
            button9.Enabled = true;
            button8.Enabled = true;
         
        }

        private void button9_Click(object sender, EventArgs e)
        {
            AddNew();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            //if (numericUpDown1.Value > 0)
            //{

            //    Commission c = new Commission(BranchInfoManager.GetBranchInfo, new BranchInfo(Convert.ToByte(comboBox1.SelectedValue.ToString())), new CurrencyInfo(Convert.ToByte(comboBox2.SelectedValue.ToString())), numericUpDown1.Value);
            //    //if (c.ExceptionInfo != null)
            //    //{
            //    //    MessageBox.Show("النقطة الهدف غير مدعومه.", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
            //    //    return;
            //    //}

            //    if (c.CommissionTypeInfo == CommissionType.Preceint)
            //    {
            //        decimal v1 = (numericUpDown1.Value / ((decimal)100)) * ((decimal)c.CommissionValue);
            //        numericUpDown2.Value = v1;
            //        label1.Text = "%" + c.CommissionValue.ToString("0.##");

            //        numericUpDown3.Value = Math.Round((numericUpDown1.Value + v1), 4);
            //    }
            //    else if (c.CommissionTypeInfo == CommissionType.Value)
            //    {
            //        numericUpDown2.Value = c.CommissionValue;
            //        numericUpDown3.Value = Math.Round((numericUpDown1.Value + c.CommissionValue), 4);

            //        label1.Text = "";
            //    }
            //}

        }

        private void button7_Click(object sender, EventArgs e)
        {
            Save();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Update();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Reset();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Search();
        }

        private void Search()
        {
            Reset();
            button6.Enabled = true;
            button8.Enabled = false;
            button9.Enabled = false;
            numericUpDown4.Enabled = true;
            numericUpDown4.Focus();
            numericUpDown4.Select(0, 9999);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Print();
        }

        private void Print()
        {
            return;
        }

        private void numericUpDown4_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                TransferOutGoing ogt = new TransferOutGoing((int)numericUpDown4.Value);
                if(ogt.ExceptionInfo == null)
                {
                    DisableALL();
                    button2.Enabled = true;
                    button5.Enabled = true;
                    button8.Enabled = true;
                    button9.Enabled = true;

                    comboBox2.SelectedValue = ogt.Currency.CurrencyNumber;
                    numericUpDown1.Value = ogt.FAmount;
                    
                    numericUpDown4.Value = ogt.Number;
                    numericUpDown2.Value = ogt.OutGoingTransferFCommation;
                    dateTimePicker1.Value = ogt.Date;
                    textBox1.Text = ogt.SenderName;
                    textBox2.Text = ogt.ReciverName;

                }
            }
        }

        private void numericUpDown1_Enter(object sender, EventArgs e)
        {
            numericUpDown1.Select(0, 999);
        }

        private void numericUpDown1_Click(object sender, EventArgs e)
        {
            numericUpDown1.Select(0, 999);
        }

        private void numericUpDown4_Click(object sender, EventArgs e)
        {
            numericUpDown4.Select(0, 999);
        }

        private void numericUpDown4_Enter(object sender, EventArgs e)
        {
            numericUpDown4.Select(0, 999);
        }

        private void numericUpDown2_Enter(object sender, EventArgs e)
        {
            numericUpDown2.Select(0, 999);
        }

        private void numericUpDown2_Click(object sender, EventArgs e)
        {
            numericUpDown2.Select(0, 999);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            numericUpDown2.Value = 0;
            numericUpDown3.Value = 0;

            if (numericUpDown1.Value > 0)
            {

                Commission c = new Commission(BranchInfoManager.GetBranchInfo, new BranchInfo(Convert.ToByte(comboBox1.SelectedValue.ToString())), new CurrencyInfo(Convert.ToByte(comboBox2.SelectedValue.ToString())), numericUpDown1.Value);
                if (c.ExceptionInfo != null)
                {
                    MessageBox.Show("  يتعذر إتمام العملية المطلوبة .", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                    return;
                }

                if (c.CommissionTypeInfo == CommissionType.Preceint)
                {
                    decimal v1 = (numericUpDown1.Value / ((decimal)100)) * ((decimal)c.CommissionValue);
                    numericUpDown2.Value = v1;
                    label1.Text = "%" + c.CommissionValue.ToString("0.##");

                    numericUpDown3.Value = Math.Round((numericUpDown1.Value + v1), 4);
                }
                else if (c.CommissionTypeInfo == CommissionType.Value)
                {
                    numericUpDown2.Value = c.CommissionValue;
                    numericUpDown3.Value = Math.Round((numericUpDown1.Value + c.CommissionValue), 4);

                    label1.Text = "";
                }
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            numericUpDown2.Value = 0;
            numericUpDown3.Value = 0;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            numericUpDown2.Value = 0;
            numericUpDown3.Value = 0;
        }

    }
       
}
