﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.IO.Compression;
using System.Security.Cryptography;

namespace YMT
{
    public enum CommandType
    {
        Logining = 15,
        Logout,
        StartPing,
        HandCheck,
        Logined,
        EndPing,
        BranchInfo,
        CurrencyInfo,
        GetCurrencyALLInfo,
        MonyTransferInfo,
        AddNewMoneyTransction,
        UpdateMoneyTransction,
        GetUserInfo,
        ChangeUserPassword,
        NewTransctionID,
        IncomingTransction,
        Commission,
        CommissionByInfo,
        GetALLBranchies,
        GetReport1,
        GetReport2,
        GetReport3,
        GetReport4,
        GetReport5,
        GetReport6,
        GetReport7,
        GetReport8,
        GetReport9,
        GetReport10,
        GetReport11,
        GetReport12,
        GetReport13,
        GetReport14,
        GetReport15,
        GetReport16,
        GetReport17,
        GetReport18,
        GetReport19,
        GetReport20,

    }

    public class SecPacket
    {

       private byte[] ar;
       private string password;

       public SecPacket(Packet packet,string password)
        {
            this.password = password;
            ar = EncryptData(Zip(packet.PacketToBytes()),this.password);
        }

        public Packet PlanPacket()
        {
            byte[] art = new byte[ar.Length - 8];
            Array.Copy(ar, 8, art, 0, art.Length);
            byte[] art2 = DecryptData(art, this.password);
            ar = Unzip(art2);
            return new Packet(ar);
        }

        public SecPacket(byte[] ar0,string password)
        {
            this.password = password;
            ar = ar0;
        }

        public byte[] ToBytes(int id)
        {
            List<byte> art = new List<byte>();
            art.AddRange(BitConverter.GetBytes(ar.Count() + 8 ));
            art.AddRange(BitConverter.GetBytes(id));
            art.AddRange((ar));
            return art.ToArray();
        }

        private void CopyTo(Stream src, Stream dest)
        {
            byte[] bytes = new byte[4096];

            int cnt;

            while ((cnt = src.Read(bytes, 0, bytes.Length)) != 0)
            {
                dest.Write(bytes, 0, cnt);
            }
        }

        private byte[] Zip(byte[] bytes)
        {
            using (var msi = new MemoryStream(bytes))
            using (var mso = new MemoryStream())
            {
                using (var gs = new GZipStream(mso, CompressionMode.Compress))
                {
                    //msi.CopyTo(gs);
                    CopyTo(msi, gs);
                }

                return mso.ToArray();
            }
        }
        private byte[] Unzip(byte[] bytes)
        {
            using (var msi = new MemoryStream(bytes))
            using (var mso = new MemoryStream())
            {
                using (var gs = new GZipStream(msi, CompressionMode.Decompress))
                {
                    CopyTo(gs, mso);
                }

                return mso.ToArray();
            }
        }

        private byte[] DecryptData(byte[] encryptedTextByte, string Encryptionkey)
        {
            RijndaelManaged objrij = new RijndaelManaged();

            objrij.Mode = CipherMode.CBC;

            objrij.Padding = PaddingMode.PKCS7;

            objrij.KeySize = 0x80;

            objrij.BlockSize = 0x80;

            //byte[] encryptedTextByte = Convert.FromBase64String(EncryptedText);

            byte[] passBytes = Encoding.UTF8.GetBytes(Encryptionkey);

            byte[] EncryptionkeyBytes = new byte[0x10];

            int len = passBytes.Length;

            if (len > EncryptionkeyBytes.Length)
            {

                len = EncryptionkeyBytes.Length;

            }

            Array.Copy(passBytes, EncryptionkeyBytes, len);

            objrij.Key = EncryptionkeyBytes;

            objrij.IV = EncryptionkeyBytes;

            byte[] TextByte = objrij.CreateDecryptor().TransformFinalBlock(encryptedTextByte, 0, encryptedTextByte.Length);

            return (TextByte);  

        }

        private byte[] EncryptData(byte[] textDataByte, string Encryptionkey)
        {

            RijndaelManaged objrij = new RijndaelManaged();

            objrij.Mode = CipherMode.CBC;

            objrij.Padding = PaddingMode.PKCS7;

            objrij.KeySize = 0x80;

            objrij.BlockSize = 0x80;

            //set the symmetric key that is used for encryption & decryption.

            byte[] passBytes = Encoding.UTF8.GetBytes(Encryptionkey);

            //set the initialization vector (IV) for the symmetric algorithm

            byte[] EncryptionkeyBytes = new byte[] { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };

            int len = passBytes.Length;

            if (len > EncryptionkeyBytes.Length)
            {

                len = EncryptionkeyBytes.Length;

            }

            Array.Copy(passBytes, EncryptionkeyBytes, len);

            objrij.Key = EncryptionkeyBytes;

            objrij.IV = EncryptionkeyBytes;

            //Creates symmetric AES object with the current key and initialization vector IV.

            ICryptoTransform objtransform = objrij.CreateEncryptor();

            //byte[] textDataByte = Encoding.UTF8.GetBytes(textData);

            //Final transform the test string.

            return (objtransform.TransformFinalBlock(textDataByte, 0, textDataByte.Length));

        }

    }
    public class Packet
    {
        private Command cmd;
        private int size;
        public Packet(Command cmd)
        {
            this.cmd = cmd;
            this.size = cmd.CommandToBytes().Length + 4;
        }

        public int GetSize
        {
            get { return this.size; }
        }

        public Packet(byte[] bytes_array)
        {
            this.size = BitConverter.ToInt32(bytes_array, 0);
            byte[] ba = new byte[bytes_array.Length - 4];
            Array.Copy(bytes_array, 4, ba, 0, bytes_array.Length - 4);
            this.cmd = new Command(ba);
        }

        public byte[] PacketToBytes()
        {
            List<byte> res = new List<byte>();
            res.AddRange(BitConverter.GetBytes(this.GetSize));
            res.AddRange(cmd.CommandToBytes());
            return res.ToArray();
        }

        public Command GetCommand
        {
            get { return this.cmd; }
        }

        



    }

    public class Command
    {
        private List<ParamInfo> pi = new List<ParamInfo>();
        private CommandType cmd;

        public Command(CommandType cmd, ParamInfo pi)
        {
            this.cmd = cmd;
            this.pi.Add(pi);
        }

        public Command(CommandType cmd, List<ParamInfo> pi)
        {
            this.cmd = cmd;
            this.pi = pi;
        }

        public Command(CommandType cmd)
        {
            this.cmd = cmd;
        }

        public byte[] CommandToBytes()
        {
            List<byte> res = new List<byte>();
            res.AddRange(BitConverter.GetBytes((int)this.cmd));

            for (int index = 0; index < this.pi.Count; index++)
            {
                res.AddRange(BitConverter.GetBytes(pi[index].GetSize));
                res.AddRange(pi[index].GetBytesArray);
            }

            return res.ToArray();
        }

        public Command(byte[] bytes_array)
        {
            this.cmd = (CommandType)BitConverter.ToInt32(bytes_array, 0);
            int index = 4;

            while (index < bytes_array.Length)
            {
                int ps = BitConverter.ToInt32(bytes_array, index);
                byte[] ta = new byte[ps];
                Array.Copy(bytes_array, index + 4, ta, 0, ps);
                ParamInfo pi = new ParamInfo(ta);
                index += pi.GetSize;
                index += 4;
                this.pi.Add(pi);
            }
        }

        public CommandType GetCommandType
        {
            get { return this.cmd; }
        }

        public List<ParamInfo> GetParametersInfo
        {
            get { return this.pi; }
        }
    }
    public class ParamInfo
    {
        private int size;
        private byte[] bytes_ary;

        public ParamInfo(string data)
        {
            this.bytes_ary = Encoding.UTF8.GetBytes(data);
            this.size = this.bytes_ary.Length;
        }

        public ParamInfo(byte[] data)
        {
            this.bytes_ary = data;
            this.size = this.bytes_ary.Length;
        }

        public int GetSize
        {
            get { return this.size; }
        }

        public byte[] GetBytesArray
        {
            get { return this.bytes_ary; }
        }

        public string GetBytesInString
        {
            get { return Encoding.UTF8.GetString(this.bytes_ary); }
        }
    }
}

    
