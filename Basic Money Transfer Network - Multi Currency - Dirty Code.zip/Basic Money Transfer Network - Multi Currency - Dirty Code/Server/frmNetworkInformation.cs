﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YMT
{
    public partial class frmNetworkInformation : Form
    {
        private NetworkInformation nt = null;

        public frmNetworkInformation()
        {
            InitializeComponent();
        }

        public frmNetworkInformation(NetworkInformation nt)
        {
            InitializeComponent();
            this.nt = nt;
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == (Keys.Control | Keys.E))
            {
                button8.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.S))
            {
                button7.PerformClick();
                return true;
            }

            if (keyData == (Keys.Shift | Keys.Escape))
            {
                if (button7.Enabled)
                {
                    button6.PerformClick();
                }
                else
                {
                    this.Close();
                }
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }


   
        private void frmNetworkInformation_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            this.CenterToScreen();
            if (this.nt != null)
            {
                DisplayInfo(this.nt);
            }
            
            
        }

        private void ClearALL()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox5.Text = "";
            textBox4.Text = "";

            numericUpDown1.Value = 0;
            numericUpDown2.Value = 0;
            numericUpDown3.Value = 0;
            numericUpDown4.Value = 0;

            checkBox1.Checked = false;
        }

        private void DisableALL()
        {
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox5.Enabled = false;
            textBox4.Enabled = false;

            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;

            numericUpDown1.Enabled = false;
            numericUpDown2.Enabled = false;
            numericUpDown3.Enabled = false;
            numericUpDown4.Enabled = false;
            checkBox1.Enabled = false;

            linkLabel1.Enabled = false;

        }

        private void Update()
        {
            DisableALL();

            textBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Enabled = true;
            textBox5.Enabled = true;

            button6.Enabled = true;
            button7.Enabled = true;
            linkLabel1.Enabled = true;
          
        }

        private void Save()
        {
            if (Server.IsRunning)
            {
                MessageBox.Show("يجب إيقاف السيرفر أولاً.", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                return;
            }

            if (string.IsNullOrEmpty(textBox1.Text))
            {
                textBox1.Focus();
                return;
            }

            if (string.IsNullOrEmpty(textBox5.Text))
            {
                textBox5.Focus();
                return;
            }

            NetworkInformation ni = new NetworkInformation(1, textBox1.Text, textBox2.Text, textBox3.Text, textBox5.Text);

            if (NetworkInformationManager.UpdateNetworkInformation(ni))
            {
                MessageBox.Show("تمت العملية بنجاح  .", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                Inti();
            }
            else
            {
                MessageBox.Show("تعذر على النظام تنفيذ العملية  .", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
            }

        }

        private void Cancel()
        {
            this.Close();
          
        }

        private void Inti()
        {

            DisableALL();

            button8.Enabled = true;

        }

        private void DisplayInfo(NetworkInformation ni)
        {

            DisableALL();
            button8.Enabled = true;
         
            textBox1.Text = ni.Name;
            textBox2.Text = ni.Address;
            textBox3.Text = ni.Phone;
            textBox5.Text = ni.DNS ;
           
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Update();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Save();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Cancel();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {

                OpenFileDialog ofd = new OpenFileDialog();


                ofd.Filter =
                    "صورة  (*.jpg)|*.jpg";
                ofd.InitialDirectory =
                    Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);


                DialogResult result = ofd.ShowDialog();


                if (result == DialogResult.OK)
                {
                    pictureBox1.Load(ofd.FileNames[0]);
                }
            }
            catch
            {
                MessageBox.Show("تعذر تغيير الشعار .", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            AddNew();
        }

        

        private void AddNew()
        {

            DisableALL();
            ClearALL();
            textBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Enabled = true;
            textBox5.Enabled = true;

            button6.Enabled = true;
            button7.Enabled = true;
            linkLabel1.Enabled = true;
           
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

    }
}
