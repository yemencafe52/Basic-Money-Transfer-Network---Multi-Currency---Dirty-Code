﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace YMT
{
    public enum StationState
    {
        ENABLE = 0,
        DISABLE
    }

    public class Station
    {
        private int number;
        private string hwid;
        private string name;
        private string password;
        private StationState state;
        private BranchInfo branch;
        private Exception exception = null;

        public Station(BranchInfo branch,string hwid, string name, string password, int number = 0,StationState state = StationState.DISABLE)
        {
            this.branch = branch;
            this.hwid = hwid;
            this.name = name;
            this.password = password;
            this.number = number;
            this.state = state;
        }

        public int Number
        {
            get
            {
                return this.number;
            }
        }

        public string HWID
        {
            get
            {
                return this.hwid;
            }
        }

        public string Name
        {
            get
            {
                return this.name;
            }
        }

        public string Password
        {
            get
            {
                return this.password;
            }
        }

        public BranchInfo Branch
        {
            get
            {
                return this.branch;
            }
        }

        public StationState State
        {
            get
            {
                return this.state;
            }
            set
            {
                this.state = value;
            }
        }

        public Exception ExceptionInfo
        {
            get
            {
                return this.exception;
            }
            
        }


        public Station(int id)
        {
            lock (Utilities.mylocker)
            {
                ADataBase db = new ADataBase();

                try
                {
                    string sql = @"select station_no,station_name,station_password,station_hwid,branch_no,station_state from tblStations where station_no=" + id;
                    if (db.ExcuteSQLQuery(sql))
                    {
                        if (db.GetDataReader.Read())
                        {
                            this.number = Convert.ToInt32(db.GetDataReader["station_no"]);
                            this.name = Convert.ToString(db.GetDataReader["station_name"]);
                            this.password = Convert.ToString(db.GetDataReader["station_password"]);
                            this.hwid = Convert.ToString(db.GetDataReader["station_hwid"]);
                            this.branch = new BranchInfo(Convert.ToByte(db.GetDataReader["branch_no"]));

                            if(Convert.ToBoolean(db.GetDataReader["station_state"])== false)
                            {
                                this.state = StationState.ENABLE;
                            }
                            else
                            {
                                this.state = StationState.DISABLE;
                            }
                            
                            db.CloseConnection();
                        }
                        else
                        {
                            throw new Exception("invalied.");
                        }
                    }
                    else
                    {
                        throw new Exception("invalied.");
                    }
                }
                catch (Exception ex)
                {
                    this.exception = ex;
                    db.CloseConnection();
                    SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تعذر قراءة بيانات المحطة.", MSGTYPE.Error), DateTime.Now,id.ToString()));
                }
            }
        }

        public Station(byte[] ar)
        {
            try
            {
                int index = 0;
                byte[] art = new byte[1];
                int l = 1;

                Array.Copy(ar, index, art, 0, l);
                index += 1;

                this.state = (StationState)art[0];

                this.number = BitConverter.ToInt32(ar, index);
                index += 4;

                l = BitConverter.ToInt32(ar, index);
                index += 4;

                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.name = Encoding.UTF8.GetString(art);

                l = BitConverter.ToInt32(ar, index);
                index += 4;

                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.hwid = Encoding.UTF8.GetString(art);

                l = BitConverter.ToInt32(ar, index);
                index += 4;

                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.password = Encoding.UTF8.GetString(art);

                l = BitConverter.ToInt32(ar, index);
                index += 4;

                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.branch = new BranchInfo(art);


                l = BitConverter.ToInt32(ar, index);
                index += 4;

                if (l == 0)
                {
                    this.exception = null;
                }
                else
                {
                    art = new byte[l];
                    Array.Copy(ar, index, art, 0, l);
                    index += l;
                    this.exception = DeserializeX(art);
                }

            }
            catch
            {
                this.number = 0;
                this.name = "";
                this.hwid = "";
                this.password = "";
                this.state = StationState.DISABLE;
                this.branch = null;
                this.exception = new Exception("");
            }

        }
        public byte[] ToBytes()
        {
          
            List<byte> ar = new List<byte>();
            ar.Add((byte)this.state);

            ar.AddRange(BitConverter.GetBytes(this.number));

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.name).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.name));

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.hwid).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.hwid));

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.password).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.password));

            ar.AddRange(BitConverter.GetBytes(this.branch.ToBytes().Count()));
            ar.AddRange((this.branch.ToBytes()));

            if (this.exception == null)
            {
                int x = 0;
                ar.AddRange(BitConverter.GetBytes(x));
            }
            else
            {
                byte[] e = SerializeX(this.exception);
                ar.AddRange(BitConverter.GetBytes(e.Length));
                ar.AddRange(e);
            }

            return ar.ToArray();
        }

        private Exception DeserializeX(byte[] ar)
        {

            Stream stream = new MemoryStream(ar);
            BinaryFormatter formatter = new BinaryFormatter();
            Exception ex = (Exception)formatter.Deserialize(stream);
            stream.Close();

            return ex;
        }

        private static byte[] SerializeX<T>(T obj)
        {
            using (MemoryStream memStream = new MemoryStream())
            {
                BinaryFormatter binSerializer = new BinaryFormatter();
                binSerializer.Serialize(memStream, obj);
                return memStream.ToArray();
            }
        }

    }

    static public class StationManager
    {
        static public bool CreateNewStation(Station station)
        {
            lock (Utilities.mylocker)
            {
                try
                {
                    ADataBase db = new ADataBase();
                    string sql = "insert into tblStations (station_name,station_password,station_state,station_hwid,branch_no) values('" + station.Name + "','" + station.Password + "'," + Convert.ToBoolean(station.State) + ",'" + station.HWID + "'," + station.Branch.BranchNumber + ")";
                    if (db.ExcuteSQLNonQuery(sql) == 1)
                    {
                        SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تم إضافة محطة جديدة.", MSGTYPE.Info), DateTime.Now, "NUMBER=" + station.Number + ",NAME=" + station.Name + ",HWID=" + station.HWID + ",PWD=" + "**********" + ",STATUS=" + Convert.ToString(station.State) + ",POS=" + station.Branch.BranchName));
                        return true;
                    }
                    else
                        throw new Exception();
                }
                catch
                {
                    SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تعذر إضافة محطة جديدة.", MSGTYPE.Error), DateTime.Now, "NUMBER=" + station.Number + ",NAME=" + station.Name + ",HWID=" + station.HWID + ",PWD=" + "**********" + ",STATUS=" + Convert.ToString(station.State) + ",POS=" + station.Branch.BranchName));
                    return false;
                }
            }

           
        }

        static public bool UpdateStation(Station station)
        {

            lock (Utilities.mylocker)
            {
                try
                {
                    ADataBase db = new ADataBase();
                    string sql = "update tblStations set station_name='" + station.Name + "',station_password='" + station.Password + "',station_state=" + Convert.ToBoolean(station.State) + " where station_no=" + station.Number;
                    if (db.ExcuteSQLNonQuery(sql) == 1)
                    {
                        SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تم تعديل بيانات المحطة .", MSGTYPE.Info), DateTime.Now, "NUMBER=" + station.Number + ",NAME=" + station.Name + ",HWID=" + station.HWID + ",PWD=" + "**********" + ",STATUS=" + Convert.ToString(station.State) + ",POS=" + station.Branch.BranchName));
                        return true;
                    }
                    else
                    {
                        throw new Exception();
                    }
                }
                catch
                {
                    SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تعذر تعديل  بيانات المحطة.", MSGTYPE.Error), DateTime.Now, "NUMBER=" + station.Number + ",NAME=" + station.Name + ",HWID=" + station.HWID + ",PWD=" + "**********" + ",STATUS=" + Convert.ToString(station.State) + ",POS=" + station.Branch.BranchName));
                    return false;
                }
            }
        }



        static public bool DeleteStation(Station station)
        {
            bool res = false;

            try
            {

            }
            catch
            {
            }

            return res;
        }

        public static List<Station> GetALLStations()
        {

            lock (Utilities.mylocker)
            {
                List<Station> stations = new List<Station>();
                try
                {
                    ADataBase ADB = new ADataBase();

                    string sql = @"select station_no,station_name,station_password,station_hwid,branch_no,station_state from tblStations";

                    if (ADB.ExcuteSQLQuery(sql))
                    {
                        while (ADB.GetDataReader.Read())
                        {
                            stations.Add(new Station(new BranchInfo(Convert.ToByte(ADB.GetDataReader["branch_no"])), Convert.ToString(ADB.GetDataReader["station_hwid"]), Convert.ToString(ADB.GetDataReader["station_name"]), Convert.ToString(ADB.GetDataReader["station_password"]), Convert.ToInt32(ADB.GetDataReader["station_no"]), ((StationState)(Convert.ToByte(ADB.GetDataReader["station_state"])))));
                        }
                    }
                    ADB.CloseConnection();
                }
                catch (Exception ex)
                {
                    SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تعذر قراءة بيانات المحطات.", MSGTYPE.Error), DateTime.Now));
                }

                return stations;
            }
        }

    }
}
