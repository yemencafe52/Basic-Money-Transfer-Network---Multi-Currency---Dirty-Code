﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace YMT
{
    public static class Users
    {
        static public bool CreateUser(User user)
        {
            lock (Utilities.mylocker)
            {
                ADataBase db = new ADataBase();
                string sql = "insert into tblUsers (user_name,user_password,can_add,can_edit,can_delete,can_manage_db,is_stoped) values('" + user.UserName + "','" + user.Password + "'," + Convert.ToBoolean(user.CanAdd) + "," + Convert.ToBoolean(user.CanEdit) + "," + Convert.ToBoolean(user.CanDelete) + "," + Convert.ToBoolean(user.CanManageDB) + "," + Convert.ToBoolean(user.IsStopped) + ")";
                if (db.ExcuteSQLNonQuery(sql) == 1)
                    return true;
                else
                    return false;
            }
        }

        static public bool UpdateUser(User user)
        {
            lock (Utilities.mylocker)
            {
                if (user.Number == 1)
                {
                    user.CanManageDB = true;
                    user.CanAdd = true;
                    user.CanDelete = true;
                    user.CanEdit = true;
                }

                ADataBase db = new ADataBase();
                string sql = "update tblUsers set user_password='" + user.Password + "',can_add=" + user.CanAdd + ",can_edit=" + user.CanEdit + ",can_delete=" + user.CanDelete + ",can_manage_db=" + user.CanManageDB + ",is_stoped=" + user.IsStopped + " where user_no=" + user.Number;
                if (db.ExcuteSQLNonQuery(sql) == 1)
                    return true;
                else
                    return false;
            }

        }

        static public bool DeleteUser(User user)
        {
            return false;
        }

        internal static int GenerateNewUSerID()
        {
            lock (Utilities.mylocker)
            {
                int res = 1;
                try
                {
                    ADataBase ADB = new ADataBase();

                    string sql = "select (max(user_no)+1) as res from tblUsers";
                    if (ADB.ExcuteSQLQuery(sql))
                    {
                        if (ADB.GetDataReader.Read())
                        {
                            res = Convert.ToInt32(ADB.GetDataReader["res"].ToString());
                        }
                    }
                    ADB.CloseConnection();
                }
                catch
                {
                    res = -1;
                }

                return res;
            }
        }



        static public bool DisableUser(User user)
        {
            lock (Utilities.mylocker)
            {
                if (user.Number == 1)
                {
                    return false;
                }

                ADataBase db = new ADataBase();
                string sql = "update tblUsers set is_stoped=1 where user_no=" + user.Number;
                if (db.ExcuteSQLNonQuery(sql) == 1)
                    return true;
                else
                    return false;
            }
        }


        static public bool EnableUser(User user)
        {
            lock (Utilities.mylocker)
            {
                if (user.Number == 1)
                {
                    return false;
                }

                ADataBase db = new ADataBase();
                string sql = "update tblUsers set is_stoped=0 where user_no=" + user.Number;
                if (db.ExcuteSQLNonQuery(sql) == 1)
                    return true;
                else
                    return false;
            }
        }


        static public List<User> GetUsers()
        {
            lock (Utilities.mylocker)
            {
                ADataBase db = new ADataBase();
                List<User> users = new List<User>();

                try
                {
                    string sql = @"select user_no,user_name,user_password,can_add,can_edit,can_delete,can_manage_db,is_stoped from tblUsers";
                    if (db.ExcuteSQLQuery(sql))
                    {
                        while (db.GetDataReader.Read())
                        {
                            User user = new User(Convert.ToByte(db.GetDataReader["user_no"]), Convert.ToString(db.GetDataReader["user_name"]), Convert.ToString(db.GetDataReader["user_password"]), Convert.ToBoolean(db.GetDataReader["can_add"]), Convert.ToBoolean(db.GetDataReader["can_edit"]), Convert.ToBoolean(db.GetDataReader["can_delete"]), Convert.ToBoolean(db.GetDataReader["can_manage_db"]), Convert.ToBoolean(db.GetDataReader["is_stoped"]));
                            users.Add(user);
                        }

                        db.CloseConnection();
                    }
                    else
                    {

                        throw new Exception("invalied.");
                    }
                }
                catch
                {
                    db.CloseConnection();
                }

                return users;
            }
        }


        public static bool Login(string username, string password, ref User user_info)
        {
            lock (Utilities.mylocker)
            {
                bool res = false;
                List<User> users = GetUsers();
                foreach (User user in users)
                {
                    if (user.IsStopped)
                    {
                        continue;
                    }
                    if ((user.UserName.ToLower() == username.ToLower()) && (user.Password == Utilities.GetMD5Hash(password)))
                    {
                        user_info = user;
                        res = true;
                        break;
                    }
                    else
                    {
           
                    }
                }
                return res;
            }
        }

    }

    public class User
    {
        private byte user_no;
        private string user_name;
        private string password = "";
        private bool can_add = false;
        private bool can_edit = false;
        private bool can_delete = false;
        private bool is_stopped = false;
        private bool can_manage_db = false;

        private Exception exception_info = null;

        public  User()
        {   
            //lock (Utilities.mylocker)
            //{
            //    ADataBase db = new ADataBase();
            //    //this.user_no = (byte)db.GenerateRowNumber("tblUsers", "user_no");
            //}
        }

        public User(byte number)
        {
            lock (Utilities.mylocker)
            {
                ADataBase db = new ADataBase();

                try
                {
                    string sql = @"select user_no,user_name,user_password,can_add,can_edit,can_delete,can_manage_db,is_stoped from tblUsers where user_no=" + number;
                    if (db.ExcuteSQLQuery(sql))
                    {
                        if (db.GetDataReader.Read())
                        {
                            this.user_no = Convert.ToByte(db.GetDataReader["user_no"]);
                            this.user_name = Convert.ToString(db.GetDataReader["user_name"]);
                            this.password = Convert.ToString(db.GetDataReader["user_password"]);
                            this.can_add = Convert.ToBoolean(db.GetDataReader["can_add"]);
                            this.can_edit = Convert.ToBoolean(db.GetDataReader["can_edit"]);
                            this.can_delete = Convert.ToBoolean(db.GetDataReader["can_delete"]);
                            this.can_manage_db = Convert.ToBoolean(db.GetDataReader["can_manage_db"]);
                            this.is_stopped = Convert.ToBoolean(db.GetDataReader["is_stoped"]);
                            db.CloseConnection();
                        }
                        else
                        {
                            throw new Exception("invalied.");
                        }

                    }
                    else
                    {
                        throw new Exception("invalied.");
                    }
                }
                catch (Exception ex)
                {
                    this.exception_info = ex;
                    db.CloseConnection();
                }
            }

        }
        public User(byte user_no, string user_name, string password, bool can_add, bool can_edit, bool can_delete, bool can_manage_db, bool is_stopped = false)
        {
            this.user_no = user_no;
            this.user_name = user_name;
            this.password = password;
            this.can_add = can_add;
            this.can_edit = can_edit;
            this.can_delete = can_delete;
            this.can_manage_db = can_manage_db;
            this.is_stopped = is_stopped;
        }

        public byte Number
        {
            get
            {
                return this.user_no;
            }

            set
            {
                this.user_no = value;
            }
        }

        public string UserName
        {
            get
            {
                return this.user_name;
            }

            set
            {
                this.user_name = value;
            }
        }

        public string Password
        {
            get
            {
                return this.password;
            }

            set
            {
                this.password = value;
            }
        }

        public bool CanAdd
        {
            get
            {
                return this.can_add;
            }

            set
            {
                this.can_add = value;
            }
        }

        public bool CanEdit
        {
            get
            {
                return this.can_edit;
            }

            set
            {
                this.can_edit = value;
            }
        }

        public bool CanDelete
        {
            get
            {
                return this.can_delete;
            }

            set
            {
                this.can_delete = value;
            }
        }

        public bool IsStopped
        {
            get
            {
                return this.is_stopped;
            }

            set
            {
                this.is_stopped = value;
            }
        }

        public bool CanManageDB
        {
            get
            {
                return this.can_manage_db;
            }

            set
            {
                this.can_manage_db = value;
            }
        }

        public Exception ExceptionInfo
        {
            get
            {
                return this.exception_info;
            }

            set
            {
                this.exception_info = value;
            }
        }

        public User(byte[] ar)
        {
            try
            {
                int index = 0;
                byte[] art = new byte[1];
                int l = 1;

                Array.Copy(ar, index, art, 0, l);
                this.user_no = ar[0];
                index += 1;

                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.user_name = Encoding.UTF8.GetString(art);


                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.password = Encoding.UTF8.GetString(art);

                this.is_stopped = BitConverter.ToBoolean(ar, index);
                index += 1;
                this.can_add = BitConverter.ToBoolean(ar, index);
                index += 1;
                this.can_delete = BitConverter.ToBoolean(ar, index);
                index += 1;
                this.can_edit = BitConverter.ToBoolean(ar, index);
                index += 1;
                this.can_manage_db = BitConverter.ToBoolean(ar, index);
                index += 1;

                l = BitConverter.ToInt32(ar, index);
                index += 4;

                if (l == 0)
                {
                    this.exception_info = null;
                }
                else
                {
                    art = new byte[l];
                    Array.Copy(ar, index, art, 0, l);
                    index += l;
                    this.exception_info = DeserializeX(art);
                }
            }
            catch (Exception ex)
            {
                this.user_no = 0;
                this.user_name = "";
                this.password = "";
                this.is_stopped = false;
                this.can_add = false;
                this.can_delete = false;
                this.can_edit = false;
                this.can_manage_db = false;
                this.exception_info = new Exception("");
            }

        }

        public byte[] ToBytes()
        {

            List<byte> ar = new List<byte>();

            ar.Add((this.user_no));
            
            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.user_name).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.user_name));

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.password).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.password));

            ar.AddRange(BitConverter.GetBytes(this.is_stopped));
            ar.AddRange(BitConverter.GetBytes(this.can_add));
            ar.AddRange(BitConverter.GetBytes(this.can_delete));
            ar.AddRange(BitConverter.GetBytes(this.can_edit));
            ar.AddRange(BitConverter.GetBytes(this.can_manage_db));

            if (this.exception_info == null)
            {
                int x = 0;
                ar.AddRange(BitConverter.GetBytes(x));
            }
            else
            {
                byte[] e = SerializeX(this.exception_info);
                ar.AddRange(BitConverter.GetBytes(e.Length));
                ar.AddRange(e);
            }

            return ar.ToArray();
        }


        private Exception DeserializeX(byte[] ar)
        {

            Stream stream = new MemoryStream(ar);
            BinaryFormatter formatter = new BinaryFormatter();
            Exception ex = (Exception)formatter.Deserialize(stream);
            stream.Close();

            return ex;
        }

        private static byte[] SerializeX<T>(T obj)
        {
            using (MemoryStream memStream = new MemoryStream())
            {
                BinaryFormatter binSerializer = new BinaryFormatter();
                binSerializer.Serialize(memStream, obj);
                return memStream.ToArray();
            }
        }

    }
}
