﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;
using System.Security.Cryptography;
using System.Runtime.InteropServices;

namespace YMT
{
    internal static class Utilities
    {

        static string dbPath = Environment.GetEnvironmentVariable("windir") + "\\EMT55";//"C:\\EMT.ACCDB"; //
        static internal string connection_string = (@"Provider=Microsoft.ACE.OLEDB.12.0;Persist Security Info=True;Data Source=" + dbPath + @";Jet OLEDB:Database Password=*YAS1520*;ole db services=-1"); //

        static public User user;
        static public object mylocker = new object();

        static public string ip = "127.0.0.1";
        static public string network_name = "YMT NetWork";
        static public StationHandCheckInfo SHC = null;
        static public NetworkInformation nt = new NetworkInformation(1);
        static public frmLog fl = null;

        [DllImport("advpack.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        static public extern bool IsNTAdmin(int dwReserved, int lpdwReserved);

        internal static bool CheckDatabase()
        {

            if (File.Exists(dbPath))
            {
                try
                {
                    OleDbConnection con;
                    con = new OleDbConnection(Utilities.connection_string);
                    con.Open();
                    con.Close();
                    return true;
                }
                catch
                {
                    return false;
                }
            }
            else
            {
                return false;
            }

        }

        static public bool InstallDateBase()
        {
            try
            {
                if (File.Exists(dbPath))
                {
                    return false;
                }

                FileStream f = new FileStream(dbPath, FileMode.Create);
                byte[] dbByte = new byte[YMT.AccessDB.db.Length];
                f.Write(YMT.AccessDB.db, 0, YMT.AccessDB.db.Length);
                f.Close();

                if (CheckDatabase())
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }

        }

        internal static bool RestoreDatabase(string path)
        {

            if (File.Exists(path))
            {
                string connecting_sting = (@"Provider=Microsoft.ACE.OLEDB.12.0;Persist Security Info=True;Jet OLEDB:Database Password=its52ye;Data Source=" + path + ";Jet OLEDB:Database Password=*YAS1520*;ole db services=-1");
                OleDbConnection con = new OleDbConnection(connecting_sting);

                try
                {
                    con.Open();
                    con.Close();
                    File.Copy(path, dbPath, true);

                    if (CheckDatabase())
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }

                catch
                {
                    return false;
                }

            }
            else
            {
                return false;
            }
        }


        static public string GenerateRandomNumber(int length)
        {
            Random r = new Random();
            string id = "";

            int x = r.Next(1, 9);
            id += x.ToString();

            for (int index = 1; index <= length; index++)
            {
                x = r.Next(0, 9);
                id += x.ToString();
            }

            return id;
        }

        internal static string GetMD5Hash(string txt)
        {

            using (MD5 md5Hash = MD5.Create())
            {
                // Convert the input string to a byte array and compute the hash. 
                byte[] data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(txt));

                StringBuilder sBuilder = new StringBuilder();

                // Loop through each byte of the hashed data  
                // and format each one as a hexadecimal string. 
                for (int i = 0; i < data.Length; i++)
                {
                    sBuilder.Append(data[i].ToString("x2"));
                }

                // Return the hexadecimal string. 
                return sBuilder.ToString();

            }

        }


        static public bool MakeBackup(string path)
        {
            try
            {

                if (!Directory.Exists(Application.StartupPath + "\\Backup"))
                {
                    Directory.CreateDirectory(Application.StartupPath + "\\Backup");
                }

                //if (!Directory.Exists(path))
                //{
                //    Directory.CreateDirectory(path);
                //}

                File.Copy(Utilities.dbPath, path, true);

                //if(!(LogoutDBSig(path)))
                //{
                //    return false;
                //}

                return true;
            }
            catch
            {
                return false;
            }

        }

        static public bool LogoutDBSig(string path)
        {

            try
            {
                FileStream fs = File.Open(path, FileMode.Open);
                byte[] sig = new byte[2];
                fs.Write(sig, 0, 2);
                fs.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }
        static public bool CheckDBSig(string path)
        {

            try
            {
                FileStream fs = File.Open(path, FileMode.Open);
                byte[] sig = new byte[2] { 84, 65 };
                fs.Write(sig, 0, 2);
                fs.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }


        public static byte[] DecryptData(byte[] encryptedTextByte, string Encryptionkey)
        {
            RijndaelManaged objrij = new RijndaelManaged();

            objrij.Mode = CipherMode.CBC;

            objrij.Padding = PaddingMode.PKCS7;

            objrij.KeySize = 0x80;

            objrij.BlockSize = 0x80;

            //byte[] encryptedTextByte = Convert.FromBase64String(EncryptedText);

            byte[] passBytes = Encoding.UTF8.GetBytes(Encryptionkey);

            byte[] EncryptionkeyBytes = new byte[0x10];

            int len = passBytes.Length;

            if (len > EncryptionkeyBytes.Length)
            {

                len = EncryptionkeyBytes.Length;

            }

            Array.Copy(passBytes, EncryptionkeyBytes, len);

            objrij.Key = EncryptionkeyBytes;

            objrij.IV = EncryptionkeyBytes;

            byte[] TextByte = objrij.CreateDecryptor().TransformFinalBlock(encryptedTextByte, 0, encryptedTextByte.Length);

            return (TextByte);

        }

        public static byte[] EncryptData(byte[] textDataByte, string Encryptionkey)
        {

            RijndaelManaged objrij = new RijndaelManaged();

            objrij.Mode = CipherMode.CBC;

            objrij.Padding = PaddingMode.PKCS7;

            objrij.KeySize = 0x80;

            objrij.BlockSize = 0x80;

            //set the symmetric key that is used for encryption & decryption.

            byte[] passBytes = Encoding.UTF8.GetBytes(Encryptionkey);

            //set the initialization vector (IV) for the symmetric algorithm

            byte[] EncryptionkeyBytes = new byte[] { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };

            int len = passBytes.Length;

            if (len > EncryptionkeyBytes.Length)
            {

                len = EncryptionkeyBytes.Length;

            }

            Array.Copy(passBytes, EncryptionkeyBytes, len);

            objrij.Key = EncryptionkeyBytes;

            objrij.IV = EncryptionkeyBytes;

            //Creates symmetric AES object with the current key and initialization vector IV.

            ICryptoTransform objtransform = objrij.CreateEncryptor();

            //byte[] textDataByte = Encoding.UTF8.GetBytes(textData);

            //Final transform the test string.

            return (objtransform.TransformFinalBlock(textDataByte, 0, textDataByte.Length));

        }


         static public bool ReadAU(string file)
        {
            bool res = false;

            try
            {

                FileStream fs = new FileStream(file, FileMode.Open);
                long size = fs.Length;
                byte[] ar = new byte[size];
                fs.Read(ar, 0, ar.Length);
                fs.Close();

                StationHandCheckInfo shc = new StationHandCheckInfo(Utilities.DecryptData(ar,"123"));
                if (shc.ExceptionInfo == null)
                {
                    Utilities.SHC = shc;
                    res = true;
                }
            }
            catch
            {
                res = false;
            }

            return res;
         }



        internal static int GetLastDayInMoth(int year, int month)
        {
            int res = 0;

            DateTime t = new DateTime(year, month, 28);

            for (int i = 28; i <32; i++)
            {
                t = t.AddDays(1);
                if (t.Month != month)
                {
                    res = i;
                    break;
                }
            }

            return res;

        }
    }
}