﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Windows.Forms;
using System.Data;
using System.Threading;
using System.IO;

namespace YMT
{
    class ADataBase
    {
        private OleDbConnection con;
        private OleDbCommand cmd;
        private Exception exception_info = null;
        private OleDbDataReader dr;
        public OleDbDataReader GetDataReader
        {
            get { return this.dr; }
        }

        public Exception ExceptionInfo
        {
            get { return this.exception_info; }
        }

        public bool ExcuteSQLQuery(string sql)
        {
            lock (Utilities.mylocker)
            {
                try
                {
                    
                    con = new OleDbConnection(Utilities.connection_string);
                    con.Open();
                    cmd = new OleDbCommand(sql, con);
                    this.dr = cmd.ExecuteReader();
                    return true;
                }
                catch (Exception ex)
                {
                    this.CloseConnection();
                    this.exception_info = ex;
                    return false;
                }
            }

        }

        public int ExcuteSQLNonQuery(string sql)
        {
            lock (Utilities.mylocker)
            {
                try
                {
                    con = new OleDbConnection(Utilities.connection_string);
                    con.Open();
                    cmd = new OleDbCommand(sql, con);
                    int res = cmd.ExecuteNonQuery();
                    con.Close();
                    return res;
                }
                catch (Exception ex)
                {
                    this.CloseConnection();
                    this.exception_info = ex;
                  
                    return -1;
                }
            }

        }

        public bool ReportDBError(string sql , Exception ex)
        {

            lock (Utilities.mylocker)
            {
                bool res = false;
                try
                {

                    string path = Application.StartupPath + "\\DB_ERROR\\" + DateTime.Now.ToString("yyyy-MM-dd");
                    string file_path = path + "\\" + DateTime.Now.ToString("yyyy-MM-dd HHmmss") + ".LOG";

                    if (!(Directory.Exists(path)))
                    {
                        Directory.CreateDirectory(path);    
                    }

                    File.AppendAllText(file_path , sql + "\r\n" + ex.Message, Encoding.UTF8);
                    res = true;

                }
                catch
                {
                    res = false;
                }

                return res;
            }
        }

        public void CloseConnection()
        {
            try
            {
                if (con != null)
                {
                    if (con.State != System.Data.ConnectionState.Closed)
                    {
                        try
                        {
                            con.Close();
                            con.Dispose();
                        }
                        catch
                        {
                            con.Dispose();
                        }
                        con = null;
                    }
                }
            }
            catch
            {
         
            }

            GC.Collect();
        }

        ~ADataBase()
        {
            CloseConnection();
        }

        public long GenerateRowNumberd(string table_name, string field_name)
        {

            lock (Utilities.mylocker)
            {
                try
                {
                    con = new OleDbConnection(Utilities.connection_string);
                    con.Open();
                    string sql = "select (max(" + field_name + ")+1) as NewRow  from " + table_name + "";

                    cmd = new OleDbCommand(sql, con);
                    long row_number = 2;

                    dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {

                        if (!long.TryParse(dr["NewRow"].ToString(), out row_number))
                        {
                            row_number = 2;
                        }

                    }

                    con.Close();
                    return row_number;

                }
                catch (Exception ex)
                {
                    SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, " تعذر توليد رقم صف جديد  ", MSGTYPE.Error), DateTime.Now,"TABLE=" + table_name + ",MSG=" + ex.Message));
                    con.Close();
                    exception_info = ex;
                    return -1;
                }
            }
        }

    }

    static class ADB
    {
        static private OleDbConnection con;
        static private OleDbCommand cmd;
        static private Exception exception_info = null;
        static private OleDbDataReader dr;

        static public OleDbDataReader GetDataReader
        {
            get { return dr; }
        }

        static public Exception ExceptionInfo
        {
            get { return exception_info; }
        }

        static public bool ExcuteSQLQuery(string sql)
        {
            lock (Utilities.mylocker)
            {
                try
                {
                    con = new OleDbConnection(Utilities.connection_string);
                    con.Open();
                    cmd = new OleDbCommand(sql, con);
                    dr = cmd.ExecuteReader();
                    return true;
                }
                catch (Exception ex)
                {
                    CloseConnection();
                    exception_info = ex;
                    SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تعذر تنفيذ الإستعلام 2", MSGTYPE.Error), DateTime.Now, "SQL=" + sql + ",MSG=" + ex.Message));
                    return false;
                }
            }

        }

        static public int ExcuteSQLNonQuery(string sql)
        {
            lock (Utilities.mylocker)
            {
                try
                {
                    con = new OleDbConnection(Utilities.connection_string);
                    con.Open();
                    cmd = new OleDbCommand(sql, con);
                    int res = cmd.ExecuteNonQuery();
                    con.Close();
                    return res;
                }
                catch (Exception ex)
                {
                    CloseConnection();
                    exception_info = ex;
                    SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تعذر تنفيذ الإستعلام 2", MSGTYPE.Error), DateTime.Now, "SQL=" + sql + ",MSG=" + ex.Message));
                    return -1;
                }
            }

        }

        static public void CloseConnection()
        {
            try
            {
                if (con != null)
                {
                    if (con.State != System.Data.ConnectionState.Closed)
                    {
                        try
                        {
                            con.Close();
                            con.Dispose();
                        }
                        catch
                        {
                            con.Dispose();
                        }
                        con = null;
                    }
                }
            }
            catch
            {

            }

            GC.Collect();
        }


    }

}
