﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace YMT
{
    public class ActiveSession
    {
        private int session_id = 0;
        private DateTime logined_at;
        private DateTime last_seen;
        private Station station;

        public ActiveSession(DateTime logined_at, DateTime last_seen, Station station)
        {
            session_id = ActiveSessionManager.GenerateNewSessionID;
            this.logined_at = logined_at;
            this.last_seen = last_seen;
            this.station = station;
        }

        public int SessionID
        {
            get
            {
                return this.session_id;
            }
        }


        public DateTime LastSeen
        {
            get
            {
                return this.last_seen;
            }
            set
            {
                this.last_seen = value;
            }
        }

        public DateTime LoginedAT
        {
            get
            {
                return this.logined_at;
            }
        }

        public Station StationInfo
        {
            get
            {
                return this.station;
            }
        }

    }

    static public class ActiveSessionManager
    {

        static private object mylocker = new object();
        static private List<ActiveSession> active_stations = new List<ActiveSession>();
        static private double timeout = 60;
        static private int new_session_id = 0;
        static private Thread th;
        static public int GenerateNewSessionID
        {
            get
            {
                lock (mylocker)
                {
                    return ++new_session_id;
                }
            }
        }

        static public List<ActiveSession> ActiveSessions
        {
            get
            {
                lock (mylocker)
                {
                    return active_stations;
                }
            }
        }

        static public bool IsActive(Station station)
        {
            lock (mylocker)
            {
                bool res = false;
                try
                {
                    res = active_stations.Exists(p => p.StationInfo.HWID == station.HWID);
                }
                catch
                {
                    res = false;
                }
                return res;
            }
        }

        static public bool AddNewActiveSession(ActiveSession acts)
        {
            lock (mylocker)
            {
                bool res = false;
                try
                {
                    res = active_stations.Exists(p => p.StationInfo.HWID == acts.StationInfo.HWID);

                    if (!res)
                    {
                        active_stations.Add(acts);
                        res = true;
                    }
                }
                catch
                {
                    res = false;
                }
                return res;
            }
        }

        static public bool GetActiveSessionByUser(Station station, ref ActiveSession as_info)
        {
            lock (mylocker)
            {
                bool res = false;
                try
                {
                    bool is_active = IsActive(station);

                    if (is_active)
                    {
                        as_info = active_stations.Find(p => p.StationInfo.HWID == station.HWID);

                        if (as_info == null)
                        {
                            res = false;
                        }
                        else
                        {
                            res = true;
                        }
                    }
                }
                catch
                {
                    res = false;
                }
                return res;
            }
        }

        static public bool UpdateActiveSession(ActiveSession as_info)
        {
            lock (mylocker)
            {
                bool res = false;
                try
                {
                    int index = active_stations.FindIndex(p => p.StationInfo.Number == as_info.StationInfo.Number);
                    active_stations[index].LastSeen = as_info.LastSeen;
                    res = true;
                   
                }
                catch
                {
                    res = false;
                }
                return res;
            }
            
        }

        static public bool GetActiveSessionByStationID(int id, ref ActiveSession as_info)
        {
            lock (mylocker)
            {
                bool res = false;
                try
                {
                    as_info = active_stations.Find(p => p.StationInfo.Number == id);

                    if (as_info == null)
                    {
                        res = false;
                    }
                    else
                    {
                        res = true;
                    }
                }
                catch
                {
                    res = false;
                }
                return res;
            }
        }

        static public bool RemoveActiveUser(Station station)
        {
            lock (mylocker)
            {
                bool res = false;
                try
                {
                    bool is_active = IsActive(station);

                    if (is_active)
                    {
                        ActiveSession as_info = null;
                        if (GetActiveSessionByUser(station, ref as_info))
                        {
                            res = active_stations.Remove(as_info);
                        }
                    }
                }
                catch
                {
                    res = false;
                }

                return res;
            }
        }

        static public void STARTProcessActiveSession()
        {
            th = new Thread(ProcessActiveSession);
            th.Start();
        }

        static public void ProcessActiveSession()
        {  
            while ((Server.IsRunning))
            {
                lock (mylocker)
                {
                    for (int i = (active_stations.Count - 1); i >= 0; i--)
                    {
                        long tick = DateTime.Now.Ticks - active_stations[i].LastSeen.Ticks;

                        TimeSpan ts = new TimeSpan(tick);
                        double sec = ts.TotalSeconds;

                        if (sec >= timeout)
                        {
                            active_stations.RemoveAt(i);
                        }

                    }
                }

                Thread.Sleep(5000);
            }

            active_stations.Clear();
        }
    }
}
