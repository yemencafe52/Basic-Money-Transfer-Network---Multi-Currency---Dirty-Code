﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;
using System.Security.Cryptography;
using System.Data;
using System.Runtime.Serialization.Formatters.Binary;
using System.Data.OleDb;

namespace YMT
{
    internal static class Server
    {
        static private Socket server = null;
        static private int port = 888;
        static private bool is_running = false;

        static internal bool IsRunning
        {
            get
            {
                return is_running;
            }
        }

        internal static int Port
        {
            get
            {
                return port;
            }
        }


        static private DataTable DeserializeX(byte[] ar)
        {
            
            
            Stream stream = new MemoryStream(ar);
            BinaryFormatter formatter = new BinaryFormatter();
            DataTable ex = (DataTable)formatter.Deserialize(stream);
            stream.Close();

            return ex;

        }

        static private byte[] SerializeX<T>(T obj)
        {
            using (MemoryStream memStream = new MemoryStream())
            {
                BinaryFormatter binSerializer = new BinaryFormatter();
                binSerializer.Serialize(memStream, obj);
                return memStream.ToArray();
            }
        }


        static internal bool StartListeing()
        {
            IPEndPoint iep = new IPEndPoint(0, port);
            try
            {

                if (server == null)
                {
                    server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                    server.Bind(iep);
                    server.Listen(0);

                    server.BeginAccept(new AsyncCallback(AcceptCallBack), server);
                    is_running = true;

                    ActiveSessionManager.STARTProcessActiveSession();
                    return true;
                }
               
                return false;
            }

            catch
            {   
                is_running = false;
                server.Dispose();
                server = null;
                return false;
            }

        }




        static internal bool Stop()
        {
           
            try
            {
                if (server != null)
                {
                    server.Close();
                    server.Dispose();
                    server = null;

                    while (ActiveSessionManager.ActiveSessions.Count > 0)
                    {
                        ActiveSessionManager.ActiveSessions.RemoveAt(0);
                    }

                    is_running = false;
                    return true;
                }

                return false;
            }

            catch 
            {   
                server = null;
                is_running = false;
                return false;
            }

        }

        static private void AcceptCallBack(IAsyncResult ar)
        {

            try
            {
                Socket client = null;

                try
                {

                    if (is_running == false)
                    {
                        return;
                    }

                    client = server.EndAccept(ar);
                    server.BeginAccept(new AsyncCallback(AcceptCallBack), server);

                }
                catch
                {
                    is_running = false;
                    return;
                }

                try
                {
                    List<byte> all_data = new List<byte>();

                    byte[] data = new byte[1024 * 8];

                    do
                    {
                        client.ReceiveTimeout = 30000;

                        int size = client.Receive(data);

                        if (size > 0)
                        {
                            byte[] a1 = new byte[size];

                            Array.Copy(data, a1, size);

                            all_data.AddRange(a1);

                            if (all_data.Count >= 12)
                            {
                                int bf_size = BitConverter.ToInt32(all_data.ToArray(), 0);

                                do
                                {

                                    if ((all_data.Count) >= bf_size)
                                    {
                                        byte[] bf = new byte[bf_size];

                                        all_data.CopyTo(0, bf, 0, bf_size);

                                        all_data.RemoveRange(0, bf_size);

                                        Packet packet = null;
                                        Station cs = null;

                                        int id = BitConverter.ToInt32(bf, 4);

                                        ActiveSession acts = null;
                                        Station station = null;

                                        if (!(ActiveSessionManager.GetActiveSessionByStationID(id, ref acts)))
                                        {

                                            station = new Station(id);

                                            try
                                            {
                                                if (station.ExceptionInfo != null)
                                                {
                                                    LogManager.CreateNewEvent(new Log(new MSGINFO(8, "محاولة إتصال محطة غير معروفة", MSGTYPE.Error), (((IPEndPoint)(client.RemoteEndPoint)).Address.ToString()), new BranchInfo(1), station, new User(1), DateTime.Now, id.ToString()));
                                                    client.Close();
                                                    return;
                                                }

                                                SecPacket sp = new SecPacket(bf, station.Password);

                                                packet = sp.PlanPacket();

                                                cs = new Station(packet.GetCommand.GetParametersInfo[0].GetBytesArray);

                                                byte[] ars1 = GetMD5HashInBytes(station.ToBytes());
                                                byte[] ars2 = GetMD5HashInBytes(cs.ToBytes());

                                                for (int i = 0; i < ars1.Length; i++)
                                                {
                                                    if (ars1[i] != ars2[i])
                                                    {
                                                        LogManager.CreateNewEvent(new Log(new MSGINFO(7, "بيانات المصادقة للمحطة غير صحيحة", MSGTYPE.Error), (((IPEndPoint)(client.RemoteEndPoint)).Address.ToString()), new BranchInfo(1), station, new User(1), DateTime.Now, id.ToString()));
                                                        client.Close();
                                                        return;
                                                        
                                                    }
                                                }

                                                acts = new ActiveSession(DateTime.Now, DateTime.Now, station);
                                                ActiveSessionManager.AddNewActiveSession(acts);
                                            }
                                            catch
                                            {   
                                                client.Close();
                                                return;
                                            }

                                          
                                        }
                                        else
                                        {

                                          
                                            SecPacket sp = new SecPacket(bf, acts.StationInfo.Password);
                                            packet = sp.PlanPacket();
                                            cs = acts.StationInfo;
                                            station = cs;
                                            acts.LastSeen = DateTime.Now;
                                            ActiveSessionManager.UpdateActiveSession(acts);
                                        }


                                        switch (packet.GetCommand.GetCommandType)
                                        {
                                            case CommandType.Logining:
                                                {
                                                    string username = packet.GetCommand.GetParametersInfo[1].GetBytesInString;
                                                    string password = packet.GetCommand.GetParametersInfo[2].GetBytesInString;

                                                    User user = null; ;
                                                    if (Users.Login(username, password, ref user))
                                                    {
                                                        LogManager.CreateNewEvent(new Log(new MSGINFO(9, " تم تسجيل الدخول "), (((IPEndPoint)(client.RemoteEndPoint)).Address.ToString()), cs.Branch, cs, user, DateTime.Now));
                                                    }
                                                    else
                                                    {
                                                        LogManager.CreateNewEvent(new Log(new MSGINFO(10, " عملية تسجيل دخول فاشلة", MSGTYPE.Warning), (((IPEndPoint)(client.RemoteEndPoint)).Address.ToString()), cs.Branch, cs, user, DateTime.Now));
                                                    }

                                                    client.Send(new SecPacket(new Packet(new Command(CommandType.Logined, new ParamInfo(user.ToBytes()))), station.Password).ToBytes(0));
                                                    break;
                                                }

                                            case CommandType.Logout:
                                                {

                                                    client.Shutdown(SocketShutdown.Both);
                                                    client.Disconnect(false);
                                                    client.Close();
                                                  
                                                    break;
                                                }

                                            case CommandType.GetCurrencyALLInfo:
                                                {

                                                    List<CurrencyInfo> currencies = CurrencyManager.GetALLCurrency();
                                                    List<byte> cary = new List<byte>();

                                                    cary.AddRange(BitConverter.GetBytes(currencies.Count));

                                                    foreach (CurrencyInfo currency in currencies)
                                                    {
                                                        byte[] c = currency.ToBytes();
                                                        cary.AddRange(BitConverter.GetBytes(c.Count()));
                                                        cary.AddRange(c);
                                                    }

                                                    client.Send(new SecPacket(new Packet(new Command(CommandType.GetCurrencyALLInfo, new ParamInfo(cary.ToArray()))), station.Password).ToBytes(0));
                                                    break;

                                                }



                                            case CommandType.GetALLBranchies:
                                                {
                                                    List<BranchInfo> branchies = BranchInfoManager.GetALLBranchInfo();
                                                    List<byte> cary = new List<byte>();

                                                    cary.AddRange(BitConverter.GetBytes(branchies.Count));

                                                    foreach (BranchInfo b in branchies)
                                                    {
                                                        byte[] c = b.ToBytes();
                                                        cary.AddRange(BitConverter.GetBytes(c.Count()));
                                                        cary.AddRange(c);
                                                    }


                                                    client.Send(new SecPacket(new Packet(new Command(CommandType.GetALLBranchies, new ParamInfo(cary.ToArray()))), station.Password).ToBytes(0));
                                                    break;

                                                }


                                            case CommandType.BranchInfo:
                                                {
                                                    User user = new User(packet.GetCommand.GetParametersInfo[1].GetBytesArray);

                                                    User u = new User(user.Number);
                                                    {
                                                        if ((u.Number == user.Number) && (u.UserName == user.UserName) && (u.Password == user.Password))
                                                        {
                                                            byte number = packet.GetCommand.GetParametersInfo[2].GetBytesArray[0];

                                                            BranchInfo branch = new BranchInfo((byte)number);
                                                            client.Send(new SecPacket(new Packet(new Command(CommandType.BranchInfo, new ParamInfo(branch.ToBytes()))), station.Password).ToBytes(0));
                                                        }
                                                        else
                                                        {
                                                            client.Close();
                                                        }
                                                    }


                                                    break;

                                                }

                                            case CommandType.CurrencyInfo:
                                                {
                                                    User user = new User(packet.GetCommand.GetParametersInfo[1].GetBytesArray);

                                                    User u = new User(user.Number);
                                                    {
                                                        if ((u.Number == user.Number) && (u.UserName == user.UserName) && (u.Password == user.Password))
                                                        {
                                                            byte number = packet.GetCommand.GetParametersInfo[2].GetBytesArray[0];

                                                            CurrencyInfo c = new CurrencyInfo(number);

                                                            client.Send(new SecPacket(new Packet(new Command(CommandType.CurrencyInfo, new ParamInfo(c.ToBytes()))), station.Password).ToBytes(0));
                                                        }
                                                        else
                                                        {
                                                            client.Close();
                                                        }
                                                    }


                                                    break;

                                                }




                                            case CommandType.UpdateMoneyTransction:
                                                {
                                                    User user = new User(packet.GetCommand.GetParametersInfo[1].GetBytesArray);

                                                    User u = new User(user.Number);
                                                    {
                                                        if ((u.Number == user.Number) && (u.UserName == user.UserName) && (u.Password == user.Password))
                                                        {
                                                            TransferIncoming ti = new TransferIncoming(packet.GetCommand.GetParametersInfo[2].GetBytesArray);
                                                            TransferIncoming ti2 = new TransferIncoming(TransferIncomingManager.GenerateNewTransctionID(), ti.TransferOutGoingInfo, ti.UserInfo, ti.Date, ti.Branch);


                                                            bool res = false;
                                                            if (TransferIncomingManager.CreateNewIncomingTransction(ti2))
                                                            {
                                                                LogManager.CreateNewEvent(new Log(new MSGINFO(5, "استلام حوالة"), (((IPEndPoint)(client.RemoteEndPoint)).Address.ToString()), cs.Branch, cs, user, DateTime.Now, "TN=" + ti.TransferOutGoingInfo.Number.ToString()));
                                                                res = true;
                                                            }
                                                            else
                                                            {
                                                                LogManager.CreateNewEvent(new Log(new MSGINFO(6, "تعذر استلام الحوالة", MSGTYPE.Warning), (((IPEndPoint)(client.RemoteEndPoint)).Address.ToString()), cs.Branch, cs, user, DateTime.Now, "TN=" + ti.TransferOutGoingInfo.Number.ToString()));
                                                            }

                                                            client.Send(new SecPacket(new Packet(new Command(CommandType.UpdateMoneyTransction, new ParamInfo(BitConverter.GetBytes(res)))), station.Password).ToBytes(0));
                                                        }
                                                        else
                                                        {
                                                            client.Close();
                                                        }
                                                    }


                                                    break;

                                                }


                                            case CommandType.AddNewMoneyTransction:
                                                {
                                                    User user = new User(packet.GetCommand.GetParametersInfo[1].GetBytesArray);

                                                    User u = new User(user.Number);
                                                    {
                                                        if ((u.Number == user.Number) && (u.UserName == user.UserName) && (u.Password == user.Password))
                                                        {
                                                            TransferOutGoing ogt = new TransferOutGoing(packet.GetCommand.GetParametersInfo[2].GetBytesArray);
                                                            TransferOutGoing ogt2 = new TransferOutGoing(ogt.Number, ogt.Type, ogt.Date, ogt.Amount, ogt.FAmount, ogt.OutGoingTransferCommation, ogt.OutGoingTransferReciverCommation, ogt.SenderName, ogt.ReciverName, ogt.UserInfo, ogt.Currency, ogt.Exchange, ogt.OutGoingTransferFCommation, ogt.OutGoingTransferReciverFCommation, ogt.Branch, ogt.DestinationBranch);
                                                            bool res = false;

                                                            if (TransferOutGoingManager.CreateNewOutGoingTransction(ogt2))
                                                            {
                                                                LogManager.CreateNewEvent(new Log(new MSGINFO(1, "تم إرسال حوالة"), (((IPEndPoint)(client.RemoteEndPoint)).Address.ToString()), cs.Branch, cs, user, DateTime.Now, "TN=" + ogt2.Number.ToString()));
                                                                res = true;
                                                            }
                                                            else
                                                            {
                                                                LogManager.CreateNewEvent(new Log(new MSGINFO(2, "تعذر عملية إرسال الحوالة", MSGTYPE.Error), (((IPEndPoint)(client.RemoteEndPoint)).Address.ToString()), cs.Branch, cs, user, DateTime.Now, "TN=" + ogt2.Number.ToString()));
                                                            }

                                                            client.Send(new SecPacket(new Packet(new Command(CommandType.AddNewMoneyTransction, new ParamInfo(BitConverter.GetBytes(res)))), station.Password).ToBytes(0));
                                                        }
                                                        else
                                                        {
                                                            client.Close();
                                                        }
                                                    }


                                                    break;

                                                }




                                            case CommandType.NewTransctionID:
                                                {
                                                    User user = new User(packet.GetCommand.GetParametersInfo[1].GetBytesArray);

                                                    User u = new User(user.Number);

                                                    if ((u.Number == user.Number) && (u.UserName == user.UserName) && (u.Password == user.Password))
                                                    {
                                                        client.Send(new SecPacket(new Packet(new Command(CommandType.NewTransctionID, new ParamInfo(BitConverter.GetBytes(TransferOutGoingManager.GenerateNewTransctionID())))), station.Password).ToBytes(0));
                                                    }
                                                    else
                                                    {
                                                        client.Close();
                                                    }
                                                    break;
                                                }

                                            case CommandType.ChangeUserPassword:
                                                {
                                                    User user = new User(packet.GetCommand.GetParametersInfo[1].GetBytesArray);
                                                    //User user2 = new User(packet.GetCommand.GetParametersInfo[2].GetBytesArray);
                                                    
                                                    string old_pass = packet.GetCommand.GetParametersInfo[2].GetBytesInString;
                                                    string new_pass = Utilities.GetMD5Hash(packet.GetCommand.GetParametersInfo[3].GetBytesInString);


                                                    User u = new User(user.Number);

                                                    if ((u.Number == user.Number) && (u.UserName == user.UserName) && (u.Password == user.Password))
                                                    {

                                                        if (((Utilities.GetMD5Hash(old_pass) == new User(user.Number).Password)))
                                                        {
                                                            user.Password = new_pass;
                                                            if (Users.UpdateUser(user))
                                                            {
                                                                LogManager.CreateNewEvent(new Log(new MSGINFO(11, " قام المستخدم بتغيير كلمة المرور الخاصة به"), (((IPEndPoint)(client.RemoteEndPoint)).Address.ToString()), cs.Branch, cs, user, DateTime.Now));
                                                                client.Send(new SecPacket(new Packet(new Command(CommandType.ChangeUserPassword, new ParamInfo("DONE"))), station.Password).ToBytes(0));
                                                            }
                                                            else
                                                            {
                                                                LogManager.CreateNewEvent(new Log(new MSGINFO(12, " تعذر تغيير كلمة المرور الخاصة بالمستخدم",MSGTYPE.Warning), (((IPEndPoint)(client.RemoteEndPoint)).Address.ToString()), cs.Branch, cs, user, DateTime.Now));
                                                                client.Send(new SecPacket(new Packet(new Command(CommandType.ChangeUserPassword, new ParamInfo("DONE"))), station.Password).ToBytes(0));
                                                            }


                                                        }
                                                        else
                                                        {
                                                            LogManager.CreateNewEvent(new Log(new MSGINFO(12, " تعذر تغيير كلمة المرور الخاصة بالمستخدم", MSGTYPE.Warning), (((IPEndPoint)(client.RemoteEndPoint)).Address.ToString()), cs.Branch, cs, user, DateTime.Now));
                                                            client.Send(new SecPacket(new Packet(new Command(CommandType.ChangeUserPassword, new ParamInfo("FALIED"))), station.Password).ToBytes(0));
                                                        }
                                                        
                                                    }
                                                    else
                                                    {

                                                        client.Close();
                                                    }
                                                    break;
                                                }

                                            case CommandType.StartPing:
                                                {
                                                    //User user = new User(packet.GetCommand.GetParametersInfo[1].GetBytesArray);

                                                    //User u = new User(user.Number);

                                                    //if ((u.Number == user.Number) && (u.UserName == user.UserName) && (u.Password == user.Password))
                                                    //{
                                                    client.Send(new SecPacket(new Packet(new Command(CommandType.EndPing, new ParamInfo(BitConverter.GetBytes(DateTime.Now.ToOADate())))), station.Password).ToBytes(0));
                                                    //}
                                                    //else
                                                    //{
                                                    //    client.Close();
                                                    //}
                                                    break;
                                                }
                                            case CommandType.MonyTransferInfo:
                                                {
                                                    User user = new User(packet.GetCommand.GetParametersInfo[1].GetBytesArray);

                                                    User u = new User(user.Number);
                                                    {
                                                        if ((u.Number == user.Number) && (u.UserName == user.UserName) && (u.Password == user.Password))
                                                        {
                                                            int number = BitConverter.ToInt32(packet.GetCommand.GetParametersInfo[2].GetBytesArray, 0);

                                                            TransferOutGoing ogt = new TransferOutGoing(number);
                                                            if (ogt.ExceptionInfo == null)
                                                            {
                                                                LogManager.CreateNewEvent(new Log(new MSGINFO(3, " استعلام  عن حوالة"), (((IPEndPoint)(client.RemoteEndPoint)).Address.ToString()), cs.Branch, cs, user, DateTime.Now, "TN=" + ogt.Number.ToString()));
                                                            }
                                                            else
                                                            {
                                                                LogManager.CreateNewEvent(new Log(new MSGINFO(4, "تعذر على النظام العثور على الحوالة المطلوبة", MSGTYPE.Warning), (((IPEndPoint)(client.RemoteEndPoint)).Address.ToString()), cs.Branch, cs, user, DateTime.Now, "TN=" + number.ToString()));
                                                            }

                                                            client.Send(new SecPacket(new Packet(new Command(CommandType.MonyTransferInfo, new ParamInfo(ogt.ToBytes()))), station.Password).ToBytes(0));
                                                        }
                                                        else
                                                        {
                                                            client.Close();
                                                        }
                                                    }
                                                    break;
                                                }

                                            case CommandType.IncomingTransction:
                                                {
                                                    User user = new User(packet.GetCommand.GetParametersInfo[1].GetBytesArray);

                                                    User u = new User(user.Number);
                                                    {
                                                        if ((u.Number == user.Number) && (u.UserName == user.UserName) && (u.Password == user.Password))
                                                        {
                                                            int number = BitConverter.ToInt32(packet.GetCommand.GetParametersInfo[2].GetBytesArray, 0);

                                                            TransferIncoming ti = new TransferIncoming(number);
                                                            if (ti.ExceptionInfo == null)
                                                            {
                                                               // LogManager.CreateNewEvent(new Log(new MSGINFO(0, " الاستعلام عن حوالة تم إستلامها مسبقاً"), (((IPEndPoint)(client.RemoteEndPoint)).Address.ToString()), cs.Branch, cs, user, DateTime.Now, "TN=" + ti.TransferIncomingNumber.ToString()));
                                                            }
                                                            else
                                                            {
                                                             //   LogManager.CreateNewEvent(new Log(new MSGINFO(0, " تعذر الاستلعام عن حوالة مستلمة  "), (((IPEndPoint)(client.RemoteEndPoint)).Address.ToString()), cs.Branch, cs, user, DateTime.Now, "TN=" + ti.TransferIncomingNumber.ToString()));
                                                            }
                                                            client.Send(new SecPacket(new Packet(new Command(CommandType.IncomingTransction, new ParamInfo(ti.ToBytes()))), station.Password).ToBytes(0));
                                                        }
                                                        else
                                                        {
                                                            client.Close();
                                                        }
                                                    }


                                                    break;

                                                }




                                            case CommandType.Commission:
                                                {
                                                    User user = new User(packet.GetCommand.GetParametersInfo[1].GetBytesArray);

                                                    User u = new User(user.Number);
                                                    {
                                                        if ((u.Number == user.Number) && (u.UserName == user.UserName) && (u.Password == user.Password))
                                                        {
                                                            int number = BitConverter.ToInt32(packet.GetCommand.GetParametersInfo[2].GetBytesArray, 0);

                                                            Commission c = new Commission(number);

                                                            client.Send(new SecPacket(new Packet(new Command(CommandType.Commission, new ParamInfo(c.ToBytes()))), station.Password).ToBytes(0));
                                                        }
                                                        else
                                                        {
                                                            client.Close();
                                                        }
                                                    }


                                                    break;

                                                }



                                            case CommandType.CommissionByInfo:
                                                {
                                                    User user = new User(packet.GetCommand.GetParametersInfo[1].GetBytesArray);

                                                    User u = new User(user.Number);
                                                    {
                                                        if ((u.Number == user.Number) && (u.UserName == user.UserName) && (u.Password == user.Password))
                                                        {
                                                            BranchInfo from = new BranchInfo(packet.GetCommand.GetParametersInfo[2].GetBytesArray);
                                                            BranchInfo to = new BranchInfo(packet.GetCommand.GetParametersInfo[3].GetBytesArray);
                                                            CurrencyInfo currency = new CurrencyInfo(packet.GetCommand.GetParametersInfo[4].GetBytesArray);

                                                            decimal amount = (decimal)BitConverter.ToDouble(packet.GetCommand.GetParametersInfo[5].GetBytesArray, 0);

                                                            Commission c = new Commission(from, to, currency, amount);

                                                            client.Send(new SecPacket(new Packet(new Command(CommandType.CommissionByInfo, new ParamInfo(c.ToBytes()))), station.Password).ToBytes(0));
                                                        }
                                                        else
                                                        {
                                                            client.Close();
                                                        }
                                                    }


                                                    break;

                                                }



                                            case CommandType.GetReport1:
                                                {
                                                    
                                                    User user = new User(packet.GetCommand.GetParametersInfo[1].GetBytesArray);

                                                    User u = new User(user.Number);
                                                    {
                                                        if ((u.Number == user.Number) && (u.UserName == user.UserName) && (u.Password == user.Password))
                                                        {
                                                            DateTime from = DateTime.FromOADate(BitConverter.ToDouble(packet.GetCommand.GetParametersInfo[2].GetBytesArray, 0));
                                                            DateTime to = DateTime.FromOADate(BitConverter.ToDouble(packet.GetCommand.GetParametersInfo[3].GetBytesArray, 0));

                                                            OugGoingReports ogr = new OugGoingReports();
                                                            DataTable dt = ogr.GetOutGoingTransction(from,to);

                                                            byte[] tbl = SerializeX(dt);


                                                            client.Send(new SecPacket(new Packet(new Command(CommandType.GetReport1, new ParamInfo(tbl))), station.Password).ToBytes(0));
                                                        }
                                                        else
                                                        {
                                                            client.Close();
                                                        }
                                                    }


                                                    break;

                                                }

                                            case CommandType.GetReport2:
                                                {

                                                    User user = new User(packet.GetCommand.GetParametersInfo[1].GetBytesArray);

                                                    User u = new User(user.Number);
                                                    {
                                                        if ((u.Number == user.Number) && (u.UserName == user.UserName) && (u.Password == user.Password))
                                                        {
                                                            DateTime from = DateTime.FromOADate(BitConverter.ToDouble(packet.GetCommand.GetParametersInfo[2].GetBytesArray, 0));
                                                            DateTime to = DateTime.FromOADate(BitConverter.ToDouble(packet.GetCommand.GetParametersInfo[3].GetBytesArray, 0));
                                                            User user2 = new User(packet.GetCommand.GetParametersInfo[4].GetBytesArray);

                                                            OugGoingReports ogr = new OugGoingReports();
                                                            DataTable dt = ogr.GetOutGoingTransction(from, to,user2);

                                                            byte[] tbl = SerializeX(dt);


                                                            client.Send(new SecPacket(new Packet(new Command(CommandType.GetReport2, new ParamInfo(tbl))), station.Password).ToBytes(0));
                                                        }
                                                        else
                                                        {
                                                            client.Close();
                                                        }
                                                    }


                                                    break;

                                                }

                                            case CommandType.GetReport3:
                                                {

                                                    User user = new User(packet.GetCommand.GetParametersInfo[1].GetBytesArray);

                                                    User u = new User(user.Number);
                                                    {
                                                        if ((u.Number == user.Number) && (u.UserName == user.UserName) && (u.Password == user.Password))
                                                        {
                                                            DateTime from = DateTime.FromOADate(BitConverter.ToDouble(packet.GetCommand.GetParametersInfo[2].GetBytesArray, 0));
                                                            DateTime to = DateTime.FromOADate(BitConverter.ToDouble(packet.GetCommand.GetParametersInfo[3].GetBytesArray, 0));
                                                            BranchInfo branch = new BranchInfo(packet.GetCommand.GetParametersInfo[4].GetBytesArray);
                                                            bool x = BitConverter.ToBoolean(packet.GetCommand.GetParametersInfo[5].GetBytesArray,0);

                                                            OugGoingReports ogr = new OugGoingReports();
                                                            DataTable dt = ogr.GetOutGoingTransction(from, to,branch,x);

                                                            byte[] tbl = SerializeX(dt);


                                                            client.Send(new SecPacket(new Packet(new Command(CommandType.GetReport3, new ParamInfo(tbl))), station.Password).ToBytes(0));
                                                        }
                                                        else
                                                        {
                                                            client.Close();
                                                        }
                                                    }


                                                    break;

                                                }

                                            case CommandType.GetReport4:
                                                {

                                                    User user = new User(packet.GetCommand.GetParametersInfo[1].GetBytesArray);

                                                    User u = new User(user.Number);
                                                    {
                                                        if ((u.Number == user.Number) && (u.UserName == user.UserName) && (u.Password == user.Password))
                                                        {
                                                            DateTime from = DateTime.FromOADate(BitConverter.ToDouble(packet.GetCommand.GetParametersInfo[2].GetBytesArray, 0));
                                                            DateTime to = DateTime.FromOADate(BitConverter.ToDouble(packet.GetCommand.GetParametersInfo[3].GetBytesArray, 0));
                                                            BranchInfo branch = new BranchInfo(packet.GetCommand.GetParametersInfo[4].GetBytesArray);
                                                            User user2 = new User(packet.GetCommand.GetParametersInfo[5].GetBytesArray);
                                                            bool x = BitConverter.ToBoolean(packet.GetCommand.GetParametersInfo[6].GetBytesArray, 0);


                                                            OugGoingReports ogr = new OugGoingReports();
                                                            DataTable dt = ogr.GetOutGoingTransction(from, to,branch,user2,x);

                                                            byte[] tbl = SerializeX(dt);


                                                            client.Send(new SecPacket(new Packet(new Command(CommandType.GetReport4, new ParamInfo(tbl))), station.Password).ToBytes(0));
                                                        }
                                                        else
                                                        {
                                                            client.Close();
                                                        }
                                                    }


                                                    break;

                                                }

                                            case CommandType.GetReport5:
                                                {

                                                    User user = new User(packet.GetCommand.GetParametersInfo[1].GetBytesArray);

                                                    User u = new User(user.Number);
                                                    {
                                                        if ((u.Number == user.Number) && (u.UserName == user.UserName) && (u.Password == user.Password))
                                                        {
                                                            DateTime from = DateTime.FromOADate(BitConverter.ToDouble(packet.GetCommand.GetParametersInfo[2].GetBytesArray, 0));
                                                            DateTime to = DateTime.FromOADate(BitConverter.ToDouble(packet.GetCommand.GetParametersInfo[3].GetBytesArray, 0));
                                                            BranchInfo src = new BranchInfo(packet.GetCommand.GetParametersInfo[4].GetBytesArray);
                                                            BranchInfo dst = new BranchInfo(packet.GetCommand.GetParametersInfo[5].GetBytesArray);

                                                            OugGoingReports ogr = new OugGoingReports();
                                                            DataTable dt = ogr.GetOutGoingTransction(from, to,src,dst);

                                                            byte[] tbl = SerializeX(dt);


                                                            client.Send(new SecPacket(new Packet(new Command(CommandType.GetReport5, new ParamInfo(tbl))), station.Password).ToBytes(0));
                                                        }
                                                        else
                                                        {
                                                            client.Close();
                                                        }
                                                    }


                                                    break;

                                                }

                                            case CommandType.GetReport6:
                                                {

                                                    User user = new User(packet.GetCommand.GetParametersInfo[1].GetBytesArray);

                                                    User u = new User(user.Number);
                                                    {
                                                        if ((u.Number == user.Number) && (u.UserName == user.UserName) && (u.Password == user.Password))
                                                        {
                                                            DateTime from = DateTime.FromOADate(BitConverter.ToDouble(packet.GetCommand.GetParametersInfo[2].GetBytesArray, 0));
                                                            DateTime to = DateTime.FromOADate(BitConverter.ToDouble(packet.GetCommand.GetParametersInfo[3].GetBytesArray, 0));
                                                            BranchInfo src = new BranchInfo(packet.GetCommand.GetParametersInfo[4].GetBytesArray);
                                                            BranchInfo dst = new BranchInfo(packet.GetCommand.GetParametersInfo[5].GetBytesArray);
                                                            User user2 = new User(packet.GetCommand.GetParametersInfo[6].GetBytesArray);
                                                            
                                                            OugGoingReports ogr = new OugGoingReports();
                                                            DataTable dt = ogr.GetOutGoingTransction(from, to,src,dst,user2);

                                                            byte[] tbl = SerializeX(dt);


                                                            client.Send(new SecPacket(new Packet(new Command(CommandType.GetReport6, new ParamInfo(tbl))), station.Password).ToBytes(0));
                                                        }
                                                        else
                                                        {
                                                            client.Close();
                                                        }
                                                    }


                                                    break;

                                                }

                                            case CommandType.GetReport7:
                                                {
                                                    User user = new User(packet.GetCommand.GetParametersInfo[1].GetBytesArray);

                                                    User u = new User(user.Number);
                                                    {
                                                        if ((u.Number == user.Number) && (u.UserName == user.UserName) && (u.Password == user.Password))
                                                        {
                                                            DateTime from = DateTime.FromOADate(BitConverter.ToDouble(packet.GetCommand.GetParametersInfo[2].GetBytesArray, 0));
                                                            DateTime to = DateTime.FromOADate(BitConverter.ToDouble(packet.GetCommand.GetParametersInfo[3].GetBytesArray, 0));

                                                            InComingReports ict = new InComingReports();
                                                            DataTable dt =ict.GetInComingTransction(from, to);

                                                            byte[] tbl = SerializeX(dt);


                                                            client.Send(new SecPacket(new Packet(new Command(CommandType.GetReport7, new ParamInfo(tbl))), station.Password).ToBytes(0));
                                                        }
                                                        else
                                                        {
                                                            client.Close();
                                                        }
                                                    }


                                                    break;

                                                }

                                            case CommandType.GetReport8:
                                                {

                                                    User user = new User(packet.GetCommand.GetParametersInfo[1].GetBytesArray);

                                                    User u = new User(user.Number);
                                                    {
                                                        if ((u.Number == user.Number) && (u.UserName == user.UserName) && (u.Password == user.Password))
                                                        {
                                                            DateTime from = DateTime.FromOADate(BitConverter.ToDouble(packet.GetCommand.GetParametersInfo[2].GetBytesArray, 0));
                                                            DateTime to = DateTime.FromOADate(BitConverter.ToDouble(packet.GetCommand.GetParametersInfo[3].GetBytesArray, 0));
                                                            User user2 = new User(packet.GetCommand.GetParametersInfo[4].GetBytesArray);

                                                            InComingReports ict = new InComingReports();
                                                            DataTable dt = ict.GetInComingTransction(from, to, user2);

                                                            byte[] tbl = SerializeX(dt);


                                                            client.Send(new SecPacket(new Packet(new Command(CommandType.GetReport8, new ParamInfo(tbl))), station.Password).ToBytes(0));
                                                        }
                                                        else
                                                        {
                                                            client.Close();
                                                        }
                                                    }



                                                    break;

                                                }

                                            case CommandType.GetReport9:
                                                {

                                                    User user = new User(packet.GetCommand.GetParametersInfo[1].GetBytesArray);

                                                    User u = new User(user.Number);
                                                    {
                                                        if ((u.Number == user.Number) && (u.UserName == user.UserName) && (u.Password == user.Password))
                                                        {
                                                            DateTime from = DateTime.FromOADate(BitConverter.ToDouble(packet.GetCommand.GetParametersInfo[2].GetBytesArray, 0));
                                                            DateTime to = DateTime.FromOADate(BitConverter.ToDouble(packet.GetCommand.GetParametersInfo[3].GetBytesArray, 0));
                                                            BranchInfo branch = new BranchInfo(packet.GetCommand.GetParametersInfo[4].GetBytesArray);
                                                            bool x = BitConverter.ToBoolean(packet.GetCommand.GetParametersInfo[5].GetBytesArray, 0);

                                                            InComingReports ict = new InComingReports();
                                                            DataTable dt = ict.GetInComingTransction(from, to, branch, x);

                                                            byte[] tbl = SerializeX(dt);


                                                            client.Send(new SecPacket(new Packet(new Command(CommandType.GetReport9, new ParamInfo(tbl))), station.Password).ToBytes(0));
                                                        }
                                                        else
                                                        {
                                                            client.Close();
                                                        }
                                                    }
                                                    break;

                                                }

                                            case CommandType.GetReport10:
                                                {

                                                    User user = new User(packet.GetCommand.GetParametersInfo[1].GetBytesArray);

                                                    User u = new User(user.Number);
                                                    {
                                                        if ((u.Number == user.Number) && (u.UserName == user.UserName) && (u.Password == user.Password))
                                                        {
                                                            DateTime from = DateTime.FromOADate(BitConverter.ToDouble(packet.GetCommand.GetParametersInfo[2].GetBytesArray, 0));
                                                            DateTime to = DateTime.FromOADate(BitConverter.ToDouble(packet.GetCommand.GetParametersInfo[3].GetBytesArray, 0));
                                                            BranchInfo branch = new BranchInfo(packet.GetCommand.GetParametersInfo[4].GetBytesArray);
                                                            User user2 = new User(packet.GetCommand.GetParametersInfo[5].GetBytesArray);
                                                            bool x = BitConverter.ToBoolean(packet.GetCommand.GetParametersInfo[6].GetBytesArray, 0);


                                                            InComingReports ict = new InComingReports();
                                                            DataTable dt = ict.GetInComingTransction(from, to, branch, user2, x);

                                                            byte[] tbl = SerializeX(dt);


                                                            client.Send(new SecPacket(new Packet(new Command(CommandType.GetReport10, new ParamInfo(tbl))), station.Password).ToBytes(0));
                                                        }
                                                        else
                                                        {
                                                            client.Close();
                                                        }
                                                    }


                                                    break;

                                                }

                                            case CommandType.GetReport11:
                                                {
                                                    User user = new User(packet.GetCommand.GetParametersInfo[1].GetBytesArray);

                                                    User u = new User(user.Number);
                                                    {
                                                        if ((u.Number == user.Number) && (u.UserName == user.UserName) && (u.Password == user.Password))
                                                        {
                                                            DateTime from = DateTime.FromOADate(BitConverter.ToDouble(packet.GetCommand.GetParametersInfo[2].GetBytesArray, 0));
                                                            DateTime to = DateTime.FromOADate(BitConverter.ToDouble(packet.GetCommand.GetParametersInfo[3].GetBytesArray, 0));
                                                            BranchInfo src = new BranchInfo(packet.GetCommand.GetParametersInfo[4].GetBytesArray);
                                                            BranchInfo dst = new BranchInfo(packet.GetCommand.GetParametersInfo[5].GetBytesArray);


                                                            InComingReports ict = new InComingReports();
                                                            DataTable dt = ict.GetInComingTransction(from, to, src, dst);

                                                            byte[] tbl = SerializeX(dt);


                                                            client.Send(new SecPacket(new Packet(new Command(CommandType.GetReport11, new ParamInfo(tbl))), station.Password).ToBytes(0));
                                                        }
                                                        else
                                                        {
                                                            client.Close();
                                                        }
                                                    }


                                                    break;

                                                }

                                            case CommandType.GetReport12:
                                                {
                                                    User user = new User(packet.GetCommand.GetParametersInfo[1].GetBytesArray);

                                                    User u = new User(user.Number);
                                                    {
                                                        if ((u.Number == user.Number) && (u.UserName == user.UserName) && (u.Password == user.Password))
                                                        {
                                                            DateTime from = DateTime.FromOADate(BitConverter.ToDouble(packet.GetCommand.GetParametersInfo[2].GetBytesArray, 0));
                                                            DateTime to = DateTime.FromOADate(BitConverter.ToDouble(packet.GetCommand.GetParametersInfo[3].GetBytesArray, 0));
                                                            BranchInfo src = new BranchInfo(packet.GetCommand.GetParametersInfo[4].GetBytesArray);
                                                            BranchInfo dst = new BranchInfo(packet.GetCommand.GetParametersInfo[5].GetBytesArray);
                                                            User user2 = new User(packet.GetCommand.GetParametersInfo[6].GetBytesArray);


                                                            InComingReports ict = new InComingReports();
                                                            DataTable dt = ict.GetInComingTransction(from, to, src, dst, user2);

                                                            byte[] tbl = SerializeX(dt);


                                                            client.Send(new SecPacket(new Packet(new Command(CommandType.GetReport12, new ParamInfo(tbl))), station.Password).ToBytes(0));
                                                        }
                                                        else
                                                        {
                                                            client.Close();
                                                        }
                                                    }
                                                    break;

                                                }

                                        }
                                    }

                                    if (all_data.Count >= 8)
                                    {
                                        bf_size = BitConverter.ToInt32(all_data.ToArray(), 0);
                                    }

                                } while (((all_data.Count) >= bf_size)&&(is_running));
                            }

                        }
                        else
                        {
                            client.Close();
                        }

                    } while ((client.Connected) && (is_running));

                }
                catch
                {
                    client.Close();
                }

            }
            catch
            {

            }
        }

        static private byte[] GetMD5HashInBytes(byte[] ar)
        {
            using (MD5 md5Hash = MD5.Create())
            {
                byte[] data = md5Hash.ComputeHash(ar);
                return data;
            }
        }

    }
}
