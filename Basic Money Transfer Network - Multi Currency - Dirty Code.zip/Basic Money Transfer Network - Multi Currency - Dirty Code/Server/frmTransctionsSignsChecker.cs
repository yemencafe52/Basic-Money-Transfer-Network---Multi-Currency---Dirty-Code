﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YMT
{
    public partial class frmTransctionsSignsChecker : Form
    {

        private bool state = false;
        public frmTransctionsSignsChecker()
        {
            InitializeComponent();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == (Keys.Shift | Keys.Escape))
            {   
                {
                    this.Close();
                }
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }



        private void frmTransctionsSignsChecker_Load(object sender, EventArgs e)
        {
            toolStripComboBox1.SelectedIndex = 0;
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            toolStripButton1.Enabled = false;
            toolStripButton2.Enabled = true;
            toolStripComboBox1.Enabled = true;

            //toolStripProgressBar1.Value = 0;
            state = false;
        }

        private void Start()
        {
            try
            {

                toolStripButton1.Enabled = true;
                toolStripButton2.Enabled = false;
                toolStripComboBox1.Enabled = false;

                if (toolStripComboBox1.SelectedIndex == 0)
                {
                    OugGoingReports ogr = new OugGoingReports();

                    List<int> numbers = ogr.GetOutGoingTransctionNumbers();
                    state = true;
                    LV.Items.Clear();

                    for (int i = 0; i < numbers.Count; i++)
                    {
                        if (state == false)
                        {
                            break;
                        }

                        TransferOutGoing ogt = new TransferOutGoing(numbers[i]);
                        bool res = true;

                        if (ogt.GetHash != ogt.GetCurrentHASH)
                        {
                            res = false;
                        }

                        ListViewItem lvi = new ListViewItem(ogt.Number.ToString());
                        lvi.SubItems.Add(ogt.Currency.CurrencyName);
                        lvi.SubItems.Add(ogt.FAmount.ToString());
                        lvi.SubItems.Add(ogt.Date.ToString());

                        if (res)
                        {
                            lvi.SubItems.Add(lvi.SubItems.Add("OK"));
                        }
                        else
                        {
                            lvi.SubItems.Add(lvi.SubItems.Add("OPPS :(, Falied"));
                            lvi.ForeColor = Color.Red;
                        }

                        LV.Items.Add(lvi);
                        LV.EnsureVisible(LV.Items.Count - 1);

                        toolStripProgressBar1.Minimum = 0;
                        toolStripProgressBar1.Maximum = numbers.Count - 1;
                        toolStripProgressBar1.Value = i;

                        toolStripStatusLabel2.Text = i.ToString();

                        Application.DoEvents();

                    }
                }
                else
                {
                    InComingReports ir = new InComingReports();

                    List<int> numbers = ir.GetInComingTransctionNumbers();

                    state = true;
                    LV.Items.Clear();

                    for (int i = 0; i < numbers.Count; i++)
                    {
                        if (state == false)
                        {
                            break;
                        }

                        TransferIncoming ti = new TransferIncoming(numbers[i]);
                        bool res = true;

                        if (ti.GetHash != ti.GetCurrentHASH)
                        {
                            res = false;
                        }

                        ListViewItem lvi = new ListViewItem(ti.TransferOutGoingInfo.Number.ToString());
                        lvi.SubItems.Add(ti.TransferOutGoingInfo.Currency.CurrencyName);
                        lvi.SubItems.Add(ti.TransferOutGoingInfo.FAmount.ToString());
                        lvi.SubItems.Add(ti.Date.ToString());

                        if (res)
                        {
                            lvi.SubItems.Add(lvi.SubItems.Add("OK"));
                        }
                        else
                        {
                            lvi.SubItems.Add(lvi.SubItems.Add("OPPS :(, Falied"));
                            lvi.ForeColor = Color.Red;
                        }

                        LV.Items.Add(lvi);
                        LV.EnsureVisible(LV.Items.Count - 1);

                        toolStripProgressBar1.Minimum = 0;
                        toolStripProgressBar1.Maximum = numbers.Count - 1;
                        toolStripProgressBar1.Value = i;

                        toolStripStatusLabel2.Text = i.ToString();

                        Application.DoEvents();

                    }

                }


                toolStripButton1.Enabled = false;
                toolStripButton2.Enabled = true;
                toolStripComboBox1.Enabled = true;

                toolStripProgressBar1.Value = 0;
                state = false;
            }
            catch
            {
            }

            
        }

        private void frmTransctionsSignsChecker_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.state)
            {
                MessageBox.Show("يجب إيقاف العملية أولاً", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                e.Cancel = true;

            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            Start();
        }
    }
}
