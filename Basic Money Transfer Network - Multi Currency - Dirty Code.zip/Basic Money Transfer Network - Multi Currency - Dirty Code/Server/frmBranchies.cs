﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YMT
{
    public partial class frmBranchies : Form
    {
        public frmBranchies()
        {
            InitializeComponent();
        }




        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {

            if (keyData == (Keys.Control | Keys.R))
            {

                toolStripButton1.PerformClick();
                return true;
            }

          
            if (keyData == (Keys.Control | Keys.N))
            {

                toolStripButton5.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.E))
            {
                toolStripButton4.PerformClick();
                return true;
            }

            if (keyData == (Keys.Shift | Keys.Escape))
            {
                {
                    this.Close();
                }
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }


        private void frmBranchies_Load(object sender, EventArgs e)
        {
            this.CenterToScreen();
            Reset();
        }

        private void DisplayResults(List<BranchInfo> branchies)
        {

            LV.Items.Clear();
            foreach (BranchInfo b in branchies)
            {
                ListViewItem lvi = new ListViewItem(b.BranchNumber.ToString()); ;

                //lvi.SubItems.Add(b.BranchName);
                lvi.SubItems.Add(b.BranchAddress.ToString());

                lvi.SubItems.Add(b.BranchPhone.ToString());
                LV.Items.Add(lvi);
            }

            toolStripStatusLabel2.Text = LV.Items.Count.ToString();

        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            frmBranchInfo fbi = new frmBranchInfo();
            fbi.ShowDialog();
        }

        private void LV_DoubleClick(object sender, EventArgs e)
        {
            if (LV.SelectedItems.Count > 0)
            {
                int index = int.Parse(LV.SelectedItems[0].Text.ToString());
                BranchInfo b = new BranchInfo((byte)index);
                frmBranchInfo fb = new frmBranchInfo(b);
                fb.ShowDialog();
            }
        }

        private void Reset()
        {
            List<BranchInfo> branchies = BranchInfoManager.GetALLBranchInfo();
            DisplayResults(branchies);
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Reset();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            if (LV.SelectedItems.Count > 0)
            {
                int index = int.Parse(LV.SelectedItems[0].Text.ToString());
                BranchInfo b = new BranchInfo((byte)index);
                frmBranchInfo fb = new frmBranchInfo(b);   
                fb.ShowDialog();
            
            }
        }
    }
}
