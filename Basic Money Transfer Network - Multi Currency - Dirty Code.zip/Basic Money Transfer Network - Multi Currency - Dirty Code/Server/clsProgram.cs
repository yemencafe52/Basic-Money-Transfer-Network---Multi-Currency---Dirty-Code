﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Globalization;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace YMT
{
    public class TTT
    {
        public int A
        {
            get
            {
                return 0;
            }
        }

        public int N
        {
            get
            {
                return 0;
            }
        }

    }
    public static class Program
    {
        public static int counter = 0;
        static Mutex s_Mutex;
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, " بدأ تشغيل النظام ... ", MSGTYPE.Info), DateTime.Now));

            Calendar defaultCalendar = CultureInfo.CurrentCulture.Calendar;

            if (!(defaultCalendar is GregorianCalendar))
            {
                SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "يجب أن يكون تقويم نظام ويندوز كـ تقويم ميلادي ( تسمية إنجليزية)", MSGTYPE.Error), DateTime.Now));
                MessageBox.Show("يجب ضبط تقويم نظام ويندوز كـ تقويم ميلادي (أنجليزي).", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }

            if (Utilities.IsNTAdmin(0, 0) == false)
            {
                SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "  يجب تشغيل النظام كمسؤول .", MSGTYPE.Error), DateTime.Now));
                MessageBox.Show("يجب تشغيل النظام تحت إمتيازات حساب مسؤول Administrator", "", MessageBoxButtons.OK, MessageBoxIcon.Stop, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }

            bool instantiated;

            s_Mutex = new Mutex(false, "Local\\EG{F6F244AB-669D-41B2-9F30-8DD9E5AC9AE1}", out instantiated);

            if (!instantiated)
            {
                SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "النظام يعمل حالياً", MSGTYPE.Error), DateTime.Now));
                MessageBox.Show("النظام يعمل حالياً", "  ", MessageBoxButtons.OK, MessageBoxIcon.Stop, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }

            if (!(Utilities.CheckDatabase()))
            {
                SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تعذر العثور على قاعدة البيانات", MSGTYPE.Error), DateTime.Now));
                DialogResult res = MessageBox.Show("تعذر العثور على قاعدة البيانات , هل تريد إستعادة قاعدة بيانات إحتياطية؟ , عند النقر على لا , سيتم إنشاء قاعدة بيانات جديدة.", " ", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2, MessageBoxOptions.RtlReading);
                if (res == DialogResult.Yes)
                {

                    OpenFileDialog ofd = new OpenFileDialog();

                    ofd.InitialDirectory = "c:\\";
                    ofd.Filter = "Access Database Backup files (*.bak)|*.bak";
                    ofd.FilterIndex = 2;
                    ofd.RestoreDirectory = true;

                    if (ofd.ShowDialog() == DialogResult.OK)
                    {
                        if (ofd.FileNames.Count() > 0)
                        {

                            if (Utilities.RestoreDatabase(ofd.FileNames[0]))
                            {
                                SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, " تم إستعادة البيانات بنجاح ", MSGTYPE.Info), DateTime.Now));
                                MessageBox.Show("تم إستعادة قاعدة البيانات بنجاح.", " ", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                            }
                            else
                            {
                                SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "  تعذر إستعادة قاعدة البيانات", MSGTYPE.Error), DateTime.Now));
                                MessageBox.Show("تعذر إستعادة قاعدة البيانات. ", " ", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                                return;
                            }
                        }
                    }
                    else
                    {
                        SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "  تعذر إستعادة قاعدة البيانات", MSGTYPE.Error), DateTime.Now));
                        MessageBox.Show("تعذر إستعادة قاعدة البيانات. ", " ", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                        return;
                    }

                }
                else
                {
                    if (Utilities.InstallDateBase())
                    {
                        SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "  تم إنشاء قاعدة بيانات جديدة بنجاح", MSGTYPE.Info), DateTime.Now));
                        MessageBox.Show("تم إنشاء قاعدة بيانات جديدة بنجاح.", " ", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                    }
                    else
                    {
                        MessageBox.Show("تعذر إنشاء قاعدة البيانات. ", " ", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                        return;
                    }
                }
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            NetworkInformation ni = new NetworkInformation(1);

            Utilities.ip = ni.DNS;
            Utilities.network_name = ni.Name;

            if (!Server.StartListeing())
            {
                SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "  تعذر تنصت النظام   ", MSGTYPE.Error), DateTime.Now));
                MessageBox.Show("تعذر التنصت.. ", " ", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }

            SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "جاري التنصت على المنفذ 888", MSGTYPE.Info), DateTime.Now));

            frmLogin flogin = new frmLogin();
            flogin.ShowDialog();

            if (flogin.IsLogined)
            {
                Application.Run(new frmMain());
            }

            SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, " إيقاف تشغيل النظام ", MSGTYPE.Info), DateTime.Now));
        }

    }
}





















