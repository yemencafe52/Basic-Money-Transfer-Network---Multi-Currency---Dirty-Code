﻿namespace YMT
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("المعطيات العامة");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("العملات");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("النقاط");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("العمولات");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("المحطات");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("الإعدادات", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3,
            treeNode4,
            treeNode5});
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("الحوالات");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("التقارير", new System.Windows.Forms.TreeNode[] {
            treeNode7});
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("الحوالات", new System.Windows.Forms.TreeNode[] {
            treeNode8});
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("التواقيع");
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("المستخدمين");
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("السجل");
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("الأمان", new System.Windows.Forms.TreeNode[] {
            treeNode10,
            treeNode11,
            treeNode12});
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("عمل نسخة إحتياطية لقاعدة البيانات");
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("إستعادة قاعدة البيانات الإحتياطية");
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("الصيانة", new System.Windows.Forms.TreeNode[] {
            treeNode14,
            treeNode15});
            System.Windows.Forms.TreeNode treeNode17 = new System.Windows.Forms.TreeNode("Ctrl + N = إضافة");
            System.Windows.Forms.TreeNode treeNode18 = new System.Windows.Forms.TreeNode("Ctrl + S = حفظ");
            System.Windows.Forms.TreeNode treeNode19 = new System.Windows.Forms.TreeNode("Ctrl + E = تعديل");
            System.Windows.Forms.TreeNode treeNode20 = new System.Windows.Forms.TreeNode("Ctrl + Del = حذف");
            System.Windows.Forms.TreeNode treeNode21 = new System.Windows.Forms.TreeNode("Ctrl + F = بحث");
            System.Windows.Forms.TreeNode treeNode22 = new System.Windows.Forms.TreeNode("Ctrl + R = تحديث");
            System.Windows.Forms.TreeNode treeNode23 = new System.Windows.Forms.TreeNode("Ctrl + P = طباعة");
            System.Windows.Forms.TreeNode treeNode24 = new System.Windows.Forms.TreeNode("Shift + Esc = إلغاء , إغلاق");
            System.Windows.Forms.TreeNode treeNode25 = new System.Windows.Forms.TreeNode("تعليمات", new System.Windows.Forms.TreeNode[] {
            treeNode17,
            treeNode18,
            treeNode19,
            treeNode20,
            treeNode21,
            treeNode22,
            treeNode23,
            treeNode24});
            System.Windows.Forms.TreeNode treeNode26 = new System.Windows.Forms.TreeNode("enjoy :)");
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.الصيانةToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.السيرفرToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.إغلاقToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.عرضToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.السجلToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel5 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel4 = new System.Windows.Forms.ToolStripStatusLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.TV = new System.Windows.Forms.TreeView();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.عرضToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(449, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.الصيانةToolStripMenuItem,
            this.toolStripMenuItem1,
            this.السيرفرToolStripMenuItem,
            this.toolStripSeparator1,
            this.إغلاقToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(42, 20);
            this.fileToolStripMenuItem.Text = "ملف";
            // 
            // الصيانةToolStripMenuItem
            // 
            this.الصيانةToolStripMenuItem.Name = "الصيانةToolStripMenuItem";
            this.الصيانةToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.الصيانةToolStripMenuItem.Text = "الصيانة";
            this.الصيانةToolStripMenuItem.Visible = false;
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(197, 6);
            this.toolStripMenuItem1.Visible = false;
            // 
            // السيرفرToolStripMenuItem
            // 
            this.السيرفرToolStripMenuItem.Checked = true;
            this.السيرفرToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.السيرفرToolStripMenuItem.Name = "السيرفرToolStripMenuItem";
            this.السيرفرToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.السيرفرToolStripMenuItem.Text = "السيرفر يعمل في الخدمة؟";
            this.السيرفرToolStripMenuItem.Click += new System.EventHandler(this.السيرفرToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(197, 6);
            // 
            // إغلاقToolStripMenuItem
            // 
            this.إغلاقToolStripMenuItem.Name = "إغلاقToolStripMenuItem";
            this.إغلاقToolStripMenuItem.Size = new System.Drawing.Size(200, 22);
            this.إغلاقToolStripMenuItem.Text = "إغلاق";
            this.إغلاقToolStripMenuItem.Click += new System.EventHandler(this.إغلاقToolStripMenuItem_Click);
            // 
            // عرضToolStripMenuItem
            // 
            this.عرضToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.السجلToolStripMenuItem});
            this.عرضToolStripMenuItem.Name = "عرضToolStripMenuItem";
            this.عرضToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
            this.عرضToolStripMenuItem.Text = "عرض";
            this.عرضToolStripMenuItem.Click += new System.EventHandler(this.عرضToolStripMenuItem_Click);
            // 
            // السجلToolStripMenuItem
            // 
            this.السجلToolStripMenuItem.DoubleClickEnabled = true;
            this.السجلToolStripMenuItem.Name = "السجلToolStripMenuItem";
            this.السجلToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.السجلToolStripMenuItem.Text = "السجل";
            this.السجلToolStripMenuItem.Click += new System.EventHandler(this.السجلToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.aboutToolStripMenuItem.Text = "حول";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel5,
            this.toolStripStatusLabel3,
            this.toolStripStatusLabel4});
            this.statusStrip1.Location = new System.Drawing.Point(0, 214);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(449, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(43, 17);
            this.toolStripStatusLabel1.Text = "Admin";
            this.toolStripStatusLabel1.Click += new System.EventHandler(this.toolStripStatusLabel1_Click);
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(65, 17);
            this.toolStripStatusLabel2.Text = "21/21/2021";
            // 
            // toolStripStatusLabel5
            // 
            this.toolStripStatusLabel5.Name = "toolStripStatusLabel5";
            this.toolStripStatusLabel5.Size = new System.Drawing.Size(255, 17);
            this.toolStripStatusLabel5.Spring = true;
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.AutoSize = false;
            this.toolStripStatusLabel3.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(36, 17);
            // 
            // toolStripStatusLabel4
            // 
            this.toolStripStatusLabel4.AutoSize = false;
            this.toolStripStatusLabel4.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripStatusLabel4.Name = "toolStripStatusLabel4";
            this.toolStripStatusLabel4.Size = new System.Drawing.Size(35, 17);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // TV
            // 
            this.TV.Dock = System.Windows.Forms.DockStyle.Left;
            this.TV.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.TV.FullRowSelect = true;
            this.TV.Location = new System.Drawing.Point(0, 24);
            this.TV.Name = "TV";
            treeNode1.Name = "Node3";
            treeNode1.Text = "المعطيات العامة";
            treeNode2.Name = "Currencies";
            treeNode2.Text = "العملات";
            treeNode3.Name = "Node1";
            treeNode3.Text = "النقاط";
            treeNode4.Name = "Node233";
            treeNode4.Text = "العمولات";
            treeNode5.Name = "Node20";
            treeNode5.Text = "المحطات";
            treeNode6.Checked = true;
            treeNode6.Name = "settings";
            treeNode6.Text = "الإعدادات";
            treeNode7.Name = "Node16";
            treeNode7.Text = "الحوالات";
            treeNode8.Name = "Node0";
            treeNode8.Text = "التقارير";
            treeNode9.Name = "Node0";
            treeNode9.Text = "الحوالات";
            treeNode10.Name = "Node2";
            treeNode10.Text = "التواقيع";
            treeNode11.Name = "Users";
            treeNode11.Text = "المستخدمين";
            treeNode12.Name = "Node100";
            treeNode12.Text = "السجل";
            treeNode13.Name = "Security";
            treeNode13.Text = "الأمان";
            treeNode14.Name = "BackupDB";
            treeNode14.Text = "عمل نسخة إحتياطية لقاعدة البيانات";
            treeNode15.Name = "RestoreDB";
            treeNode15.Text = "إستعادة قاعدة البيانات الإحتياطية";
            treeNode16.Name = "Node0";
            treeNode16.Text = "الصيانة";
            treeNode17.Name = "Node0";
            treeNode17.Text = "Ctrl + N = إضافة";
            treeNode18.Name = "Node2";
            treeNode18.Text = "Ctrl + S = حفظ";
            treeNode19.Name = "Node1";
            treeNode19.Text = "Ctrl + E = تعديل";
            treeNode20.Name = "Node2";
            treeNode20.Text = "Ctrl + Del = حذف";
            treeNode21.Name = "Node3";
            treeNode21.Text = "Ctrl + F = بحث";
            treeNode22.Name = "Node0";
            treeNode22.Text = "Ctrl + R = تحديث";
            treeNode23.Name = "Node3";
            treeNode23.Text = "Ctrl + P = طباعة";
            treeNode24.Name = "Node7";
            treeNode24.Text = "Shift + Esc = إلغاء , إغلاق";
            treeNode25.Name = "d";
            treeNode25.Text = "تعليمات";
            treeNode26.Name = "s";
            treeNode26.Text = "enjoy :)";
            this.TV.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode6,
            treeNode9,
            treeNode13,
            treeNode16,
            treeNode25,
            treeNode26});
            this.TV.RightToLeftLayout = true;
            this.TV.Size = new System.Drawing.Size(214, 190);
            this.TV.TabIndex = 9;
            this.TV.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterSelect);
            this.TV.DoubleClick += new System.EventHandler(this.TV_DoubleClick);
            this.TV.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TV_KeyDown);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(449, 236);
            this.Controls.Add(this.TV);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.KeyPreview = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "تحويل أموال ";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.Shown += new System.EventHandler(this.frmMain_Shown);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TreeView TV;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel4;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel5;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem الصيانةToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem إغلاقToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem السيرفرToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem عرضToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem السجلToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    }
}

