﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YMT
{
    public partial class frmUsers : Form
    {
        public frmUsers()
        {
            InitializeComponent();
            
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {

            if (keyData == (Keys.Control | Keys.F))
            {
                bindingNavigator3.Focus();
                return true;
            }

            if (keyData == (Keys.Control | Keys.N))
            {

                toolStripButton5.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.E))
            {
                toolStripButton2.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.S))
            {
                toolStripButton1.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.Delete))
            {
                toolStripButton6.PerformClick();
                return true;
            }

            if (keyData == (Keys.Shift | Keys.Escape))
            {
                if (toolStripButton1.Enabled)
                {
                    toolStripButton3.PerformClick();
                }
                else
                {
                    this.Close();
                }
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void frmUsers_Load(object sender, EventArgs e)
        {

            Init();

        }

        private bool Init()
        {
            bool res = false;

            try
            {
                bindingSource.Clear();
                bindingSource.DataSource = Users.GetUsers();
                bindingNavigator1.BindingSource = bindingSource;
                bindingNavigator3.BindingSource = bindingSource;
                DisplayData();
                res = true;
            }
            catch
            {
                res = false;
            }

            return res;
        }

        private void DisplayData()
        {

            bindingNavigator1.Enabled = true;
            bindingNavigator3.Enabled = true;

            toolStripButton5.Enabled = true;
            toolStripButton6.Enabled = true;

            toolStripButton1.Enabled = false;

            toolStripButton3.Enabled = false;
            toolStripButton2.Enabled = true;

            comboBox1.Enabled = false;

            textBox2.Enabled = false;
            textBox3.Enabled = false;

            groupBox1.Enabled = false;

            if (Utilities.user.Number != 1)
            {
                toolStripButton5.Visible = false;
                toolStripButton6.Visible = false;
                bindingNavigator3.Visible = false;
                bindingSource.Clear();
                bindingSource.Add(Utilities.user);
                groupBox1.Visible = false;
                this.Height = 256;
                toolStripButton4.Visible = false;
            }


        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("هل تريد حذف المستخدم فعلاً؟", "تاكيد الحذف", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
            if (res == System.Windows.Forms.DialogResult.Yes)
            {
                User user = (User)bindingSource.Current;
                if (user.Number == 1)
                {
                    MessageBox.Show("تعذر عملية الحذف.", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                    return;
                }
                if (Users.DeleteUser(user))
                {
                    bindingSource.Remove(bindingSource.Current);
                    //DisplayData();
                    bindingSource.DataSource = Users.GetUsers();
                    bindingNavigator1.BindingSource = bindingSource;
                    bindingNavigator3.BindingSource = bindingSource;
                    DisplayData();
                }
                else
                {
                    MessageBox.Show("تعذر عملية الحذف.", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                }
            }
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            bindingSource.AddNew();

            bindingNavigator3.Enabled = false;

            toolStripButton5.Enabled = false;
            toolStripButton6.Enabled = false;

            toolStripButton1.Enabled = true;
            toolStripButton3.Enabled = true;
            toolStripButton2.Enabled = false;

            comboBox1.Enabled = true;

            textBox2.Enabled = true;
            textBox3.Enabled = true;

            groupBox1.Enabled = true;
            comboBox1.Focus();



        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {

            //DisplayData();

            bindingSource.DataSource = Users.GetUsers();
            bindingNavigator1.BindingSource = bindingSource;
            bindingNavigator3.BindingSource = bindingSource;
            DisplayData();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (Server.IsRunning)
            {
                MessageBox.Show("يجب إيقاف السيرفر أولاً.", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                return;
            }

            try
            {
                if (string.IsNullOrEmpty(comboBox1.Text))
                {
                    comboBox1.Focus();

                    throw new Exception("عفواً , أدخل اسم المتسخدم اأولاً . ");
                }

                if (string.IsNullOrEmpty(textBox2.Text))
                {
                    throw new Exception("عفواً , أدخل كلمة المرور  . ");
                }

                if (textBox2.Text != textBox3.Text)
                {
                    throw new Exception("كلمة المرور غير متطابقة ");
                }

                bindingSource.EndEdit();
                User user = (User)bindingSource.Current;
                user.Password = Utilities.GetMD5Hash(textBox2.Text);


                if (comboBox1.Enabled == true)
                {

                    if (Users.CreateUser(user))
                    {
                        //DisplayData();
                        bindingSource.DataSource = Users.GetUsers();
                        bindingNavigator1.BindingSource = bindingSource;
                        bindingNavigator3.BindingSource = bindingSource;
                        DisplayData();
                    }
                    else
                    {
                        MessageBox.Show("تعذر عملية الإضافة.", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                    }
                }
                else
                {

                    if (Users.UpdateUser(user))
                    {
                        //DisplayData();
                        bindingSource.DataSource = Users.GetUsers();
                        bindingNavigator1.BindingSource = bindingSource;
                        bindingNavigator3.BindingSource = bindingSource;
                        DisplayData();
                    }
                    else
                    {
                        MessageBox.Show("تعذر عملية الحفظ.", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, " ", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                //MessageBox.Show(ex.Message);
            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {

            bindingNavigator3.Enabled = false;


            toolStripButton5.Enabled = false;
            toolStripButton6.Enabled = false;

            toolStripButton1.Enabled = true;
            toolStripButton3.Enabled = true;
            toolStripButton2.Enabled = false;

            comboBox1.Enabled = false;

            textBox2.Enabled = true;
            textBox3.Enabled = true;
            textBox2.Text = "";
            textBox3.Text = "";
            groupBox1.Enabled = true;

            User user = (User)bindingSource.Current;
            if (user.Number == 1)
            {
                groupBox1.Enabled = false;
                toolStripButton6.Enabled = false;
            }
           
           
        }

        private void bindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (bindingSource.Current != null)
            {
                User user = (User)bindingSource.Current;
                if (user.Number == 1)
                {
                    groupBox1.Enabled = false;
                    groupBox1.Visible = true;
                    toolStripButton6.Enabled = false;
                    //this.Height = 205;
                }
                else
                {
                    if (Utilities.user.Number == 1)
                    {
                        groupBox1.Visible = true;
                        toolStripButton6.Enabled = true;
                        //this.Height = 300;
                        groupBox3.Enabled = true;
                    }
                    else
                    {
                        groupBox3.Enabled = false;
                        groupBox1.Visible = true;
                        groupBox1.Visible = false;
                        toolStripButton6.Enabled = false;

                       
                        this.Height = 256;

                        //this.Height = 205;
                    }

                }
            }

            if (bindingSource.Current != null)
            {
                User user = bindingSource.Current as User;
                if (user.IsStopped)
                {


                    toolStripButton4.Text = "قيد العمل";

                }
                else
                {

                    toolStripButton4.Text = "توقيـــف";

                }

            }
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {

            if (bindingSource.Current != null)
            {
                User user = bindingSource.Current as User;
                if (user.IsStopped)
                {
                    if (Users.EnableUser(user))
                    {
                        toolStripButton4.Text = "قيد العمل";


                        Init();



                    }
                }
                else
                {
                    if (Users.DisableUser(user))
                    {
                        toolStripButton4.Text = "توقيـــف";
                        Init();
                    }
                }

            }

        }

        private void bindingSource_BindingComplete(object sender, BindingCompleteEventArgs e)
        {
            
        }
    }
}
