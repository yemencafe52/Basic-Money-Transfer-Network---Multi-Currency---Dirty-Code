﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YMT
{
    public partial class frmCommission : Form
    {
        public frmCommission()
        {
            InitializeComponent();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {

            if (keyData == (Keys.Control | Keys.Delete))
            {
                toolStripButton1.PerformClick();
                //button5.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.F))
            {
                //button5.PerformClick();
                //return true;
            }

            if (keyData == (Keys.Control | Keys.P))
            {
                //button2.PerformClick();
                //return true;
            }

            if (keyData == (Keys.Control | Keys.N))
            {
                toolStripButton5.PerformClick();
               
                return true;
            }

            if (keyData == (Keys.Control | Keys.E))
            {

                toolStripButton4.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.S))
            {
                //button7.PerformClick();
                return true;
            }

            if (keyData == (Keys.Shift | Keys.Escape))
            {
                //if (button7.Enabled)
                //{
                //    button6.PerformClick();
                //}
                //else
                {
                    this.Close();
                }
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void frmCommission_Load(object sender, EventArgs e)
        {
            this.CenterToScreen();
            Reset();
        }

        private void DisplayResults(List<Commission> commissions)
        {

            LV.Items.Clear();
            foreach (Commission c in commissions)
            {
                ListViewItem lvi = new ListViewItem(c.CommissionID.ToString()); ;

                lvi.SubItems.Add(c.FromBranch.BranchNumber.ToString());
                lvi.SubItems.Add(c.Currency.CurrencyName);
                lvi.SubItems.Add(c.ToBranch.BranchNumber.ToString());

                lvi.SubItems.Add(c.FromAmount.ToString());
                lvi.SubItems.Add(c.ToAmount.ToString());

                if (c.CommissionTypeInfo == CommissionType.Value)
                {
                    lvi.SubItems.Add("مبلغ");
                }
                else
                {
                    lvi.SubItems.Add("نسبة");
                }
                lvi.SubItems.Add(c.CommissionValue.ToString());

                if (c.CommissionTypeInfo2 == CommissionType.Value)
                {
                    lvi.SubItems.Add("مبلغ");
                }
                else
                {
                    lvi.SubItems.Add("نسبة");
                }

                lvi.SubItems.Add(c.CommissionValue2.ToString());


                LV.Items.Add(lvi);
               
            }

            toolStripStatusLabel2.Text = LV.Items.Count.ToString();
            
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            frmCommissionManager fcm = new frmCommissionManager();
            fcm.ShowDialog();
        }

        private void LV_DoubleClick(object sender, EventArgs e)
        {
            if (LV.SelectedItems.Count > 0)
            {
                int index = int.Parse(LV.SelectedItems[0].Text.ToString());
                Commission c = new Commission(index);
                frmCommissionManager fcm = new frmCommissionManager(c);
                fcm.ShowDialog();
                Reset();
            }
        }

        private void Reset()
        {
            List<Commission> commissions = CommissionManager.GetALLCommissions();
            DisplayResults(commissions);
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (LV.SelectedItems.Count > 0)
            {

                if (Server.IsRunning)
                {
                    MessageBox.Show("يجب إيقاف السيرفر أولاً.", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                    return;
                }

                int index = int.Parse(LV.SelectedItems[0].Text.ToString());
                Commission c = new Commission(index);


                DialogResult res = MessageBox.Show("هل تريد الحذف فعلاً؟", "تاكيد الحذف", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);

                if (res == System.Windows.Forms.DialogResult.Yes)
                {
                    if (!(CommissionManager.DeleteCommission(c)))
                    {
                        MessageBox.Show("تعذر عملية الحذف.", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                        return;
                    }

                    Reset();
                }

            }

        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            if (LV.SelectedItems.Count > 0)
            {
                int index = int.Parse(LV.SelectedItems[0].Text.ToString());
                Commission c = new Commission(index);
                frmCommissionManager fcm = new frmCommissionManager(c);
                fcm.ShowDialog();
                Reset();
            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            Reset();
        }
    }
}
