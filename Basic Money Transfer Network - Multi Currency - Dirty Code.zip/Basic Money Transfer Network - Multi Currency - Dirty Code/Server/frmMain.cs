﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YMT
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {

            if (keyData == (Keys.Shift | Keys.Escape))
            {

                this.Close();
                return true;

            }

            return base.ProcessCmdKey(ref msg, keyData);
        }


        protected override void WndProc(ref Message m)
        {

            base.WndProc(ref m);

            if (IsKeyLocked(Keys.CapsLock))
            {
                toolStripStatusLabel3.Text = "CAPS";
            }
            else
            {
                toolStripStatusLabel3.Text = "";
            }

            if (IsKeyLocked(Keys.NumLock))
            {
                toolStripStatusLabel4.Text = "NUM";
            }
            else
            {
                toolStripStatusLabel4.Text = "";
            }

        }


        private void toolStripButton1_Click(object sender, EventArgs e)
        {
           // frmIncomingStockOrder fi = new frmIncomingStockOrder();
            //fi.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            //frmReports fr = new frmReports();
            //fr.Show();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            //frmWarehouses fwh = new frmWarehouses();
            //fwh.ShowDialog();
               
        }

        private void toolStripButton2_Click_1(object sender, EventArgs e)
        {
        }

        private void المخازنToolStripMenuItem_Click(object sender, EventArgs e)
        {
           // frmWarehouses fwh = new frmWarehouses();
           // fwh.ShowDialog();
        }

        private void المجموعاتToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //frmGroups fg = new frmGroups();
            //fg.ShowDialog();
        }

        private void الأصنافToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //frmItemsSearcher fis = new frmItemsSearcher();
            //fis.Show();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            frmAboutBox fa = new frmAboutBox();
            fa.ShowDialog();
        }

        private void toolStripButton1_Click_1(object sender, EventArgs e)
        {
            //frmIncomingStockOrder f = new frmIncomingStockOrder();
            //f.MdiParent = this;
            //f.Show();
            //frmIncomingStockOrder fis = new frmIncomingStockOrder();
            //fis.Show();
        }

        private void toolStripButton9_Click(object sender, EventArgs e)
        {
            //frmReports fr = new frmReports();
            //fr.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel2.Text = DateTime.Now.ToString();
            toolStripStatusLabel1.Text = Utilities.user.UserName;
        }

        private void المستخدمينToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmUsers fusers = new frmUsers();
            fusers.ShowDialog();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            //frmOutgoingStockOrder fos = new frmOutgoingStockOrder();
            //fos.MdiParent = this;
            //fos.Show();
        }

        private void عملنسخةأحتياطيةلقاعدةالبياناتToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void إستعادةالنسخةالأحتياطيةلقاعدةالبياناتToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void toolStripButton2_Click_2(object sender, EventArgs e)
        {
            
           
        }

        private void العملاتToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCurrency fc = new frmCurrency();
            fc.Show();
        }

        private void الصناديقToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void toolStripButton3_Click_1(object sender, EventArgs e)
        {
            

        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            ///MessageBox.Show(e.);
        }

        private void TV_DoubleClick(object sender, EventArgs e)
        {
            TreeView tv = sender as TreeView;
            if(tv == null)
            {
                return;
            }

            switch(tv.SelectedNode.Name)
            {

                case "Currencies":
                    {
                        frmCurrency c = new frmCurrency();
                        c.Show();
                        break;
                    }

                case "Node100":
                    {

                        frmLogReport fl = new frmLogReport();
                        //frmLog fl = new frmLog();
                        fl.Show();
                        break;
                    }

                case "Node20":
                    {
                        frmStations fs = new frmStations();
                        fs.ShowDialog();
                        break;
                    }

                case "Node145":
                    {
                    //    frmIncomingTransction fi = new frmIncomingTransction();
                     //   fi.Show();
                      break;
                    }

                case "Node233":
                    {
                        frmCommission fc = new frmCommission();
                        fc.ShowDialog();
                        break;
                    }

                case "Node0":
                    {
                        //frmOutGoingTransction fogt = new frmOutGoingTransction();
                        //fogt.Show();
                        //fs.ShowDialog();
                        break;
                    }


                case "Node3":
                    {
                        frmNetworkInformation fni = new frmNetworkInformation(new NetworkInformation(1));
                        fni.ShowDialog();
                        break;
                    }
                case "UnitInfo":
                    {
                        frmBranchInfo fbi = new frmBranchInfo();
                        fbi.ShowDialog();
                        break;
                    }


                case "Node2":
                    {


                        frmTransctionsSignsChecker ftsc = new frmTransctionsSignsChecker();
                        ftsc.Show();

                        break;
                    }


                case "Users":
                    {
                        
                        frmUsers fu = new frmUsers();
                        fu.ShowDialog();

                        break;
                    }


                case "Node1":
                    {

                        frmBranchies fbi = new frmBranchies();
                        fbi.ShowDialog();

                        break;
                    }


                case "Node7":
                    {

                       // frmOutGoingTransction fogt = new frmOutGoingTransction();
                       // fogt.MdiParent = this;
                       // fogt.Show();

                        break;
                    }

                case "Node16":
                    {
                       // MessageBox.Show("عذراً ,,, هذه الخاصية غير متاحة حالياً. ..", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
///
                        //return;

                        frmReports freport = new frmReports();
                        freport.Show();

                        break;
                    }

                case "Node11":
                    {
                        MessageBox.Show("عذراً ,,, هذه الخاصية غير متاحة حالياً. ..", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);

                        return;

                        break;
                    }

                case "Node22":
                    {
                        MessageBox.Show("عذراً ,,, هذه الخاصية غير متاحة حالياً. ..", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);

                        return;

                        break;
                    }

                case "Node44":
                    {
                        MessageBox.Show("عذراً ,,, هذه الخاصية غير متاحة حالياً. ..", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);

                        return;

                        break;
                    }

                case "Node8":
                    {
                       // frmIncomingTransction fit = new frmIncomingTransction();
                       // fit.ShowDialog();
                        

                        break;
                    }


                //Node7


                case "BackupDB":
                    {
                        MessageBox.Show("عذراً ,,, هذه الخاصية غير متاحة حالياً. ..", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);

                        return;
                        if (!(Utilities.user.CanManageDB))
                        {

                            MessageBox.Show("عفواً ,,, ليس لديك الإمتيازات الكافية لإتمام هذه العملية.. ", " ", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                            return;
                        }


                        SaveFileDialog SaveFileDialog1 = new SaveFileDialog();
                        try
                        {
                            SaveFileDialog1 = new SaveFileDialog();
                            SaveFileDialog1.CreatePrompt = true;
                            SaveFileDialog1.OverwritePrompt = true;

                            // Set the file name to myText.txt, set the type filter 
                            // to text files, and set the initial directory to the  
                            // MyDocuments folder.
                            SaveFileDialog1.FileName = "db.bak";
                            // DefaultExt is only used when "All files" is selected from  
                            // the filter box and no extension is specified by the user.
                            SaveFileDialog1.DefaultExt = "accdb";
                            SaveFileDialog1.Filter =
                                "Access Database Backup files (*.bak)|*.bak";
                            SaveFileDialog1.InitialDirectory =
                                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

                            // Call ShowDialog and check for a return value of DialogResult.OK, 
                            // which indicates that the file was saved. 
                            DialogResult result = SaveFileDialog1.ShowDialog();


                            if (result == DialogResult.OK)
                            {
                                if (Utilities.MakeBackup(SaveFileDialog1.FileNames[0]))
                                {
                                    SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تم عمل نسخة إحتياطية لقاعدة البيانات بنجاح.", MSGTYPE.Info), DateTime.Now, SaveFileDialog1.FileNames[0]));
                                    MessageBox.Show("تم عمل النسخة الاحتياطية بنجاح..", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                                }
                                else
                                {
                                    SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "فشل النظام في عمل النسخة الإحتياطية.", MSGTYPE.Error), DateTime.Now, SaveFileDialog1.FileNames[0]));
                                    MessageBox.Show("تعذر عمل النسخة الاحتياطية.", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                                }
                            }
                        }
                        catch
                        {
                            SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "فشل النظام في عمل النسخة الإحتياطية.", MSGTYPE.Error), DateTime.Now, SaveFileDialog1.FileNames[0]));
                            MessageBox.Show("تعذر عمل النسخة الاحتياطية.", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                        }

                        break;
                    }

                case "RestoreDB":
                    {
                        MessageBox.Show("عذراً ,,, هذه الخاصية غير متاحة حالياً. ..", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                        return;



                        MessageBox.Show("تواصل مع  وأصدقائه لتفعيل هذه الخاصية.", " ", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                        return;

                        if (!(Utilities.user.CanManageDB))
                        {

                            MessageBox.Show("عفواً ,,, ليس لديك الإمتيازات الكافية لإتمام هذه العملية.. ", " ", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                            return;
                        }


                        OpenFileDialog ofd = null;
                        try
                        {
                            ofd = new OpenFileDialog();

                            ofd.InitialDirectory = "c:\\";
                            ofd.Filter = "Access Database Backup files (*.bak)|*.bak";
                            ofd.FilterIndex = 2;
                            ofd.RestoreDirectory = true;

                            if (ofd.ShowDialog() == DialogResult.OK)
                            {
                                if (ofd.FileNames.Count() > 0)
                                {
                                    DialogResult res = MessageBox.Show("تحذير \r\r سيتم حذف جميع البيانات السابقة , هل تريد الإستمرار؟", " ", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                                    if (res == DialogResult.Yes)
                                    {

                                        if (!(Utilities.MakeBackup(Application.StartupPath + "\\BBRDB" + DateTime.Now.ToString("yyyyMMdd-HHmmss"))))
                                        {
                                            MessageBox.Show("تعذر إستعادة قاعدة البيانات. ", " ", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                                            return;
                                        }

                                        if (Utilities.RestoreDatabase(ofd.FileNames[0]))
                                        {
                                            SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تم إستعادة قاعدة البيانات بنجاح.", MSGTYPE.Info), DateTime.Now, ofd.FileNames[0]));
                                            MessageBox.Show("تم إستعادة قاعدة البيانات بنجاح.", " ", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                                        }
                                        else
                                        {
                                            SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تعذر إستعادة قاعدة البيانات .", MSGTYPE.Error), DateTime.Now, ofd.FileNames[0]));
                                            MessageBox.Show("تعذر إستعادة قاعدة البيانات. ", " ", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                                            return;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تعذر إستعادة قاعدة البيانات .", MSGTYPE.Error), DateTime.Now, ofd.FileNames[0]));
                                MessageBox.Show("تعذر إستعادة قاعدة البيانات. ", " ", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                                return;
                            }

                        }
                        catch
                        {
                            SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تعذر إستعادة قاعدة البيانات .", MSGTYPE.Error), DateTime.Now, ofd.FileNames[0]));
                            MessageBox.Show("تعذر إستعادة قاعدة البيانات. ", " ", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                            return;
                        }

                        break;
                    }

                  

            }

        }

        private void TV_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                TV_DoubleClick(sender, new EventArgs());
            }
        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        {
            frmLogin fl = new frmLogin(true);
            fl.ShowDialog();
           
        }

        private void إغلاقToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {

            DialogResult res = MessageBox.Show("هل تُريد إغلاق النظام فعلاً؟" , " ", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RtlReading);
            if (res == DialogResult.Yes)
            {
                if (Server.IsRunning)
                {

                    MessageBox.Show(" يجب إيقاف السيرفر أولاً", " ", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                    e.Cancel = true;
                    return;
                    if (Server.Stop() == false)
                    {
                        SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تعذر إيقاف السيرفر ", MSGTYPE.Error), DateTime.Now));
                        MessageBox.Show("تعذر إيقاف السيرفر بصورة صحيحة   .. ", " ", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                        //return;
                    }
                    else
                    {
                        السيرفرToolStripMenuItem.Checked = false;
                        SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تم إيقاف السيرفر بنجاح.", MSGTYPE.Info), DateTime.Now));
                    }
                }
                //if (!(Utilities.MakeBackup(Application.StartupPath + "\\Backup\\BBRDB" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + ".bak")))
                //{
                //    MessageBox.Show("تعذر على النظام عمل نسخة إحتياطية لقاعدة البيانات.", " ", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                //    return;
                //}

            }
            else
            {
                e.Cancel = true;
            }


         
        }

        private void frmMain_Shown(object sender, EventArgs e)
        {
            Utilities.fl = new frmLog();
            Utilities.fl.MdiParent = this;
            Utilities.fl.Show();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void السجلToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Utilities.fl == null)
            {
                Utilities.fl = new frmLog();
                Utilities.fl.MdiParent = this;
                Utilities.fl.Show();
            }
            else
            {
                Utilities.fl.Show();
            }
        }

        private void عرضToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void السيرفرToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (السيرفرToolStripMenuItem.Checked)
            {
                if (Server.Stop() == false)
                {
                    SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تعذر إيقاف السيرفر ", MSGTYPE.Error), DateTime.Now));
                    MessageBox.Show("تعذر إيقاف السيرفر بصورة صحيحة   .. ", " ", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                    return;
                }

                السيرفرToolStripMenuItem.Checked = false;
                SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تم إيقاف السيرفر بنجاح.", MSGTYPE.Info), DateTime.Now));
            }
            else
            {
                if (Server.StartListeing() == false)
                {
                    SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تعذر إيقاف السيرفر ", MSGTYPE.Error), DateTime.Now));
                    MessageBox.Show("تعذر على النظام التنصت  .. ", " ", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                    return;
                }

                السيرفرToolStripMenuItem.Checked = true;
                SystemLogManager.CreateNewSystemEvent(new SystemLog(new MSGINFO(0, "تم التنصت بنجاح.", MSGTYPE.Info), DateTime.Now));
            }
        }
    }
}
