﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YMT
{
    public partial class frmCurrency : Form
    {
        private bool op = false;
        public frmCurrency()
        {
            InitializeComponent();
            Reset();

        }


        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {

            if (keyData == (Keys.Control | Keys.F))
            {
                bindingNavigator3.Focus();
                return true;
            }
            
            if (keyData == (Keys.Control | Keys.N))
            {
                button9.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.E))
            {
                button8.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.S))
            {
                button7.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.Delete))
            {
                button1.PerformClick();
                return true;
            }

            if (keyData == (Keys.Shift | Keys.Escape))
            {
                if (button7.Enabled)
                {
                    button6.PerformClick();
                }
                else
                {
                    this.Close();
                }
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }



        private void button9_Click(object sender, EventArgs e)
        {
            AddNew();
        }

        private void frmCurrency_Load(object sender, EventArgs e)
        {

        }

        private void AddNew()
        {
            DisableALL();
            button6.Enabled = true;
            button7.Enabled = true;
            textBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Enabled = true;
            bindingNavigator3.Enabled = false;
            numericUpDown1.Enabled = true;
            //textBox4.Enabled = true;
            op = true;
            textBox1.Focus();
            bindingSource1.AddNew();
        }

        private void Save()
        {
            if (Server.IsRunning)
            {
                MessageBox.Show("يجب إيقاف السيرفر أولاً.", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                return;
            }

            if (!(numericUpDown1.Value > 0))
            {
                numericUpDown1.Focus();
                return;
            }

            if (string.IsNullOrEmpty(textBox1.Text))
            {
                textBox1.Focus();
                return;
            }

            if (string.IsNullOrEmpty(textBox2.Text))
            {
                textBox2.Focus();
                return;
            }

            if (string.IsNullOrEmpty(textBox3.Text))
            {
                textBox3.Focus();
                return;
            }

            //if (string.IsNullOrEmpty(textBox4.Text))
            //{
            //    textBox4.Focus();
            //    return;
            //}

            //long led_id = 0;
            //if (!(long.TryParse(textBox4.Text, out led_id)))
            //{
            //    //MessageBox.Show("ادخل رقم الحساب.", "", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning, System.Windows.Forms.MessageBoxDefaultButton.Button1, System.Windows.Forms.MessageBoxOptions.RtlReading);
            //   // textBox4.Focus();
            //    return;
            //}


            //Ledger ledger = new Ledger(long.Parse(textBox4.Text));

            //if ((ledger.ExceptionInfo != null))
            //{
            //    //MessageBox.Show("ادخل رقم الحساب.", "", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning, System.Windows.Forms.MessageBoxDefaultButton.Button1, System.Windows.Forms.MessageBoxOptions.RtlReading);
            //    //textBox4.Focus();

            //    return;
            //}

            CurrencyInfo c = bindingSource1.Current as CurrencyInfo;
            c.CurrencyExchange = numericUpDown1.Value;
            //Warehouse wh = bindingSource1.Current as Warehouse;

            if (op)
            {
                if (CurrencyManager.CreateNewCurrency(c))
                {
                    Reset();
                    MessageBox.Show("تمت العملية بنجاح  .", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                }
                else
                {
                    MessageBox.Show("تعذر على النظام تنفيذ العملية  .", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                }
            }
            else
            {
                if (CurrencyManager.UpdateCurrency(c))
                {
                    Reset();
                    MessageBox.Show("تمت العملية بنجاح  .", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                }
                else
                {
                    MessageBox.Show("تعذر على النظام تنفيذ العملية  .", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                }
            }
        }


        private void DisableALL()
        {

            numericUpDown1.Enabled = false;
            button1.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = false;
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            checkBox1.Enabled = false;

            //textBox4.Enabled = false;

        }

        private void Delete()
        {
            if (bindingSource1.Current != null)
            {
                DialogResult res = MessageBox.Show("هل تريد حذف السجل فعلاً؟", "تاكيد الحذف", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);

                if (res == System.Windows.Forms.DialogResult.Yes)
                {
                    CurrencyInfo c = bindingSource1.Current as CurrencyInfo;

                    if (!(CurrencyManager.DeleteCurrency(c)))
                    {
                        MessageBox.Show("تعذر عملية الحذف.", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                        return;
                    }

                    Reset();
                }
            }

        }

        private void Update()
        {

            DisableALL();
            button6.Enabled = true;
            button7.Enabled = true;
            textBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Enabled = true;
            op = false;

            CurrencyInfo c = bindingSource1.Current as CurrencyInfo;
            if(c.CurrencyNumber==1)
            {
                
                numericUpDown1.Enabled = false;
            }
            else
            {
                textBox1.Enabled = false;
                textBox2.Enabled = false;
                textBox3.Enabled = false;
                numericUpDown1.Enabled = true;
            }

            textBox1.Focus();


        }

        private void Reset()
        {
            DisableALL();
            List<CurrencyInfo> currencies = CurrencyManager.GetALLCurrency();
            
            bindingSource1.Clear();
            bindingSource1.DataSource = currencies;
            bindingNavigator3.BindingSource = bindingSource1;
            bindingNavigator3.Enabled = true;
            button9.Enabled = true;
            button8.Enabled = true;
            button1.Enabled = true;

        }

        private void bindingSource1_BindingComplete(object sender, BindingCompleteEventArgs e)
        {
            checkBox1.Checked = false;
            if (bindingSource1.Current != null)
            {
                CurrencyInfo c = bindingSource1.Current as CurrencyInfo;
                if (c.CurrencyNumber == 1)
                {
                    checkBox1.Checked = true;
                }
            }
        }

        private void bindingSource1_CurrentChanged(object sender, EventArgs e)
        {
            checkBox1.Checked = false;
            if (bindingSource1.Current != null)
            {
                CurrencyInfo c = bindingSource1.Current as CurrencyInfo;
                if (c.CurrencyNumber == 1)
                {
                    checkBox1.Checked = true;
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Update();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Save();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Reset();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Delete();
        }

        private void numericUpDown1_Enter(object sender, EventArgs e)
        {
            numericUpDown1.Select(0, 999999);
        }

        private void numericUpDown1_Click(object sender, EventArgs e)
        {
            numericUpDown1.Select(0, 999999);
        }
    }
}
