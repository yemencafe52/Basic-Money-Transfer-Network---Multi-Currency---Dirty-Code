﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YMT
{
    public partial class frmLogReport : Form
    {
        public frmLogReport()
        {
            InitializeComponent();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == (Keys.Shift | Keys.Escape))
            {
                {
                    this.Close();
                }
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmReportViewer frmRV = new frmReportViewer();

            DataTable dt = new DataTable();

            try
            {

                LogReport lr = new LogReport();
                dt = lr.GetLog(dateTimePicker6.Value, dateTimePicker5.Value);

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("لا توجد نتائج لعرضها.", "", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information, System.Windows.Forms.MessageBoxDefaultButton.Button1, System.Windows.Forms.MessageBoxOptions.RtlReading);
                    return;
                }

                Microsoft.Reporting.WinForms.ReportDataSource rpt = new Microsoft.Reporting.WinForms.ReportDataSource("tblLog", dt);

                frmRV.reportViewer1.LocalReport.DataSources.Clear();

                frmRV.reportViewer1.LocalReport.ReportEmbeddedResource = "YMT.rptLog.rdlc";

                frmRV.reportViewer1.LocalReport.DataSources.Add(rpt);
                frmRV.reportViewer1.RefreshReport();
                frmRV.Show();

            }
            catch
            {
                MessageBox.Show("تعذر عرض التقرير..", "", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error, System.Windows.Forms.MessageBoxDefaultButton.Button1, System.Windows.Forms.MessageBoxOptions.RtlReading);
            }

        }

        private void frmLogReport_Load(object sender, EventArgs e)
        {

            dateTimePicker5.Format = DateTimePickerFormat.Custom;
            dateTimePicker5.CustomFormat = "yyyy/MM/dd";

            dateTimePicker6.Format = DateTimePickerFormat.Custom;
            dateTimePicker6.CustomFormat = "yyyy/MM/dd";

            dateTimePicker6.Value = new DateTime(DateTime.Now.Year, 1, 1);
            dateTimePicker5.Value = DateTime.Parse(DateTime.Now.ToString("yyyy/MM/dd"));


            dateTimePicker6.Enabled = false;
            dateTimePicker5.Enabled = false;

            dateTimePicker6.Value = new DateTime(DateTime.Now.Year, 1, 1);
            dateTimePicker5.Value = new DateTime(DateTime.Now.Year, 12, 31);//DateTime.Parse(DateTime.Now.ToString("yyyy/MM/dd"));

           

            
        }
    }
}
