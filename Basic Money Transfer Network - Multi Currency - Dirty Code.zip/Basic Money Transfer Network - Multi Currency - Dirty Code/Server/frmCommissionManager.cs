﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YMT
{
    public partial class frmCommissionManager : Form
    {
        bool op = false;
        private Commission commission = null;

        public frmCommissionManager()
        {
            InitializeComponent();
            Preparing();
        }

        public frmCommissionManager(Commission com)
        {
            InitializeComponent();
            Preparing();
            this.commission = com;
            DisplayInfo(this.commission);   
        }

        private void DisplayInfo(Commission com)
        {
            DisableALL();
            button6.Enabled = true;
            button8.Enabled = true;
            button9.Enabled = true;
            
            comboBox1.SelectedValue = com.FromBranch.BranchNumber;
            comboBox2.SelectedValue = com.ToBranch.BranchNumber;
            comboBox3.SelectedValue = com.Currency.CurrencyNumber;

            numericUpDown5.Value = com.CommissionID;
            numericUpDown1.Value = com.FromAmount;
            numericUpDown2.Value = com.ToAmount;

            comboBox4.SelectedIndex = (byte)com.CommissionTypeInfo;
            numericUpDown3.Value = com.CommissionValue;

            comboBox5.SelectedIndex = (byte)com.CommissionTypeInfo2;
            numericUpDown4.Value = com.CommissionValue2;

        }


        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {

            if (keyData == (Keys.Control | Keys.F))
            {
                //button5.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.P))
            {
               // button2.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.N))
            {
                button9.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.E))
            {
                button8.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.S))
            {
                button7.PerformClick();
                return true;
            }

            if (keyData == (Keys.Shift | Keys.Escape))
            {
                if (button7.Enabled)
                {
                    button6.PerformClick();
                }
                else
                {
                    this.Close();
                }
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void frmCommissionManager_Load(object sender, EventArgs e)
        {
           

        }

        private bool Preparing()
        {
            bool res = false;
            try
            {
                List<BranchInfo> branchies = BranchInfoManager.GetALLBranchInfo();

                comboBox1.DisplayMember = "BranchNumber";
                comboBox1.ValueMember = "BranchNumber";
                comboBox1.DataSource = branchies;

                if (comboBox1.Items.Count > 0)
                {
                    comboBox1.SelectedIndex = 0;
                }

                List<BranchInfo> branchies2 = BranchInfoManager.GetALLBranchInfo();

                comboBox2.DisplayMember = "BranchNumber";
                comboBox2.ValueMember = "BranchNumber";
                comboBox2.DataSource = branchies2;

                if (comboBox2.Items.Count > 0)
                {
                    comboBox2.SelectedIndex = 0;
                }

                List<CurrencyInfo> currenies = CurrencyManager.GetALLCurrency();
                
                comboBox3.DisplayMember = "CurrencyName";
                comboBox3.ValueMember = "CurrencyNumber";
                comboBox3.DataSource = currenies;

                comboBox4.Items.Add("نسبة");
                comboBox4.Items.Add("مبلغ");

                if (comboBox4.Items.Count > 0)
                {
                    comboBox4.SelectedIndex = 0;
                }

                comboBox5.Items.Add("نسبة");
                comboBox5.Items.Add("مبلغ");

                if (comboBox5.Items.Count > 0)
                {
                    comboBox5.SelectedIndex = 0;
                }

                res = true;
                DisableALL();
                button9.Enabled = true;
                button6.Enabled = true;
            }
            catch
            {
                res = false;
            }

            return res;
        }


        private void AddNew()
        {
            DisableALL();
            button6.Enabled = true;
            button7.Enabled = true;

            comboBox1.Enabled = true;
            comboBox2.Enabled = true;
            comboBox3.Enabled = true;
            comboBox4.Enabled = true;
            comboBox5.Enabled = true;
            numericUpDown1.Enabled = true;
            numericUpDown2.Enabled = true;
            numericUpDown3.Enabled = true;
            numericUpDown4.Enabled = true;
            comboBox1.Enabled = true;
            
         
            op = true;
            
        }

        private void Save()
        {

            try
            {
                if (Server.IsRunning)
                {
                    MessageBox.Show("يجب إيقاف السيرفر أولاً.", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                    return;
                }

                if (op)
                {

                    Commission c = new Commission(new BranchInfo(Convert.ToByte(comboBox1.SelectedValue.ToString())),new BranchInfo(Convert.ToByte(comboBox2.SelectedValue.ToString())) ,new CurrencyInfo(Convert.ToByte(comboBox3.SelectedValue.ToString())),numericUpDown1.Value,numericUpDown2.Value,((CommissionType)comboBox4.SelectedIndex),numericUpDown3.Value,((CommissionType)comboBox5.SelectedIndex),numericUpDown4.Value);

                    if (CommissionManager.CreateNewCommission(c))
                    {
                        DisableALL();
                        button9.Enabled = true;
                        button6.Enabled = true;

                        //Reset();
                        MessageBox.Show("تمت العملية بنجاح  .", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                    }
                    else
                    {
                        MessageBox.Show("تعذر على النظام تنفيذ العملية  .", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                    }
                }
                else
                {
                    Commission c = new Commission((int)numericUpDown5.Value);

                    if (c.ExceptionInfo != null)
                    {
                        MessageBox.Show("تعذر على النظام تنفيذ العملية  .", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                        return;
                    }

                    c.FromAmount =  numericUpDown1.Value;
                    c.ToAmount = numericUpDown2.Value;
                    c.CommissionTypeInfo = ((CommissionType)comboBox4.SelectedIndex);
                    c.CommissionValue  = numericUpDown3.Value;
                    c.CommissionTypeInfo2 = ((CommissionType)comboBox5.SelectedIndex);
                    c.CommissionValue2 = numericUpDown4.Value;
                   
                    if (CommissionManager.UpdateCommission(c))
                    {
                        Reset();
                        MessageBox.Show("تمت العملية بنجاح  .", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                    }
                    else
                    {
                        MessageBox.Show("تعذر على النظام تنفيذ العملية  .", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                    }
                }

            }
            catch
            {
                MessageBox.Show("أوبس ,,, هناك شيء حدث بشكل خاطئ:(.", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
            }

        }


        private void DisableALL()
        {

            numericUpDown1.Enabled = false;
            button1.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = false;
            comboBox1.Enabled = false;
            comboBox2.Enabled = false;
            comboBox3.Enabled = false;
            comboBox4.Enabled = false;
            comboBox5.Enabled = false;
            numericUpDown1.Enabled = false;
            numericUpDown2.Enabled = false;
            numericUpDown3.Enabled = false;
            numericUpDown4.Enabled = false;
            numericUpDown5.Enabled = false;

        }

        private void Delete()
        {
            
        }

        private void Update()
        {
            DisableALL();
            button6.Enabled = true;
            button7.Enabled = true;

            
            comboBox4.Enabled = true;
            comboBox5.Enabled = true;
            numericUpDown1.Enabled = true;
            numericUpDown2.Enabled = true;
            numericUpDown3.Enabled = true;
            numericUpDown4.Enabled = true;
            op = false; ;
        }

        private void Reset()
        {
            this.Close();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            AddNew();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Update();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Save();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Reset();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Delete();
        }

    }
}
