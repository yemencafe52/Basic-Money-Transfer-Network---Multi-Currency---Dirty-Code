﻿namespace YMT
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("إرسال");
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("إستلام");
            System.Windows.Forms.TreeNode treeNode17 = new System.Windows.Forms.TreeNode("العمليات", new System.Windows.Forms.TreeNode[] {
            treeNode15,
            treeNode16});
            System.Windows.Forms.TreeNode treeNode18 = new System.Windows.Forms.TreeNode("الحوالات");
            System.Windows.Forms.TreeNode treeNode19 = new System.Windows.Forms.TreeNode("التقارير", new System.Windows.Forms.TreeNode[] {
            treeNode18});
            System.Windows.Forms.TreeNode treeNode20 = new System.Windows.Forms.TreeNode("الحوالات", new System.Windows.Forms.TreeNode[] {
            treeNode17,
            treeNode19});
            System.Windows.Forms.TreeNode treeNode21 = new System.Windows.Forms.TreeNode("تغيير كلمة المرور");
            System.Windows.Forms.TreeNode treeNode22 = new System.Windows.Forms.TreeNode("الأمان", new System.Windows.Forms.TreeNode[] {
            treeNode21});
            System.Windows.Forms.TreeNode treeNode23 = new System.Windows.Forms.TreeNode("Ctrl + N = إضافة");
            System.Windows.Forms.TreeNode treeNode24 = new System.Windows.Forms.TreeNode("Ctrl + S = حفظ");
            System.Windows.Forms.TreeNode treeNode25 = new System.Windows.Forms.TreeNode("Ctrl + F = بحث");
            System.Windows.Forms.TreeNode treeNode26 = new System.Windows.Forms.TreeNode("Shift + Esc = إلغاء , إغلاق");
            System.Windows.Forms.TreeNode treeNode27 = new System.Windows.Forms.TreeNode("تعليمات", new System.Windows.Forms.TreeNode[] {
            treeNode23,
            treeNode24,
            treeNode25,
            treeNode26});
            System.Windows.Forms.TreeNode treeNode28 = new System.Windows.Forms.TreeNode("enjoy :)");
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.الصيانةToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.عملنسخةأحتياطيةلقاعدةالبياناتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.إستعادةالنسخةالأحتياطيةلقاعدةالبياناتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.إغلاقToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.المخازنToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.المجموعاتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.الأصنافToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.المستخدمينToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.الصناديقToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.العملاتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel12 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel5 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel4 = new System.Windows.Forms.ToolStripStatusLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.TV = new System.Windows.Forms.TreeView();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.viewToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(636, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.الصيانةToolStripMenuItem,
            this.toolStripMenuItem1,
            this.إغلاقToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(42, 20);
            this.fileToolStripMenuItem.Text = "ملف";
            // 
            // الصيانةToolStripMenuItem
            // 
            this.الصيانةToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.عملنسخةأحتياطيةلقاعدةالبياناتToolStripMenuItem,
            this.إستعادةالنسخةالأحتياطيةلقاعدةالبياناتToolStripMenuItem});
            this.الصيانةToolStripMenuItem.Name = "الصيانةToolStripMenuItem";
            this.الصيانةToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.الصيانةToolStripMenuItem.Text = "الصيانة";
            this.الصيانةToolStripMenuItem.Visible = false;
            // 
            // عملنسخةأحتياطيةلقاعدةالبياناتToolStripMenuItem
            // 
            this.عملنسخةأحتياطيةلقاعدةالبياناتToolStripMenuItem.Name = "عملنسخةأحتياطيةلقاعدةالبياناتToolStripMenuItem";
            this.عملنسخةأحتياطيةلقاعدةالبياناتToolStripMenuItem.Size = new System.Drawing.Size(272, 22);
            this.عملنسخةأحتياطيةلقاعدةالبياناتToolStripMenuItem.Text = "عمل نسخة أحتياطية لقاعدة البيانات";
            // 
            // إستعادةالنسخةالأحتياطيةلقاعدةالبياناتToolStripMenuItem
            // 
            this.إستعادةالنسخةالأحتياطيةلقاعدةالبياناتToolStripMenuItem.Name = "إستعادةالنسخةالأحتياطيةلقاعدةالبياناتToolStripMenuItem";
            this.إستعادةالنسخةالأحتياطيةلقاعدةالبياناتToolStripMenuItem.Size = new System.Drawing.Size(272, 22);
            this.إستعادةالنسخةالأحتياطيةلقاعدةالبياناتToolStripMenuItem.Text = "إستعادة النسخة الأحتياطية لقاعدةالبيانات";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(107, 6);
            this.toolStripMenuItem1.Visible = false;
            // 
            // إغلاقToolStripMenuItem
            // 
            this.إغلاقToolStripMenuItem.Name = "إغلاقToolStripMenuItem";
            this.إغلاقToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.إغلاقToolStripMenuItem.Text = "إغلاق";
            this.إغلاقToolStripMenuItem.Click += new System.EventHandler(this.إغلاقToolStripMenuItem_Click);
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.المخازنToolStripMenuItem,
            this.المجموعاتToolStripMenuItem,
            this.الأصنافToolStripMenuItem,
            this.toolStripMenuItem2,
            this.المستخدمينToolStripMenuItem,
            this.toolStripMenuItem3,
            this.الصناديقToolStripMenuItem,
            this.العملاتToolStripMenuItem});
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.viewToolStripMenuItem.Text = "إعداد";
            this.viewToolStripMenuItem.Visible = false;
            // 
            // المخازنToolStripMenuItem
            // 
            this.المخازنToolStripMenuItem.Name = "المخازنToolStripMenuItem";
            this.المخازنToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.المخازنToolStripMenuItem.Text = "المخازن";
            // 
            // المجموعاتToolStripMenuItem
            // 
            this.المجموعاتToolStripMenuItem.Name = "المجموعاتToolStripMenuItem";
            this.المجموعاتToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.المجموعاتToolStripMenuItem.Text = "المجموعات";
            // 
            // الأصنافToolStripMenuItem
            // 
            this.الأصنافToolStripMenuItem.Name = "الأصنافToolStripMenuItem";
            this.الأصنافToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.الأصنافToolStripMenuItem.Text = "الأصناف";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(126, 6);
            // 
            // المستخدمينToolStripMenuItem
            // 
            this.المستخدمينToolStripMenuItem.Name = "المستخدمينToolStripMenuItem";
            this.المستخدمينToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(126, 6);
            // 
            // الصناديقToolStripMenuItem
            // 
            this.الصناديقToolStripMenuItem.Name = "الصناديقToolStripMenuItem";
            this.الصناديقToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.الصناديقToolStripMenuItem.Text = "الصناديق";
            // 
            // العملاتToolStripMenuItem
            // 
            this.العملاتToolStripMenuItem.Name = "العملاتToolStripMenuItem";
            this.العملاتToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.العملاتToolStripMenuItem.Text = "العملات";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.aboutToolStripMenuItem.Text = "حول";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel12,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel5,
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel3,
            this.toolStripStatusLabel4});
            this.statusStrip1.Location = new System.Drawing.Point(0, 214);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(636, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel12
            // 
            this.toolStripStatusLabel12.Name = "toolStripStatusLabel12";
            this.toolStripStatusLabel12.Size = new System.Drawing.Size(43, 17);
            this.toolStripStatusLabel12.Text = "Admin";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(65, 17);
            this.toolStripStatusLabel2.Text = "21/21/2021";
            // 
            // toolStripStatusLabel5
            // 
            this.toolStripStatusLabel5.Name = "toolStripStatusLabel5";
            this.toolStripStatusLabel5.Size = new System.Drawing.Size(372, 17);
            this.toolStripStatusLabel5.Spring = true;
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.AutoSize = false;
            this.toolStripStatusLabel1.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(70, 17);
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.AutoSize = false;
            this.toolStripStatusLabel3.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(36, 17);
            // 
            // toolStripStatusLabel4
            // 
            this.toolStripStatusLabel4.AutoSize = false;
            this.toolStripStatusLabel4.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.toolStripStatusLabel4.Name = "toolStripStatusLabel4";
            this.toolStripStatusLabel4.Size = new System.Drawing.Size(35, 17);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // TV
            // 
            this.TV.Dock = System.Windows.Forms.DockStyle.Left;
            this.TV.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.TV.FullRowSelect = true;
            this.TV.Location = new System.Drawing.Point(0, 24);
            this.TV.Name = "TV";
            treeNode15.Name = "Node7";
            treeNode15.Text = "إرسال";
            treeNode16.Name = "Node8";
            treeNode16.Text = "إستلام";
            treeNode17.Name = "Node2";
            treeNode17.Text = "العمليات";
            treeNode18.Name = "Node2";
            treeNode18.Text = "الحوالات";
            treeNode19.Name = "Node1";
            treeNode19.Text = "التقارير";
            treeNode20.Name = "Node0";
            treeNode20.Text = "الحوالات";
            treeNode21.Name = "Node1212";
            treeNode21.Text = "تغيير كلمة المرور";
            treeNode22.Name = "Node0";
            treeNode22.Text = "الأمان";
            treeNode23.Name = "Node0";
            treeNode23.Text = "Ctrl + N = إضافة";
            treeNode24.Name = "Node2";
            treeNode24.Text = "Ctrl + S = حفظ";
            treeNode25.Name = "Node3";
            treeNode25.Text = "Ctrl + F = بحث";
            treeNode26.Name = "Node7";
            treeNode26.Text = "Shift + Esc = إلغاء , إغلاق";
            treeNode27.Name = "d";
            treeNode27.Text = "تعليمات";
            treeNode28.Name = "s";
            treeNode28.Text = "enjoy :)";
            this.TV.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode20,
            treeNode22,
            treeNode27,
            treeNode28});
            this.TV.RightToLeftLayout = true;
            this.TV.Size = new System.Drawing.Size(214, 190);
            this.TV.TabIndex = 9;
            this.TV.DoubleClick += new System.EventHandler(this.TV_DoubleClick);
            this.TV.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TV_KeyDown);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(636, 236);
            this.Controls.Add(this.TV);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.KeyPreview = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " تحويل أموال";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripMenuItem المخازنToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem المجموعاتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem الأصنافToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem الصيانةToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem عملنسخةأحتياطيةلقاعدةالبياناتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem إستعادةالنسخةالأحتياطيةلقاعدةالبياناتToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem إغلاقToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem المستخدمينToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem الصناديقToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem العملاتToolStripMenuItem;
        private System.Windows.Forms.TreeView TV;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel4;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel5;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel12;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
    }
}

