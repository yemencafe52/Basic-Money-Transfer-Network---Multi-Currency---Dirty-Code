﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace YMT
{
    public static class Users
    {
        public static bool Login(string username, string password, ref User user_info)
        {
            bool res = false;

            SocketCommender sc = new SocketCommender();

            List<ParamInfo> lp = new List<ParamInfo>();
            lp.Add(new ParamInfo(username));
            lp.Add(new ParamInfo(password));

            byte[] data =   new byte[0]; 

            if (sc.GetObject(new Command(CommandType.Logining, lp),ref  data))
            {
                user_info = new User(data);
                if ((user_info.UserName == username) && (Utilities.GetMD5Hash(password) == user_info.Password))
                {
                    res = true;
                }
                else
                {
                    res = false;
                }
                
            }
            else
            {
                res = false;
            }

            return res;
        }

    }
    public class User
    {
        private byte user_no;
        private string user_name;
        private string password = "";
        private bool can_add = false;
        private bool can_edit = false;
        private bool can_delete = false;
        private bool is_stopped = false;
        private bool can_manage_db = false;

        private Exception exception_info = null;

        public User()
        {
        }

        public User(byte number)
        {
            try
            {
                SocketCommender sc = new SocketCommender();
                byte[] ar = new byte[0];

                List<ParamInfo> lp = new List<ParamInfo>();
                
                lp.Add(new ParamInfo(( new byte[] { number })));

                if (sc.GetObject(new Command(CommandType.CurrencyInfo, lp), ref ar))
                {
                    Fill(ar);

                    if (this.exception_info != null)
                    {
                        throw this.exception_info;
                    }
                }
                else
                {
                    this.exception_info = new Exception("");
                }
            }

            catch (Exception ex)
            {
                this.exception_info = ex;
            }
        }
        public User(byte user_no, string user_name, string password, bool can_add, bool can_edit, bool can_delete, bool can_manage_db, bool is_stopped = false)
        {
            this.user_no = user_no;
            this.user_name = user_name;
            this.password = password;
            this.can_add = can_add;
            this.can_edit = can_edit;
            this.can_delete = can_delete;
            this.can_manage_db = can_manage_db;
            this.is_stopped = is_stopped;
        }

        public byte Number
        {
            get
            {
                return this.user_no;
            }

            set
            {
                this.user_no = value;
            }
        }

        public string UserName
        {
            get
            {
                return this.user_name;
            }

            set
            {
                this.user_name = value;
            }
        }

        public string Password
        {
            get
            {
                return this.password;
            }

            set
            {
                this.password = value;
            }
        }

        public bool CanAdd
        {
            get
            {
                return this.can_add;
            }

            set
            {
                this.can_add = value;
            }
        }

        public bool CanEdit
        {
            get
            {
                return this.can_edit;
            }

            set
            {
                this.can_edit = value;
            }
        }

        public bool CanDelete
        {
            get
            {
                return this.can_delete;
            }

            set
            {
                this.can_delete = value;
            }
        }

        public bool IsStopped
        {
            get
            {
                return this.is_stopped;
            }

            set
            {
                this.is_stopped = value;
            }
        }

        public bool CanManageDB
        {
            get
            {
                return this.can_manage_db;
            }

            set
            {
                this.can_manage_db = value;
            }
        }






        public User(byte[] ar)
        {
            try
            {
                int index = 0;
                byte[] art = new byte[1];
                int l = 1;

                Array.Copy(ar, index, art, 0, l);
                this.user_no = ar[0];
                index += 1;

                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.user_name = Encoding.UTF8.GetString(art);


                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.password = Encoding.UTF8.GetString(art);

                this.is_stopped = BitConverter.ToBoolean(ar, index);
                index += 1;
                this.can_add = BitConverter.ToBoolean(ar, index);
                index += 1;
                this.can_delete = BitConverter.ToBoolean(ar, index);
                index += 1;
                this.can_edit = BitConverter.ToBoolean(ar, index);
                index += 1;
                this.can_manage_db = BitConverter.ToBoolean(ar, index);
                index += 1;

                l = BitConverter.ToInt32(ar, index);
                index += 4;

                if (l == 0)
                {
                    this.exception_info = null;
                }
                else
                {
                    art = new byte[l];
                    Array.Copy(ar, index, art, 0, l);
                    index += l;
                    this.exception_info = DeserializeX(art);
                }
            }
            catch (Exception ex)
            {
                this.user_no = 0;
                this.user_name = "";
                this.password = "";
                this.is_stopped = false;
                this.can_add = false;
                this.can_delete = false;
                this.can_edit = false;
                this.can_manage_db = false;
                this.exception_info = new Exception("");
            }

        }


        public bool Fill(byte[] ar)
        {
            bool res = false;
            try
            {
                int index = 0;
                byte[] art = new byte[1];
                int l = 1;

                Array.Copy(ar, index, art, 0, l);
                this.user_no = ar[0];
                index += 1;

                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.user_name = Encoding.UTF8.GetString(art);


                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.password = Encoding.UTF8.GetString(art);

                this.is_stopped = BitConverter.ToBoolean(ar, index);
                index += 1;
                this.can_add = BitConverter.ToBoolean(ar, index);
                index += 1;
                this.can_delete = BitConverter.ToBoolean(ar, index);
                index += 1;
                this.can_edit = BitConverter.ToBoolean(ar, index);
                index += 1;
                this.can_manage_db = BitConverter.ToBoolean(ar, index);
                index += 1;

                l = BitConverter.ToInt32(ar, index);
                index += 4;

                if (l == 0)
                {
                    this.exception_info = null;
                }
                else
                {
                    art = new byte[l];
                    Array.Copy(ar, index, art, 0, l);
                    index += l;
                    this.exception_info = DeserializeX(art);
                }
                res = true;
            }
            catch (Exception ex)
            {
                this.user_no = 0;
                this.user_name = "";
                this.password = "";
                this.is_stopped = false;
                this.can_add = false;
                this.can_delete = false;
                this.can_edit = false;
                this.can_manage_db = false;
                this.exception_info = new Exception("");
            }

            return res;

        }



        public byte[] ToBytes()
        {

            List<byte> ar = new List<byte>();

            ar.Add((this.user_no));
            
            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.user_name).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.user_name));

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.password).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.password));

            ar.AddRange(BitConverter.GetBytes(this.is_stopped));
            ar.AddRange(BitConverter.GetBytes(this.can_add));
            ar.AddRange(BitConverter.GetBytes(this.can_delete));
            ar.AddRange(BitConverter.GetBytes(this.can_edit));
            ar.AddRange(BitConverter.GetBytes(this.can_manage_db));

            if (this.exception_info == null)
            {
                int x = 0;
                ar.AddRange(BitConverter.GetBytes(x));
            }
            else
            {
                byte[] e = SerializeX(this.exception_info);
                ar.AddRange(BitConverter.GetBytes(e.Length));
                ar.AddRange(e);
            }

            return ar.ToArray();
        }


        private Exception DeserializeX(byte[] ar)
        {

            Stream stream = new MemoryStream(ar);
            BinaryFormatter formatter = new BinaryFormatter();
            Exception ex = (Exception)formatter.Deserialize(stream);
            stream.Close();

            return ex;

        }

        private static byte[] SerializeX<T>(T obj)
        {
            using (MemoryStream memStream = new MemoryStream())
            {
                BinaryFormatter binSerializer = new BinaryFormatter();
                binSerializer.Serialize(memStream, obj);
                return memStream.ToArray();
            }
        }

    }
}
