﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace YMT
{
    public enum StationState
    {
        ENABLE = 0,
        DISABLE
    }

    public class Station
    {
        private int number;
        private string hwid;
        private string name;
        private string password;
        private StationState state;
        private clsBranchInfo branch;
        private Exception exception = null;

        public Station(clsBranchInfo branch, string hwid, string name, string password, int number = 0, StationState state = StationState.DISABLE)
        {
            this.branch = branch;
            this.hwid = hwid;
            this.name = name;
            this.password = password;
            this.number = number;
            this.state = state;
        }

        public int Number
        {
            get
            {
                return this.number;
            }
        }

        public string HWID
        {
            get
            {
                return this.hwid;
            }
        }

        public string Name
        {
            get
            {
                return this.name;
            }
        }

        public string Password
        {
            get
            {
                return this.password;
            }
        }

        public clsBranchInfo Branch
        {
            get
            {
                return this.branch;
            }
        }

        public StationState State
        {
            get
            {
                return this.state;
            }
            set
            {
                this.state = value;
            }
        }

        public Exception ExceptionInfo
        {
            get
            {
                return this.exception;
            }

        }

        public Station(byte[] ar)
        {
            try
            {
                int index = 0;
                byte[] art = new byte[1];
                int l = 1;

                Array.Copy(ar, index, art, 0, l);
                index += 1;

                this.state = (StationState)art[0];

                this.number = BitConverter.ToInt32(ar, index);
                index += 4;

                l = BitConverter.ToInt32(ar, index);
                index += 4;

                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.name = Encoding.UTF8.GetString(art);


                l = BitConverter.ToInt32(ar, index);
                index += 4;

                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.hwid = Encoding.UTF8.GetString(art);
                string id = Convert.ToBase64String(FingerPrint.Hash());
                string hash = Utilities.GetMD5Hash(id);
                this.hwid = hash;


                l = BitConverter.ToInt32(ar, index);
                index += 4;

                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.password = Encoding.UTF8.GetString(art);

                l = BitConverter.ToInt32(ar, index);
                index += 4;

                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.branch = new clsBranchInfo(art);


                l = BitConverter.ToInt32(ar, index);
                index += 4;

                if (l == 0)
                {
                    this.exception = null;
                }
                else
                {
                    art = new byte[l];
                    Array.Copy(ar, index, art, 0, l);
                    index += l;
                    this.exception = DeserializeX(art);
                }

            }
            catch
            {
                this.number = 0;
                this.name = "";
                this.hwid = "";
                this.password = "";
                this.state = StationState.DISABLE;
                this.branch = null;
                this.exception = new Exception("");
            }

        }
        public byte[] ToBytes()
        {

            List<byte> ar = new List<byte>();
            ar.Add((byte)this.state);

            ar.AddRange(BitConverter.GetBytes(this.number));



            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.name).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.name));


            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.hwid).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.hwid));

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.password).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.password));

            ar.AddRange(BitConverter.GetBytes(this.branch.ToBytes().Count()));
            ar.AddRange((this.branch.ToBytes()));

            if (this.exception == null)
            {
                int x = 0;
                ar.AddRange(BitConverter.GetBytes(x));
            }
            else
            {
                byte[] e = SerializeX(this.exception);
                ar.AddRange(BitConverter.GetBytes(e.Length));
                ar.AddRange(e);
            }

            return ar.ToArray();
        }

        private Exception DeserializeX(byte[] ar)
        {

            Stream stream = new MemoryStream(ar);
            BinaryFormatter formatter = new BinaryFormatter();
            Exception ex = (Exception)formatter.Deserialize(stream);
            stream.Close();

            return ex;
        }

        private static byte[] SerializeX<T>(T obj)
        {
            using (MemoryStream memStream = new MemoryStream())
            {
                BinaryFormatter binSerializer = new BinaryFormatter();
                binSerializer.Serialize(memStream, obj);
                return memStream.ToArray();
            }
        }

    }
}
