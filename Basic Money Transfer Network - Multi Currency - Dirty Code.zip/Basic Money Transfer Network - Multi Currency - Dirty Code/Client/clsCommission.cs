﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace YMT
{
    public enum CommissionType
    {
        Preceint = 0,
        Value
    }
    public class Commission
    {
        private clsBranchInfo from_branch_no;
        private clsBranchInfo to_branch_no;
        private clsCurrencyInfo cur_no;
        private decimal com_from;
        private int com_id;
        private decimal com_to;
        private CommissionType com_type;
        private decimal com_value;
        private CommissionType com_rec_type;
        private decimal com_rec_value;

        private Exception exception = null;

        public Commission(clsBranchInfo from_branch, clsBranchInfo to_branch, clsCurrencyInfo currency, decimal from, decimal to, CommissionType com_type, decimal com_value, CommissionType com_rec_type, decimal com_rec_value, int com_id = 0)
        {
            this.from_branch_no = from_branch;
            this.to_branch_no = to_branch;
            this.cur_no = currency;
            this.com_from = from;
            this.com_to = to;
            this.com_type = com_type;
            this.com_value = com_value;

            this.com_rec_type = com_rec_type;
            this.com_rec_value = com_rec_value;

            this.com_id = com_id;
        }

        public int CommissionID
        {
            get
            {
                return this.com_id;
            }
            set
            {
                this.com_id = value;
            }

        }

        public clsBranchInfo FromBranch
        {
            get
            {
                return this.from_branch_no;
            }
            set
            {
                this.from_branch_no = value;
            }

        }

        public clsBranchInfo ToBranch
        {
            get
            {
                return this.to_branch_no;
            }
            set
            {
                this.to_branch_no = value;
            }

        }

        public clsCurrencyInfo Currency
        {
            get
            {
                return this.cur_no;
            }
            set
            {
                this.cur_no = value;
            }

        }

        public decimal FromAmount
        {
            get
            {

                return Math.Round(this.com_from, 4);
            }
            set
            {
                this.com_to = value;
            }

        }

        public decimal ToAmount
        {
            get
            {
                return Math.Round(this.com_to, 4);
                //return this.com_to;
            }
            set
            {
                this.com_to = value;
            }

        }

        public CommissionType CommissionTypeInfo
        {
            get
            {
                return this.com_type;
            }
            set
            {
                this.com_type = value;
            }
        }



        public decimal CommissionValue
        {
            get
            {
                return Math.Round(this.com_value, 4);
               
            }
            set
            {
                this.com_value = value;
            }

        }

        public CommissionType CommissionTypeInfo2
        {
            get
            {
                return this.com_rec_type;
            }
            set
            {
                this.com_rec_type = value;
            }
        }

        public decimal CommissionValue2
        {
            get
            {
                return Math.Round(this.com_rec_value, 4);
               
            }
            set
            {
                this.com_rec_value = value;
            }

        }

        public Exception ExceptionInfo
        {
            get
            {
                return this.exception;
            }
            set
            {
                this.exception = value;
            }

        }

        public byte[] ToBytes()
        {
            List<byte> ar = new List<byte>();

            ar.AddRange(BitConverter.GetBytes((this.from_branch_no.ToBytes().Count())));
            ar.AddRange(((this.from_branch_no.ToBytes())));

            ar.AddRange(BitConverter.GetBytes((this.to_branch_no.ToBytes().Count())));
            ar.AddRange(((this.to_branch_no.ToBytes())));

            ar.AddRange(BitConverter.GetBytes((this.Currency.ToBytes().Count())));
            ar.AddRange(((this.Currency.ToBytes())));

            ar.AddRange(BitConverter.GetBytes((int)(this.com_id)));

            ar.AddRange(BitConverter.GetBytes((double)(this.com_from)));
            ar.AddRange(BitConverter.GetBytes((double)(this.com_to)));

            ar.Add(((byte)(this.com_type)));
            ar.AddRange(BitConverter.GetBytes((double)(this.com_value)));


            ar.Add(((byte)(this.com_rec_type)));
            ar.AddRange(BitConverter.GetBytes((double)(this.com_rec_value)));

            if (this.exception == null)
            {
                int x = 0;
                ar.AddRange(BitConverter.GetBytes(x));
            }
            else
            {
                byte[] e = SerializeX(this.exception);
                ar.AddRange(BitConverter.GetBytes(e.Length));
                ar.AddRange(e);
            }
            return ar.ToArray();
        }

        public Commission(byte[] ar)
        {
            try
            {
                int index = 0;
                byte[] art = new byte[1];

                int l = BitConverter.ToInt32(ar, 0);
                index += 4;

                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.from_branch_no = new clsBranchInfo(art);


                l = BitConverter.ToInt32(ar, index);
                index += 4;

                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;
                this.to_branch_no = new clsBranchInfo(art);


                l = BitConverter.ToInt32(ar, index);
                index += 4;

                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.cur_no = new clsCurrencyInfo(art);

                this.com_id = BitConverter.ToInt32(ar, index);
                index += 4;

                this.com_from = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                this.com_to = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                l = 1;
                art = new byte[1];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.com_type = (CommissionType)art[0];

                this.com_value = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                l = 1;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;
                this.com_rec_type = (CommissionType)art[0];


                this.com_rec_value = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                l = BitConverter.ToInt32(ar, index);
                index += 4;

                if (l == 0)
                {
                    this.exception = null;
                }
                else
                {
                    art = new byte[l];
                    Array.Copy(ar, index, art, 0, l);
                    index += l;
                    this.exception = DeserializeX(art);
                }
            }
            catch (Exception ex)
            {
                this.exception = new Exception("");
            }

        }



        public bool Fill(byte[] ar)
        {
            bool res = false;
            try
            {
                int index = 0;
                byte[] art = new byte[1];

                int l = BitConverter.ToInt32(ar, 0);
                index += 4;

                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.from_branch_no = new clsBranchInfo(art);


                l = BitConverter.ToInt32(ar, index);
                index += 4;

                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;
                this.to_branch_no = new clsBranchInfo(art);


                l = BitConverter.ToInt32(ar, index);
                index += 4;

                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.cur_no = new clsCurrencyInfo(art);

                this.com_id = BitConverter.ToInt32(ar, index);
                index += 4;

                this.com_from = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                this.com_to = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                l = 1;
                art = new byte[1];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.com_type = (CommissionType)art[0];

                this.com_value = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                l = 1;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;
                this.com_rec_type = (CommissionType)art[0];


                this.com_rec_value = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                l = BitConverter.ToInt32(ar, index);
                index += 4;

                if (l == 0)
                {
                    this.exception = null;
                }
                else
                {
                    art = new byte[l];
                    Array.Copy(ar, index, art, 0, l);
                    index += l;
                    this.exception = DeserializeX(art);
                }
            }
            catch (Exception ex)
            {
                this.exception = new Exception("");
            }

            return res;

        }

        private Exception DeserializeX(byte[] ar)
        {

            Stream stream = new MemoryStream(ar);
            BinaryFormatter formatter = new BinaryFormatter();
            Exception ex = (Exception)formatter.Deserialize(stream);
            stream.Close();

            return ex;

        }

        private static byte[] SerializeX<T>(T obj)
        {
            using (MemoryStream memStream = new MemoryStream())
            {
                BinaryFormatter binSerializer = new BinaryFormatter();
                binSerializer.Serialize(memStream, obj);
                return memStream.ToArray();
            }
        }

        public Commission(int com_id)
        {
            try
            {
                SocketCommender sc = new SocketCommender();
                byte[] ar = new byte[0];

                List<ParamInfo> lp = new List<ParamInfo>();
                lp.Add(new ParamInfo(Utilities.user.ToBytes()));
                lp.Add(new ParamInfo(BitConverter.GetBytes(com_id)));

                if (sc.GetObject(new Command(CommandType.Commission, lp), ref ar))
                {
                    Fill(ar);

                    if (this.exception!= null)
                    {
                        throw this.exception;
                    }
                }
                else
                {
                    this.exception = new Exception("");
                }
            }

            catch (Exception ex)
            {
                this.exception = ex;
            }
        }

        public Commission(clsBranchInfo from, clsBranchInfo to, clsCurrencyInfo currency, decimal amount)
        {
            try
            {
                SocketCommender sc = new SocketCommender();
                byte[] ar = new byte[0];

                List<ParamInfo> lp = new List<ParamInfo>();
                lp.Add(new ParamInfo(Utilities.user.ToBytes()));
                lp.Add(new ParamInfo(from.ToBytes()));
                lp.Add(new ParamInfo(to.ToBytes()));
                lp.Add(new ParamInfo(currency.ToBytes()));
                lp.Add(new ParamInfo(BitConverter.GetBytes((double)amount)));

                if (sc.GetObject(new Command(CommandType.CommissionByInfo, lp), ref ar))
                {
                    Fill(ar);

                    if (this.exception != null)
                    {
                        throw this.exception;
                    }
                }
                else
                {
                    this.exception = new Exception("");
                }
            }

            catch (Exception ex)
            {
                this.exception = ex;
            }
        }

    }

}
