﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.IO;
using System.Data.OleDb;

using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace YMT
{
    public class clsBranchInfo
    {
        private byte branch_no;
        private string branch_name;
        private string branch_address;
        private string branch_phone;
        private string branch_mobile;
        private Image branch_flag;
        private Exception exception_info = null;

        public byte BranchNumber
        {
            get
            {
                return this.branch_no;
            }
            set
            {
                this.branch_no = value;
            }
        }

        public string BranchName
        {
            get
            {
                return this.branch_name;
            }
            set
            {
                this.branch_name = value;
            }
        }

        public string BranchAddress
        {
            get
            {
                return this.branch_address;
            }
            set
            {
                this.branch_address = value;
            }
        }

        public string BranchPhone
        {
            get
            {
                return this.branch_phone;
            }
            set
            {
                this.branch_phone = value;
            }
        }

        public string BrancMobile
        {
            get
            {
                return this.branch_mobile;
            }
            set
            {
                this.branch_mobile = value;
            }
        }

        public Image BranchFlag
        {
            get
            {
                return this.branch_flag;
            }
            set
            {
                this.branch_flag = value;
            }
        }

        public Exception ExceptionInfo
        {
            get { return this.exception_info; }
            set
            {
                this.exception_info = value;
            }

        }

        public clsBranchInfo(byte number, string branch_name, string branch_address, string branch_phone, string branch_mobile, byte[] branch_flag = null)
        {
            this.branch_no = number;
            this.branch_name = branch_name;
            this.branch_address = branch_address;
            this.branch_phone = branch_phone;
            this.branch_mobile = branch_mobile;
            //this.branch_flag = new Bitmap(new Stream(branch_flag));
        }


        public clsBranchInfo(byte number)
        {
            try
            {
                SocketCommender sc = new SocketCommender();
                byte[] ar = new byte[0];

                List<ParamInfo> lp = new List<ParamInfo>();
                lp.Add(new ParamInfo(Utilities.user.ToBytes()));
                lp.Add(new ParamInfo(new byte[] { number }));

                if (sc.GetObject(new Command(CommandType.BranchInfo, lp), ref ar))
                {

                    clsBranchInfo branch = new clsBranchInfo(ar);

                    this.branch_no = branch.branch_no;
                    this.branch_name = branch.branch_name;
                    this.branch_address = branch.branch_address;
                    this.branch_phone = branch.branch_phone;
                    this.branch_mobile = branch.branch_mobile;

                    byte[] img = new byte[1];// branch.branch_flag;

                    try
                    {
                        MemoryStream ms = new MemoryStream(img);
                        this.branch_flag = new Bitmap(ms);
                    }
                    catch
                    {
                    
                    }

                }
                else
                {
                    this.exception_info = new Exception("");
                }
            }

            catch (Exception ex)
            {
                this.exception_info = ex;
            }

        }


        public clsBranchInfo(byte[] ar)
        {
            try
            {
                int index = 0;
                byte[] art = new byte[1];
                Array.Copy(ar, index, art, 0, 1);
                index += 1;

                this.branch_no = art[0];

                int l = BitConverter.ToInt32(ar, 1);
                index += 4;


                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.branch_name = Encoding.UTF8.GetString(art);


                l = BitConverter.ToInt32(ar, index);
                index += 4;

                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.branch_address = Encoding.UTF8.GetString(art);


                l = BitConverter.ToInt32(ar, index);
                index += 4;

                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.branch_phone = Encoding.UTF8.GetString(art);

                l = BitConverter.ToInt32(ar, index);
                index += 4;

                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.branch_mobile = Encoding.UTF8.GetString(art);





                l = BitConverter.ToInt32(ar, index);
                index += 4;

                if (l == 0)
                {
                    this.exception_info = null;
                }
                else
                {
                    art = new byte[l];
                    Array.Copy(ar, index, art, 0, l);
                    index += l;
                    this.exception_info = DeserializeX(art);
                }
            }
            catch (Exception ex)
            {
                this.branch_no = 0;
                this.branch_address = "";
                this.branch_phone = "";
                this.branch_mobile = "";
                this.exception_info = new Exception("");
            }

        }


        public byte[] ToBytes()
        {

            List<byte> ar = new List<byte>();

            ar.Add(this.branch_no);

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.branch_name).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.branch_name));

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.branch_address).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.branch_address));

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.branch_phone).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.branch_phone));

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.branch_mobile).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.branch_mobile));


            if (this.exception_info == null)
            {
                int x = 0;
                ar.AddRange(BitConverter.GetBytes(x));
            }
            else
            {
                byte[] e = SerializeX(this.exception_info);
                ar.AddRange(BitConverter.GetBytes(e.Length));
                ar.AddRange(e);
            }
            return ar.ToArray();
        }


        private Exception DeserializeX(byte[] ar)
        {

            Stream stream = new MemoryStream(ar);
            BinaryFormatter formatter = new BinaryFormatter();
            Exception ex = (Exception)formatter.Deserialize(stream);
            stream.Close();

            return ex;

        }


        private static byte[] SerializeX<T>(T obj)
        {
            using (MemoryStream memStream = new MemoryStream())
            {
                BinaryFormatter binSerializer = new BinaryFormatter();
                binSerializer.Serialize(memStream, obj);
                return memStream.ToArray();
            }
        }
    }


    public static class BranchInfoManager
    {

        private static clsBranchInfo branch = new clsBranchInfo(1);

        public static clsBranchInfo GetBranchInfo
        {
            get
            {
                return branch;
            }
            set
            {
                branch = value;
            }

        }


        public static List<clsBranchInfo> GetALLBranchInfo()
        {
            List<clsBranchInfo> branchies = new List<clsBranchInfo>();

            try
            {
                SocketCommender sc = new SocketCommender();
                byte[] ar = new byte[0];

                if (sc.GetObject(new Command(CommandType.GetALLBranchies), ref ar))
                {
                    byte[] art = new byte[0];

                    int index = 0;
                    int count = BitConverter.ToInt32(ar, index);
                    index += 4;

                    for (int i = 0; i < count; i++)
                    {
                        int size = BitConverter.ToInt32(ar, index);
                        index += 4;

                        art = new byte[size];
                        Array.Copy(ar, index, art, 0, size);
                        index += size;

                        clsBranchInfo branch = new clsBranchInfo(art);

                        if (branch.ExceptionInfo == null)
                        {
                            branchies.Add(branch);
                        }

                    }

                }
            }

            catch (Exception ex)
            {

            }

            return branchies;

        }
    }


}
