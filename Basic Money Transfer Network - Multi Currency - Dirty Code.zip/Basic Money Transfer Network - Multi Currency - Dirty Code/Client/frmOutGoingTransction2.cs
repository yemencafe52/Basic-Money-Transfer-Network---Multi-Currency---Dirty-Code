﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace YMT
{
    public partial class frmOutGoingTransction : Form
    {
        public frmOutGoingTransction()
        {
            InitializeComponent();


            if (!(Utilities.user.CanAdd))
            {
                button9.Visible = false;
            }

            if (!(Utilities.user.CanEdit))
            {
                button8.Visible = false;
            }

            Reset();
        }



        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {

            if (keyData == (Keys.Control | Keys.F))
            {
                button5.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.P))
            {
                button2.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.N))
            {
                button9.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.E))
            {
                button8.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.S))
            {
                button7.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.Delete))
            {
                // button1.PerformClick();
                return true;
            }

            if (keyData == (Keys.Shift | Keys.Escape))
            {
                if (button7.Enabled)
                {
                    button6.PerformClick();
                }
                else
                {
                    this.Close();
                }
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }


        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void frmOutGoingTransction_Load(object sender, EventArgs e)
        {
            comboBox6.Items.Add("داخلي");
            comboBox6.Items.Add("خارجي");
            comboBox6.SelectedIndex = 0;
            comboBox6.Enabled = false;
            dateTimePicker1.CustomFormat = "yyyy/MM/dd";

            List<clsCurrencyInfo> currencies = CurrencyManager.GetALLCurrency();

            comboBox2.DisplayMember = "CurrencyName";
            comboBox2.ValueMember = "CurrencyNumber";
            comboBox2.DataSource = currencies;

            if (comboBox2.Items.Count > 0)
            {
                comboBox2.SelectedIndex = 0;
            }

        }

        private void ClearALL()
        {
            numericUpDown1.Value = 0;
            numericUpDown2.Value = 0;
            numericUpDown4.Value = 0;
            textBox1.Text = "";
            textBox2.Text = "";
            comboBox2.SelectedIndex = 0;
            comboBox6.SelectedIndex = 0;
            
        }

        private void AddNew()
        {
            if (Utilities.is_connected == false)
            {
                MessageBox.Show("الشبكة غير متوفرة.", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                return;
            }

            ClearALL();
            DisableALL();
            dateTimePicker1.Value = DateTime.Now;
            numericUpDown1.Enabled = true;
            
            button6.Enabled = true;
            button7.Enabled = true;

            textBox1.Enabled = true;
            textBox2.Enabled = true;

            comboBox2.Enabled = true;

            numericUpDown4.Value = TransferOutGoingManager.GenerateNewTransctionID();


        }

        private void Save()
        {
            if (Utilities.is_connected == false)
            {
                MessageBox.Show("الشبكة غير متوفرة.", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                return;
            }

            if (!(numericUpDown1.Value > 0))
            {
                numericUpDown1.Focus();
                return;
            }

            if (!(numericUpDown2.Value > 0))
            {
                numericUpDown2.Focus();
                return;
            }


            if (!(numericUpDown4.Value > 0))
            {
                numericUpDown4.Focus();
                return;
            }


            if (string.IsNullOrEmpty(textBox1.Text))
            {
                textBox1.Focus();
                return;
            }

            if (string.IsNullOrEmpty(textBox2.Text))
            {
                textBox2.Focus();
                return;
            }

            clsCurrencyInfo c = new clsCurrencyInfo(Convert.ToByte(comboBox2.SelectedValue));

            TransferOutGoing ogt = new TransferOutGoing((int)numericUpDown4.Value, MoneyTransferType.OUT, dateTimePicker1.Value, (numericUpDown1.Value * c.CurrencyExchange), numericUpDown1.Value, (numericUpDown2.Value * c.CurrencyExchange), ((numericUpDown2.Value * c.CurrencyExchange) / ((decimal)2)), textBox1.Text, textBox2.Text, Utilities.user, c, c.CurrencyExchange, numericUpDown2.Value, (numericUpDown2.Value / ((decimal)2)), BranchInfoManager.GetBranchInfo, BranchInfoManager.GetBranchInfo);

            TransferOutGoing ff = new TransferOutGoing(ogt.ToBytes());


            DialogResult res = MessageBox.Show("هل تريد إعتماد الحوالة فعلاً؟", "تاكيد الإعتماد", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);

            if (res == System.Windows.Forms.DialogResult.No)
            {
                return;
            }

            if (TransferOutGoingManager.CreateNewOutGoingTransction(ogt))
            {
                Reset();
                MessageBox.Show("تمت العملية بنجاح  .", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
            }
            else
            {
                MessageBox.Show("تعذر على النظام تنفيذ العملية  .", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
            }
        }

    
        private void DisableALL()
        {

            numericUpDown1.Enabled = false;
            numericUpDown2.Enabled = false;
            numericUpDown4.Enabled = false;

            button2.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = false;
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            comboBox2.Enabled = false;

            comboBox6.Enabled = false;

            dateTimePicker1.Enabled = false;

        }

        private void Delete()
        {

        }

        private void Update()
        {

            DisableALL();

            //op = false;

            textBox1.Focus();
            button6.Enabled = true;


        }

        private void Reset()
        {
            DisableALL();

            button9.Enabled = true;
            button8.Enabled = true;

        }

        private void button9_Click(object sender, EventArgs e)
        {
            AddNew();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            if (numericUpDown1.Value > 0)
            {
                decimal v1 = (numericUpDown1.Value / ((decimal)100)) * ((decimal)(1));
                numericUpDown2.Value = v1;
            }
            else
            {
                numericUpDown2.Value = 0;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Save();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Update();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Reset();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Search();
        }

        private void Search()
        {
            Reset();
            button6.Enabled = true;
            button8.Enabled = false;
            button9.Enabled = false;
            numericUpDown4.Enabled = true;
            numericUpDown4.Focus();
            numericUpDown4.Select(0, 9999);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Print();
        }

        private void Print()
        {
            return ;
        }

        private void numericUpDown4_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (Utilities.is_connected == false)
                {
                    MessageBox.Show("الشبكة غير متوفرة.", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                    return;
                }

                TransferOutGoing ogt = new TransferOutGoing((int)numericUpDown4.Value);
                if (ogt.ExceptionInfo == null)
                {
                    DisableALL();
                    button2.Enabled = true;
                    button5.Enabled = true;
                    button8.Enabled = true;
                    button9.Enabled = true;

                    comboBox2.SelectedValue = ogt.Currency.CurrencyNumber;
                    numericUpDown1.Value = ogt.FAmount;

                    numericUpDown4.Value = ogt.Number;
                    numericUpDown2.Value = ogt.OutGoingTransferFCommation;
                    dateTimePicker1.Value = ogt.Date;
                    textBox1.Text = ogt.SenderName;
                    textBox2.Text = ogt.ReciverName;

                    //comboBox1.SelectedValue = ogt.Cash.LedId;
                    //comboBox5.SelectedValue = ogt.ReciverAccount.LedId;


                }
            }
        }

        private void numericUpDown1_Enter(object sender, EventArgs e)
        {
            numericUpDown1.Select(0, 999);
        }

        private void numericUpDown1_Click(object sender, EventArgs e)
        {
            numericUpDown1.Select(0, 999);
        }

        private void numericUpDown4_Click(object sender, EventArgs e)
        {
            numericUpDown4.Select(0, 999);
        }

        private void numericUpDown4_Enter(object sender, EventArgs e)
        {
            numericUpDown4.Select(0, 999);
        }

        private void numericUpDown2_Enter(object sender, EventArgs e)
        {
            numericUpDown2.Select(0, 999);
        }

        private void numericUpDown2_Click(object sender, EventArgs e)
        {
            numericUpDown2.Select(0, 999);
        }
    }
       
}
