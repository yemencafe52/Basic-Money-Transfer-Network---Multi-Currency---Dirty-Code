﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YMT
{
    public partial class frmIncomingTransction : Form
    {
        public frmIncomingTransction()
        {
            InitializeComponent();

            if (!(Utilities.user.CanAdd))
            {
                button9.Visible = false;
            }

            if (!(Utilities.user.CanEdit))
            {
                button8.Visible = false;
            }

            Reset();
            button5.PerformClick();
        }

        private void frmIncomingTransction_Load(object sender, EventArgs e)
        {
            comboBox6.Items.Add("داخلي");
            comboBox6.Items.Add("خارجي");
            comboBox6.SelectedIndex = 0;
            comboBox6.Enabled = false;
            dateTimePicker1.CustomFormat = "yyyy/MM/dd";

            List<clsCurrencyInfo> currencies = CurrencyManager.GetALLCurrency();

            comboBox2.DisplayMember = "CurrencyName";
            comboBox2.ValueMember = "CurrencyNumber";
            comboBox2.DataSource = currencies;

            if (comboBox2.Items.Count > 0)
            {
                comboBox2.SelectedIndex = 0;
            }

        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {

            if (keyData == (Keys.Control | Keys.F))
            {
                button5.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.P))
            {
                button2.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.N))
            {
                button9.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.E))
            {
                button8.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.S))
            {
                button7.PerformClick();
                return true;
            }

            if (keyData == (Keys.Control | Keys.Delete))
            {
                // button1.PerformClick();
                return true;
            }

            if (keyData == (Keys.Shift | Keys.Escape))
            {
                if (button7.Enabled)
                {
                    button6.PerformClick();
                }
                else
                {
                    this.Close();
                }
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }


        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void ClearALL()
        {
            numericUpDown1.Value = 0;

            numericUpDown4.Value = 0;
            textBox1.Text = "";
            textBox2.Text = "";
            comboBox2.SelectedIndex = 0;
            comboBox6.SelectedIndex = 0;
          
        }

        private void AddNew()
        {
            if (Utilities.is_connected == false)
            {
                MessageBox.Show("الشبكة غير متوفرة.", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                return;
            }

            TransferOutGoing ogt = new TransferOutGoing((int)numericUpDown4.Value);
            if (ogt.ExceptionInfo == null)
            {

                TransferIncoming ti = new TransferIncoming(0, ogt, Utilities.user, DateTime.Now, BranchInfoManager.GetBranchInfo);


                DialogResult res = MessageBox.Show("هل تريد تسليم الحوالة فعلاً؟", "تاكيد التسليم", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);

                if (res == System.Windows.Forms.DialogResult.No)
                {
                    return;
                }

                if (TransferIncomingManager.CreateNewIncomingTransction(ti))
                {
                    Reset();
                    MessageBox.Show("تمت العملية بنجاح  .", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                }
                else
                {
                    MessageBox.Show("تعذر على النظام تنفيذ العملية  .", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                }
            }


        }

        private void Save()
        {
            if (Utilities.is_connected == false)
            {
                MessageBox.Show("الشبكة غير متوفرة.", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                return;
            }

            if (!(numericUpDown1.Value > 0))
            {
                numericUpDown1.Focus();
                return;
            }

            if (!(numericUpDown4.Value > 0))
            {
                numericUpDown4.Focus();
                return;
            }


            if (string.IsNullOrEmpty(textBox1.Text))
            {
                textBox1.Focus();
                return;
            }

            if (string.IsNullOrEmpty(textBox2.Text))
            {
                textBox2.Focus();
                return;
            }
        }
        private void DisableALL()
        {

            numericUpDown1.Enabled = false;
            dateTimePicker2.Enabled = false;
            dateTimePicker2.Visible = false;
            label2.Visible = false;
            numericUpDown4.Enabled = false;

            button2.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = false;
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            comboBox2.Enabled = false;

            comboBox6.Enabled = false;

            dateTimePicker1.Enabled = false;

        }

        private void Delete()
        {

        }

        private void Update()
        {
            DisableALL();
            textBox1.Focus();
            button6.Enabled = true;
        }

        private void Reset()
        {
            DisableALL();
            button8.Enabled = true;

        }

        private void button9_Click(object sender, EventArgs e)
        {
            AddNew();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Save();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Update();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Reset();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Search();
        }

        private void Search()
        {
            ClearALL();
            Reset();
            button6.Enabled = true;
            button8.Enabled = false;
            button9.Enabled = false;
            numericUpDown4.Enabled = true;
            numericUpDown4.Focus();
            numericUpDown4.Select(0, 9999);
        }

        private void numericUpDown4_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {

                if (Utilities.is_connected == false)
                {
                    MessageBox.Show("الشبكة غير متوفرة.", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                    return;
                }

                TransferOutGoing ogt = new TransferOutGoing((int)numericUpDown4.Value);
                if (ogt.ExceptionInfo == null)
                {
                    DisableALL();
                    button2.Enabled = true;
                    button5.Enabled = true;
                    button8.Enabled = true;
                    button9.Enabled = true;

                    comboBox2.SelectedValue = ogt.Currency.CurrencyNumber;
                    numericUpDown1.Value = ogt.FAmount;

                    numericUpDown4.Value = ogt.Number;

                    dateTimePicker1.Value = ogt.Date;
                    textBox1.Text = ogt.SenderName;
                    textBox2.Text = ogt.ReciverName;

                    TransferIncoming ti = new TransferIncoming((int)numericUpDown4.Value);
                    if (ti.ExceptionInfo == null)
                    {
                        label2.Visible = true;
                        dateTimePicker2.Visible = true;
                        button9.Enabled = false;
                    }

                }
            }
        }

        private void numericUpDown1_Enter(object sender, EventArgs e)
        {
            numericUpDown1.Select(0, 999);
        }

        private void numericUpDown1_Click(object sender, EventArgs e)
        {
            numericUpDown1.Select(0, 999);
        }

        private void numericUpDown4_Click(object sender, EventArgs e)
        {
            numericUpDown4.Select(0, 999);
        }

        private void numericUpDown4_Enter(object sender, EventArgs e)
        {
            numericUpDown4.Select(0, 999);
        }

    }
}
