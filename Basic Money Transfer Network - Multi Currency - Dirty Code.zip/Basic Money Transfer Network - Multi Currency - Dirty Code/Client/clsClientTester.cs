﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace EMT
{

    class clsClientTester
    {
        private IPAddress ip;
        private string user_name;
        private string password;
        private User user;
        private clsBranchInfo clsBranch;

        Thread th;
        public int scc = 0;
        public int swc = 0;

        public int rcc = 0;
        public int rwc = 0;
        public int id = 0;
        public int i = 0;

        public int tx = 0;
        public int tx_err = 0;

        public int qx = 0;
        public int qx_err = 0;

        public int rx = 0;
        public int rx_err = 0;

        public int ping = -1;

        List<TransferOutGoing> l = new List<TransferOutGoing>();


        public void Ping()
        {
            while (true)
            {
                int tick = Environment.TickCount;
                SocketCommender sc = new SocketCommender();

                int res = 0;
                byte[] ar = new byte[0];

                if (sc.GetObject(new Command(CommandType.StartPing, new ParamInfo(Utilities.user.ToBytes())), ref ar))
                {
                    res = Environment.TickCount - tick;
                }
                else
                {
                    res = -1;
                }

                this.ping = res;

                Thread.Sleep(5000);
            }
        }

        public clsClientTester(IPAddress ip, string username, string password, int id,int branch_no)
        {   
         //   if(Users.Login(username, password, ref this.user))
          //  {
                this.clsBranch = new clsBranchInfo((byte)branch_no);
         //   }

            this.id = id;
        }

        public void START()
        {

            th = new Thread(Go);
            th.Start();
        }

        private void Go()
        {

            th = new Thread(Ping);
            th.IsBackground = true;
            th.Start();

            for (i = 0; i < 100; i++)
            {
                TransferOutGoing ogt = GenerateRandomOGT();

                if (TransferOutGoingManager.CreateNewOutGoingTransction(ogt))
                {
                    tx++;
                    
                    TransferOutGoing ogt2 = new TransferOutGoing(ogt.Number);
                    if (ogt2.ExceptionInfo == null)
                    {
                        qx++;

                        TransferIncoming ic = new TransferIncoming(0, ogt2, Utilities.user, DateTime.Now, BranchInfoManager.GetBranchInfo);
                        if(TransferIncomingManager.CreateNewIncomingTransction(ic))
                        {
                            rx++;
                        }
                        else
                        {
                            rx_err++;
                        }
                    }
                    else
                    {
                        qx_err++;
                    }
                }
                else
                {
                    tx_err++;
                }
            }
        }


        private TransferOutGoing GenerateRandomOGT()
        {
            int trans_no = TransferOutGoingManager.GenerateNewTransctionID();

            byte src_branch_no = byte.Parse(GenerateID(0, 1));
            byte dst_branch_no = byte.Parse(GenerateID(0, 1));
            byte currncy_no = byte.Parse(GenerateID(0, 1));

            decimal amount = decimal.Parse(id.ToString() + GenerateID(5, 9));
            decimal trans_commation = 0;
            decimal rec_commation = 0;

            clsBranchInfo src_b = new clsBranchInfo(src_branch_no);
            clsBranchInfo dst_b = new clsBranchInfo(dst_branch_no);
            clsCurrencyInfo currncy = new clsCurrencyInfo(currncy_no);

            Commission com = new Commission(src_b, dst_b, currncy, amount);

            if (com.CommissionTypeInfo == CommissionType.Preceint)
            {
                decimal v1 = (amount / ((decimal)100)) * ((decimal)com.CommissionValue);
                trans_commation = v1;

                if (com.CommissionTypeInfo2 == CommissionType.Preceint)
                {
                    rec_commation = (trans_commation / ((decimal)(100)) * com.CommissionValue2);
                }
                else
                {
                    rec_commation = com.CommissionValue2;
                }

            }
            else
            {
                trans_commation = com.CommissionValue;

                if (com.CommissionTypeInfo2 == CommissionType.Preceint)
                {
                    rec_commation = (trans_commation / ((decimal)(100)) * com.CommissionValue2);
                }
                else
                {
                    rec_commation = com.CommissionValue2;
                }
            }

            TransferOutGoing ogt = new TransferOutGoing(trans_no, MoneyTransferType.IN, DateTime.Now, (amount * currncy.CurrencyExchange), amount, (trans_commation * currncy.CurrencyExchange), (rec_commation * currncy.CurrencyExchange), "dfsdf", "dfsdf", Utilities.user, currncy, currncy.CurrencyExchange, trans_commation, rec_commation, src_b, dst_b);
            return ogt;

        }

        public string GenerateID(int length, byte to_digi)
        {
            Random r = new Random();
            string id = "";


            int x = r.Next(1, to_digi);
            id += x.ToString();

            for (int index = 1; index <= length; index++)
            {
                x = r.Next(0, to_digi);
                id += x.ToString();
            }

            return id;

        }
    }
}
