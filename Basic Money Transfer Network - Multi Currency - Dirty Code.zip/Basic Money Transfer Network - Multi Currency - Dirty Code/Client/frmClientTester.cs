﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EMT
{
    public partial class frmClientTester : Form
    {
        public frmClientTester()
        {
            InitializeComponent();
        }

        long tick = 0;
        int i = 0;
       

        private void frmClientTester_Load(object sender, EventArgs e)
        {
            CheckForIllegalCrossThreadCalls = false;
            Utilities.ip = System.Net.IPAddress.Parse("127.0.0.1");
            Users.Login("admin", "admin", ref Utilities.user);
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
         int total_tx = 0;
         int total_tx_err = 0;

         int total_qx = 0;
         int total_qx_err = 0;

         int total_rx = 0;
         int total_rx_err = 0;


            int v = 0;
            for (int i = 0; i < Utilities.cl.Count; i++)
            {
                listView1.Items[i].SubItems[1].Text = Utilities.cl[i].tx.ToString();
                listView1.Items[i].SubItems[2].Text = Utilities.cl[i].tx_err.ToString();
                listView1.Items[i].SubItems[3].Text = Utilities.cl[i].qx.ToString();
                listView1.Items[i].SubItems[4].Text = Utilities.cl[i].qx_err.ToString();
                listView1.Items[i].SubItems[5].Text = Utilities.cl[i].rx.ToString();
                listView1.Items[i].SubItems[6].Text = Utilities.cl[i].rx_err.ToString();


                if (Utilities.cl[i].ping == -1)
                {
                    listView1.Items[i].SubItems[7].Text  = "OOPS -1 :(";
                    Utilities.is_connected = false;
                }
                else if (Utilities.cl[i].ping == 0)
                {
                    Utilities.is_connected = true;
                    listView1.Items[i].SubItems[7].Text  = "1ms<";
                }
                else
                {
                    Utilities.is_connected = true;
                    listView1.Items[i].SubItems[7].Text  = Utilities.cl[i].ping.ToString() + "ms";
                }


                //= Utilities.cl[i].ping.ToString();
                listView1.Items[i].SubItems[8].Text = Utilities.cl[i].i.ToString();

                total_tx += Utilities.cl[i].tx;
                total_tx_err += Utilities.cl[i].tx_err;

                total_qx += Utilities.cl[i].qx;
                total_qx_err += Utilities.cl[i].qx_err;

                total_rx += Utilities.cl[i].rx;
                total_rx_err += Utilities.cl[i].rx_err;

                v += Utilities.cl[i].i;
                Application.DoEvents();
            }

            toolStripProgressBar1.Minimum = 0;
            toolStripProgressBar1.Maximum = Utilities.cl.Count * 100;
            toolStripProgressBar1.Value = v;

            toolStripStatusLabel2.Text = total_tx.ToString();
            toolStripStatusLabel4.Text = total_tx_err.ToString();

            toolStripStatusLabel6.Text = total_qx.ToString();
            toolStripStatusLabel8.Text = total_qx_err.ToString();

            toolStripStatusLabel10.Text = total_rx.ToString();
            toolStripStatusLabel12.Text = total_rx_err.ToString();


            TimeSpan t = TimeSpan.FromSeconds(((int)((long)Environment.TickCount - tick)/ ((int)1000)));
            toolStripStatusLabel14.Text = t.Duration().ToString();
           // progressBar1.Minimum = 0;
           // progressBar1.Maximum = Utilities.cl.Count * 100;
           // progressBar1.Value = v;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            int x = 0;

            if (int.TryParse(toolStripTextBox4.Text, out x)== false)
            {
                MessageBox.Show("Invlaid Clients Count");
                return;
            }

            if (Utilities.is_runing == false)
            {
                listView1.Items.Clear();

                for (i = 0; i < x; i++)
                {
                    Utilities.cl.Add(new clsClientTester(System.Net.IPAddress.Parse(toolStripTextBox1.Text), toolStripTextBox2.Text, toolStripTextBox3.Text, i, 1));
                    //Utilities.cl[i].START();

                    ListViewItem lvi = new ListViewItem(i.ToString());
                    lvi.SubItems.Add("0");
                    lvi.SubItems.Add("0");
                    lvi.SubItems.Add("0");
                    lvi.SubItems.Add("0");
                    lvi.SubItems.Add("0");
                    lvi.SubItems.Add("0");
                    lvi.SubItems.Add("0");
                    lvi.SubItems.Add("0");
                    listView1.Items.Add(lvi);

                    Application.DoEvents();
                    //  th = new Thread(START);
                    //  th.Start();

                }

                tick = Environment.TickCount;
                for (i = 0; i < x; i++)
                {
                    Utilities.cl[i].START();

                }

                Utilities.is_runing = true;
                timer1.Enabled = true;
                //button1.Text = "STOP";
            }
            else
            {
                Utilities.is_runing = false;
                timer1.Enabled = false;
                //button1.Text = "START";
            }
        }
    }
}
