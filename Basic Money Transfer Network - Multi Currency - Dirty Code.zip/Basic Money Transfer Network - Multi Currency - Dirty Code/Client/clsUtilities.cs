﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;
using System.Security.Cryptography;
using System.Runtime.InteropServices;
using System.Net;

using System.Net.Sockets;

namespace YMT
{
    internal static class Utilities
    {
        static public User user;
        static public IPAddress ip;
        static public bool is_connected = false;
        static public StationHandCheckInfo SHC = null;

        internal static string GetMD5Hash(string txt)
        {

            using (MD5 md5Hash = MD5.Create())
            {
                // Convert the input string to a byte array and compute the hash. 
                byte[] data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(txt));

                StringBuilder sBuilder = new StringBuilder();

                // Loop through each byte of the hashed data  
                // and format each one as a hexadecimal string. 
                for (int i = 0; i < data.Length; i++)
                {
                    sBuilder.Append(data[i].ToString("x2"));
                }

                // Return the hexadecimal string. 
                return sBuilder.ToString();

            }

        }


        public static byte[] DecryptData(byte[] encryptedTextByte, string Encryptionkey)
        {
            RijndaelManaged objrij = new RijndaelManaged();

            objrij.Mode = CipherMode.CBC;

            objrij.Padding = PaddingMode.PKCS7;

            objrij.KeySize = 0x80;

            objrij.BlockSize = 0x80;

            //byte[] encryptedTextByte = Convert.FromBase64String(EncryptedText);

            byte[] passBytes = Encoding.UTF8.GetBytes(Encryptionkey);

            byte[] EncryptionkeyBytes = new byte[0x10];

            int len = passBytes.Length;

            if (len > EncryptionkeyBytes.Length)
            {

                len = EncryptionkeyBytes.Length;

            }

            Array.Copy(passBytes, EncryptionkeyBytes, len);

            objrij.Key = EncryptionkeyBytes;

            objrij.IV = EncryptionkeyBytes;

            byte[] TextByte = objrij.CreateDecryptor().TransformFinalBlock(encryptedTextByte, 0, encryptedTextByte.Length);

            return (TextByte);

        }

        public static byte[] EncryptData(byte[] textDataByte, string Encryptionkey)
        {

            RijndaelManaged objrij = new RijndaelManaged();

            objrij.Mode = CipherMode.CBC;

            objrij.Padding = PaddingMode.PKCS7;

            objrij.KeySize = 0x80;

            objrij.BlockSize = 0x80;

            //set the symmetric key that is used for encryption & decryption.

            byte[] passBytes = Encoding.UTF8.GetBytes(Encryptionkey);

            //set the initialization vector (IV) for the symmetric algorithm

            byte[] EncryptionkeyBytes = new byte[] { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };

            int len = passBytes.Length;

            if (len > EncryptionkeyBytes.Length)
            {

                len = EncryptionkeyBytes.Length;

            }

            Array.Copy(passBytes, EncryptionkeyBytes, len);

            objrij.Key = EncryptionkeyBytes;

            objrij.IV = EncryptionkeyBytes;

            //Creates symmetric AES object with the current key and initialization vector IV.

            ICryptoTransform objtransform = objrij.CreateEncryptor();

            //byte[] textDataByte = Encoding.UTF8.GetBytes(textData);

            //Final transform the test string.

            return (objtransform.TransformFinalBlock(textDataByte, 0, textDataByte.Length));

        }


        static public bool ReadAU(string file)
        {
            bool res = false;

            try
            {

                FileStream fs = new FileStream(file, FileMode.Open);
                long size = fs.Length;
                byte[] ar = new byte[size];
                fs.Read(ar, 0, ar.Length);
                fs.Close();

                StationHandCheckInfo shc = new StationHandCheckInfo(Utilities.DecryptData(ar, "123"));

                if (shc.ExceptionInfo == null)
                {
                    Utilities.SHC = shc;
                    res = true;
                }
            }
            catch
            {
                res = false;
            }

            return res;
        }



        internal static int GetLastDayInMoth(int year, int month)
        {
            int res = 0;

            DateTime t = new DateTime(year, month, 28);

            for (int i = 28; i < 32; i++)
            {
                t = t.AddDays(1);
                if (t.Month != month)
                {
                    res = i;
                    break;
                }
            }

            return res;

        }
    }
}