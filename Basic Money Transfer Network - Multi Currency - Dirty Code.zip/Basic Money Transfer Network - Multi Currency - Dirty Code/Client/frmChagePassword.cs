﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YMT
{
    public partial class frmChagePassword : Form
    {
        public frmChagePassword()
        {
            InitializeComponent();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {

            if (keyData == (Keys.Shift | Keys.Escape))
            {

                {
                    this.Close();
                }
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }



        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                textBox1.SelectAll();
                textBox1.Focus();
                return;
            }

            if (string.IsNullOrEmpty(textBox2.Text))
            {
                textBox2.SelectAll();
                textBox2.Focus();
                return;
            }

            if (string.IsNullOrEmpty(textBox3.Text))
            {
                textBox3.SelectAll();
                textBox3.Focus();
                return;
            }

            if ((textBox3.Text) != (textBox2.Text))
            {
                textBox2.SelectAll();
                textBox2.Focus();
                return;
            }

            SocketCommender sc = new SocketCommender();
            byte[] ar = new byte[0];

            List<ParamInfo> lp = new List<ParamInfo>();
            lp.Add(new ParamInfo(Utilities.user.ToBytes()));
            lp.Add(new ParamInfo(textBox1.Text));
            lp.Add(new ParamInfo(textBox3.Text));

            if (sc.GetObject(new Command(CommandType.ChangeUserPassword, lp) ,ref ar))
            {
                string msg = Encoding.UTF8.GetString(ar);
                if (msg == "DONE")
                {
                    //Users.Login(Utilities.user.UserName,"")
                    MessageBox.Show("تم تغيير كلمة المرور بنجاح..", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                }
                else
                {
                    MessageBox.Show("تعذر تغيير كلمة المرور..", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                }
            }
            else
            {
                MessageBox.Show("تعذر تغيير كلمة المرور..", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
            }


            this.Close();
        }

        private void frmChagePassword_Load(object sender, EventArgs e)
        {

        }
    }
}
