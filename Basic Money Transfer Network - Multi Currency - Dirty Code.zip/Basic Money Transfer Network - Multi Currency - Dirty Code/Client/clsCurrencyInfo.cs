﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace YMT
{
    public class clsCurrencyInfo
    {
        private byte cur_no;
        private string cur_name;
        private string cur_bit_name;
        private decimal cur_exchange;
        private string cur_symbol;

        private Exception exception_info = null;

        public byte CurrencyNumber
        {
            get
            {
                return this.cur_no;
            }
        }

        public decimal CurrencyExchange
        {
            get
            {
                return Math.Round( this.cur_exchange,4);
            }
            set
            {
                this.cur_exchange = Math.Round(value, 4); ;
            }
        }

        public string CurrencySymbol
        {
            get
            {
                return this.cur_symbol;
            }
            set
            {
                this.cur_symbol = value;
            }
        }

        public string CurrencyName
        {
            get
            {
                return this.cur_name;
            }
            set
            {
                this.cur_name = value;
            }
        }

        public string CurrencyBitName
        {
            get
            {
                return this.cur_bit_name;
            }
            set
            {
                this.cur_bit_name = value;
            }
        }

        public Exception ExceptionInfo
        {
            get { return this.exception_info; }
            set
            {
                this.exception_info = value;
            }

        }

        public clsCurrencyInfo()
        {
        }

        public clsCurrencyInfo(byte cur_no, string cur_name, string cur_bit_name, decimal cur_exchange, string cur_symbol)
        {
            this.cur_no = cur_no;
            this.cur_name = cur_name;
            this.cur_symbol = cur_symbol;
            this.cur_exchange = cur_exchange;
            this.cur_bit_name = cur_bit_name;
        }

        public clsCurrencyInfo(byte[] ar)
        {
            try
            {
                int index = 0;
                byte[] art = new byte[1];
                Array.Copy(ar, 0, art, 0, 1);
                this.cur_no = art[0];
                index += 1;
                int l = BitConverter.ToInt32(ar, 1);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.cur_name = Encoding.UTF8.GetString(art);


                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.cur_symbol = Encoding.UTF8.GetString(art);

                this.cur_exchange = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.cur_bit_name = Encoding.UTF8.GetString(art);

                l = BitConverter.ToInt32(ar, index);
                index += 4;

                if (l == 0)
                {
                    this.exception_info = null;
                }
                else
                {
                    art = new byte[l];
                    Array.Copy(ar, index, art, 0, l);
                    index += l;
                    this.exception_info = DeserializeX(art);
                }
            }
            catch(Exception ex)
            {
                this.cur_no = 0;
                this.cur_name = "";
                this.cur_exchange = 0;
                this.cur_bit_name = "";
                this.cur_symbol = "";
                this.exception_info = new Exception("");
            }

        }

        public bool Fill(byte[] ar)
        {
            bool res = false;
            try
            {
                int index = 0;
                byte[] art = new byte[1];
                Array.Copy(ar, 0, art, 0, 1);
                this.cur_no = art[0];
                index += 1;

                int l = BitConverter.ToInt32(ar, 1);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.cur_name = Encoding.UTF8.GetString(art);


                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.cur_symbol = Encoding.UTF8.GetString(art);

                this.cur_exchange = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.cur_bit_name = Encoding.UTF8.GetString(art);

                l = BitConverter.ToInt32(ar, index);
                index += 4;

                if (l == 0)
                {
                    this.exception_info = null;
                }
                else
                {
                    art = new byte[l];
                    Array.Copy(ar, index, art, 0, l);
                    index += l;
                    this.exception_info = DeserializeX(art);
                }

                res = true;
            }
            catch (Exception ex)
            {
                this.cur_no = 0;
                this.cur_name = "";
                this.cur_exchange = 0;
                this.cur_bit_name = "";
                this.cur_symbol = "";
                this.exception_info = new Exception("");
            }

            return res;

        }


        public byte[] ToBytes()
        {
            
            List<byte> ar = new List<byte>();

            ar.Add(this.cur_no);

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.cur_name).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.cur_name));

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.cur_symbol).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.cur_symbol));

            ar.AddRange(BitConverter.GetBytes((double)(this.cur_exchange)));

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.cur_bit_name).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.cur_bit_name));

            if(this.exception_info == null)
            {
                int x = 0;
                ar.AddRange(BitConverter.GetBytes(x));
            }
            else
            {
                byte[] e = SerializeX(this.exception_info);
                ar.AddRange(BitConverter.GetBytes(e.Length));
                ar.AddRange(e);
            }
            return ar.ToArray();
        }

        private Exception DeserializeX(byte[] ar)
        {

            Stream stream = new MemoryStream(ar);
            BinaryFormatter formatter = new BinaryFormatter();
            Exception ex = (Exception)formatter.Deserialize(stream);
            stream.Close();

            return ex;

        }

        private static byte[] SerializeX<T>(T obj)
        {
            using (MemoryStream memStream = new MemoryStream())
            {
                BinaryFormatter binSerializer = new BinaryFormatter();
                binSerializer.Serialize(memStream, obj);
                return memStream.ToArray();
            }
        }
        public clsCurrencyInfo(byte cur_no)
        {
            try
            {
                SocketCommender sc = new SocketCommender();
                byte[] ar = new byte[0];

                List<ParamInfo> lp = new List<ParamInfo>();
                lp.Add(new ParamInfo(Utilities.user.ToBytes()));
                lp.Add(new ParamInfo(BitConverter.GetBytes(cur_no)));
             

                if (sc.GetObject(new Command(CommandType.CurrencyInfo, lp), ref ar))
                {
                    Fill(ar);

                    if (this.exception_info != null)
                    {
                        throw this.exception_info;
                    }
                }
                else
                {
                    this.exception_info = new Exception("");
                }
            }

            catch (Exception ex)
            {
                this.exception_info = ex;
            }

        }

    }

    static class CurrencyManager
    {
        private static clsCurrencyInfo defualt_currency = new clsCurrencyInfo(1);
        public static clsCurrencyInfo DefualtCurrency
        {
            get
            {
               return defualt_currency;
            }
        }
       
        public static List<clsCurrencyInfo> GetALLCurrency()
        {
            List<clsCurrencyInfo> currencies = new List<clsCurrencyInfo>();

            try
            {
                SocketCommender sc = new SocketCommender();
                byte[] ar = new byte[0];

                if (sc.GetObject(new Command(CommandType.GetCurrencyALLInfo), ref ar))
                {
                    byte[] art = new byte[0];

                    int index = 0;
                    int count = BitConverter.ToInt32(ar, index);
                    index += 4;

                    for(int i=0;i<count;i++)
                    {
                        int size = BitConverter.ToInt32(ar, index);
                        index += 4;

                        art = new byte[size];
                        Array.Copy(ar, index, art, 0, size);
                        index += size;

                        clsCurrencyInfo currency = new clsCurrencyInfo(art);

                        if (currency.ExceptionInfo == null)
                        {
                            currencies.Add(currency);
                        }

                    }

                }
            }

            catch (Exception ex)
            {
                
            }

            return currencies;
        }
    }

}
