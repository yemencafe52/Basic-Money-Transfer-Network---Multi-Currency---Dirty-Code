﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography;

namespace YMT
{
    public enum MoneyTransferType
    {
        IN = 0,
        OUT = 1
    }

    public class TransferIncomingManager
    {
        public static bool CreateNewIncomingTransction(TransferIncoming ti)
        {
            bool res = false;

            try
            {
                try
                {
                    SocketCommender sc = new SocketCommender();
                    byte[] ar = new byte[0];

                    List<ParamInfo> lp = new List<ParamInfo>();
                    lp.Add(new ParamInfo(Utilities.user.ToBytes()));
                    lp.Add(new ParamInfo(ti.ToBytes()));

                    if (sc.GetObject(new Command(CommandType.UpdateMoneyTransction, lp), ref ar))
                    {
                       res = BitConverter.ToBoolean(ar,0);
                       
                    }
                    else
                    {
                   
                    }
                }

                catch (Exception ex)
                {
                    
                }

            }
            catch (Exception ex)
            {
                ti.ExceptionInfo = ex;
            }

            return res;
        }

    }

    public class TransferIncoming
    {
        private int ti_no;
        private TransferOutGoing to_no;
        private User user;
        private DateTime ti_date;
        private clsBranchInfo branch_no;
        private string hash = "";
        private Exception exception_info;

        public TransferIncoming(int ti_no, TransferOutGoing to_no, User user, DateTime ti_date, clsBranchInfo branch, string hash = null)
        {
            this.ti_no = ti_no;
            this.to_no = to_no;
            this.user = user;
            this.ti_date = ti_date;
            this.branch_no = branch;

            if (hash != null)
            {
                this.hash = hash;
            }
        }


        public TransferIncoming(int number)
        {
            try
            {
                SocketCommender sc = new SocketCommender();
                byte[] ar = new byte[0];

                List<ParamInfo> lp = new List<ParamInfo>();
                lp.Add(new ParamInfo(Utilities.user.ToBytes()));
                lp.Add(new ParamInfo(BitConverter.GetBytes(number)));

                if (sc.GetObject(new Command(CommandType.IncomingTransction, lp), ref ar))
                {
                    
                    Fill(ar);

                }
                else
                {
                    this.exception_info = new Exception("   ");
                }
            }

            catch (Exception ex)
            {
                this.exception_info = ex;
            }


        }

        public int TransferIncomingNumber
        {
            get
            {
                return this.ti_no;
            }
            set
            {
                this.ti_no = value;
            }
        }

        public TransferOutGoing TransferOutGoingInfo
        {
            get
            {
                return this.to_no;
            }
            set
            {
                this.to_no = value;
            }
        }

        public DateTime Date
        {
            get
            {
                return this.ti_date;
            }
            set
            {
                this.ti_date = value;
            }
        }

        public Exception ExceptionInfo
        {
            get
            {
                return this.exception_info;
            }
            set
            {
                this.exception_info = value;
            }
        }

        public User UserInfo
        {
            get
            {
                return this.user;
            }
            set
            {
                this.user = value;
            }
        }

        public clsBranchInfo Branch
        {
            get
            {
                return this.branch_no;
            }
            set
            {
                this.branch_no = value;
            }
        }

        private string GetMD5Hash(byte[] ar)
        {

            using (MD5 md5Hash = MD5.Create())
            {
                // Convert the input string to a byte array and compute the hash. 
                byte[] data = md5Hash.ComputeHash(ar);

                StringBuilder sBuilder = new StringBuilder();

                // Loop through each byte of the hashed data  
                // and format each one as a hexadecimal string. 
                for (int i = 0; i < data.Length; i++)
                {
                    sBuilder.Append(data[i].ToString("x2"));
                }

                // Return the hexadecimal string. 
                return sBuilder.ToString();

            }
        }

        public string GetCurrentHASH
        {
            get
            {
                return this.GetMD5Hash(this.ToBytes());
            }
        }

        public string GetHash
        {
            get
            {
                return this.hash;
            }
        }




        public TransferIncoming(byte[] ar)
        {
            try
            {
                int index = 0;
                int l = 1;
                byte[] art = new byte[1];

                this.ti_no = BitConverter.ToInt32(ar, index);
                index += 4;

                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.to_no = new TransferOutGoing(art);

                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.user = new User(art);

                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.branch_no = new clsBranchInfo(art);


                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.hash = Encoding.UTF8.GetString(art);


                this.ti_date = DateTime.FromOADate(BitConverter.ToDouble(ar, index));
                index += 8;

                l = BitConverter.ToInt32(ar, index);
                index += 4;

                if (l == 0)
                {
                    this.exception_info = null;
                }
                else
                {
                    art = new byte[l];
                    Array.Copy(ar, index, art, 0, l);
                    index += l;
                    this.exception_info = DeserializeX(art);
                }
            }
            catch (Exception ex)
            {
                this.exception_info = new Exception("");
            }

        }


        public bool Fill(byte[] ar)
        {

            bool res = false;
                
            try
            {
                int index = 0;
                int l = 1;
                byte[] art = new byte[1];

                this.ti_no = BitConverter.ToInt32(ar, index);
                index += 4;

                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.to_no = new TransferOutGoing(art);

                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.user = new User(art);

                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.branch_no = new clsBranchInfo(art);


                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.hash = Encoding.UTF8.GetString(art);


                this.ti_date = DateTime.FromOADate(BitConverter.ToDouble(ar, index));
                index += 8;

                l = BitConverter.ToInt32(ar, index);
                index += 4;

                if (l == 0)
                {
                    this.exception_info = null;
                }
                else
                {
                    art = new byte[l];
                    Array.Copy(ar, index, art, 0, l);
                    index += l;
                    this.exception_info = DeserializeX(art);
                }

                res = true;
            }
            catch (Exception ex)
            {
                this.exception_info = new Exception("");
            }



            return res;
        }


        public byte[] ToBytes()
        {
            List<byte> ar = new List<byte>();

            ar.AddRange(BitConverter.GetBytes(this.ti_no));

            ar.AddRange(BitConverter.GetBytes(this.to_no.ToBytes().Count()));
            ar.AddRange(this.to_no.ToBytes());

            ar.AddRange(BitConverter.GetBytes(this.user.ToBytes().Count()));
            ar.AddRange(this.user.ToBytes());

            ar.AddRange(BitConverter.GetBytes(this.branch_no.ToBytes().Count()));
            ar.AddRange(this.branch_no.ToBytes());

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.hash).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.hash));

            ar.AddRange(BitConverter.GetBytes((double)this.ti_date.ToOADate()));

            if (this.exception_info == null)
            {
                int x = 0;
                ar.AddRange(BitConverter.GetBytes(x));
            }
            else
            {
                byte[] e = SerializeX(this.exception_info);
                ar.AddRange(BitConverter.GetBytes(e.Length));
                ar.AddRange(e);
            }
            return ar.ToArray();
        }




        private Exception DeserializeX(byte[] ar)
        {

            Stream stream = new MemoryStream(ar);
            BinaryFormatter formatter = new BinaryFormatter();
            Exception ex = (Exception)formatter.Deserialize(stream);
            stream.Close();

            return ex;

        }


        private static byte[] SerializeX<T>(T obj)
        {
            using (MemoryStream memStream = new MemoryStream())
            {
                BinaryFormatter binSerializer = new BinaryFormatter();
                binSerializer.Serialize(memStream, obj);
                return memStream.ToArray();
            }
        }
    }


    public class TransferOutGoing
    {
        private int to_no;
        private MoneyTransferType type;
        private DateTime to_date;

        private decimal to_amount;
        private decimal to_famount;
        private decimal to_trans_commation;

        private decimal to_reciver_commation;
        private string to_sender_name;
        private string to_reciver_name;
        private User user;

        private clsCurrencyInfo currency;
        private decimal cur_exchange;
        private decimal to_trans_fcommation;
        private decimal to_reciver_fcommation;

        private Exception exception_info = null;
        private int ogt_v1;

        private clsBranchInfo branch = null;
        private string hash = "";

        private clsBranchInfo dest_branch = null;


        public TransferOutGoing(int number)
        {
            try
            {
                SocketCommender sc = new SocketCommender();
                byte[] ar = new byte[0];

                List<ParamInfo> lp = new List<ParamInfo>();
                lp.Add(new ParamInfo(Utilities.user.ToBytes()));
                lp.Add(new ParamInfo(BitConverter.GetBytes(number)));

                if (sc.GetObject(new Command(CommandType.MonyTransferInfo, lp), ref ar))
                {
                    //TransferOutGoing ogt = new TransferOutGoing(ar);
                    Fill(ar);

                }
                else
                {
                    this.exception_info = new Exception("   ");
                }
            }

            catch (Exception ex)
            {
                this.exception_info = ex;
            }

        }

        public TransferOutGoing(byte[] ar)
        {
            try
            {
                int index = 0;
                int l = 1;
                byte[] art = new byte[1];


                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.dest_branch = new clsBranchInfo(art);


                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.hash = Encoding.UTF8.GetString(art);


                this.to_no = BitConverter.ToInt32(ar, index);
                index += 4;

                art = new byte[1];
                Array.Copy(ar, index, art, 0, 1);
                index += 1;

                this.type = (MoneyTransferType)art[0];

                this.to_amount = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                this.to_famount = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                this.to_reciver_commation = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                this.to_reciver_fcommation = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                this.to_trans_commation = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                this.to_trans_fcommation = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                this.ogt_v1 = BitConverter.ToInt32(ar, index);
                index += 4;


                this.cur_exchange = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;


                this.to_date = DateTime.FromOADate(BitConverter.ToDouble(ar, index));
                index += 8;

                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;



                this.user = new User((art));


                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.branch = new clsBranchInfo((art));



                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.currency = new clsCurrencyInfo((art));




                l = BitConverter.ToInt32(ar, index);
                index += 4;


                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.to_sender_name = Encoding.UTF8.GetString(art);


                l = BitConverter.ToInt32(ar, index);
                index += 4;


                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.to_reciver_name = Encoding.UTF8.GetString(art);



                l = BitConverter.ToInt32(ar, index);
                index += 4;

                if (l == 0)
                {
                    this.exception_info = null;
                }
                else
                {
                    art = new byte[l];
                    Array.Copy(ar, index, art, 0, l);
                    index += l;
                    this.exception_info = DeserializeX(art);
                }
            }
            catch (Exception ex)
            {
                this.exception_info = new Exception("");
            }

        }




        public bool Fill(byte[] ar)
        {
            bool res = false;
            try
            {
                int index = 0;
                int l = 1;
                byte[] art = new byte[1];


                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.dest_branch = new clsBranchInfo(art);


                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.hash = Encoding.UTF8.GetString(art);


                this.to_no = BitConverter.ToInt32(ar, index);
                index += 4;

                art = new byte[1];
                Array.Copy(ar, index, art, 0, 1);
                index += 1;

                this.type = (MoneyTransferType)art[0];

                this.to_amount = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                this.to_famount = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                this.to_reciver_commation = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                this.to_reciver_fcommation = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                this.to_trans_commation = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                this.to_trans_fcommation = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;

                this.ogt_v1 = BitConverter.ToInt32(ar, index);
                index += 4;


                this.cur_exchange = (decimal)BitConverter.ToDouble(ar, index);
                index += 8;


                this.to_date = DateTime.FromOADate(BitConverter.ToDouble(ar, index));
                index += 8;

                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;



                this.user = new User((art));


                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.branch = new clsBranchInfo((art));



                l = BitConverter.ToInt32(ar, index);
                index += 4;
                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.currency = new clsCurrencyInfo((art));




                l = BitConverter.ToInt32(ar, index);
                index += 4;


                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.to_sender_name = Encoding.UTF8.GetString(art);


                l = BitConverter.ToInt32(ar, index);
                index += 4;


                art = new byte[l];
                Array.Copy(ar, index, art, 0, l);
                index += l;

                this.to_reciver_name = Encoding.UTF8.GetString(art);



                l = BitConverter.ToInt32(ar, index);
                index += 4;

                if (l == 0)
                {
                    this.exception_info = null;
                }
                else
                {
                    art = new byte[l];
                    Array.Copy(ar, index, art, 0, l);
                    index += l;
                    this.exception_info = DeserializeX(art);
                }

                res = true;
            }
            catch (Exception ex)
            {
                this.exception_info = new Exception("");
            }

            return res;
        }
        public byte[] ToBytes()
        {

            List<byte> ar = new List<byte>();

            int l = this.branch.ToBytes().Count();

            ar.AddRange(BitConverter.GetBytes(l));
            ar.AddRange((this.branch.ToBytes()));


            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.hash).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.hash));

            ar.AddRange(BitConverter.GetBytes(to_no));
            ar.Add(((byte)this.type));

            ar.AddRange(BitConverter.GetBytes((double)to_amount));
            ar.AddRange(BitConverter.GetBytes((double)to_famount));
            ar.AddRange(BitConverter.GetBytes((double)to_reciver_commation));
            ar.AddRange(BitConverter.GetBytes((double)to_reciver_fcommation));
            ar.AddRange(BitConverter.GetBytes((double)to_trans_commation));
            ar.AddRange(BitConverter.GetBytes((double)to_trans_fcommation));

            ar.AddRange(BitConverter.GetBytes(this.ogt_v1));
            ar.AddRange(BitConverter.GetBytes((double)this.cur_exchange));
            ar.AddRange(BitConverter.GetBytes((double)to_date.ToOADate()));
            ar.AddRange(BitConverter.GetBytes(user.ToBytes().Count()));
            ar.AddRange((user.ToBytes()));

            ar.AddRange(BitConverter.GetBytes(this.branch.ToBytes().Count()));
            ar.AddRange((this.branch.ToBytes()));

            ar.AddRange(BitConverter.GetBytes(this.currency.ToBytes().Count()));
            ar.AddRange((this.currency.ToBytes()));

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.to_sender_name).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.to_sender_name));

            ar.AddRange(BitConverter.GetBytes(Encoding.UTF8.GetBytes(this.to_reciver_name).Count()));
            ar.AddRange(Encoding.UTF8.GetBytes(this.to_reciver_name));



            if (this.exception_info == null)
            {
                int x = 0;
                ar.AddRange(BitConverter.GetBytes(x));
            }
            else
            {
                byte[] e = SerializeX(this.exception_info);
                ar.AddRange(BitConverter.GetBytes(e.Length));
                ar.AddRange(e);
            }
            return ar.ToArray();
        }


        private Exception DeserializeX(byte[] ar)
        {

            Stream stream = new MemoryStream(ar);
            BinaryFormatter formatter = new BinaryFormatter();
            Exception ex = (Exception)formatter.Deserialize(stream);
            stream.Close();

            return ex;

        }

        private static byte[] SerializeX<T>(T obj)
        {
            using (MemoryStream memStream = new MemoryStream())
            {
                BinaryFormatter binSerializer = new BinaryFormatter();
                binSerializer.Serialize(memStream, obj);
                return memStream.ToArray();
            }
        }


        public TransferOutGoing(int to_no, MoneyTransferType type, DateTime to_date, decimal to_amount, decimal to_famount, decimal to_trans_commation, decimal to_reciver_commation, string to_sender_name, string to_reciver_name, User user, clsCurrencyInfo currency, decimal cur_exchange, decimal to_trans_fcommation, decimal to_reciver_fcommation, clsBranchInfo branch, clsBranchInfo dest, string hash = null)
        {

            this.to_no = to_no;
            this.type = type;
            this.to_date = to_date;

            this.to_amount = to_amount;
            this.to_famount = to_famount;
            this.to_trans_commation = to_trans_commation;
            this.to_trans_fcommation = to_trans_fcommation;

            this.to_reciver_commation = to_reciver_commation;
            this.to_reciver_fcommation = to_reciver_fcommation;
            this.user = user;
            this.to_sender_name = to_sender_name;
            this.to_reciver_name = to_reciver_name;
            this.currency = currency;
            this.cur_exchange = cur_exchange;

            this.branch = branch;
            this.dest_branch = dest;

            if (hash != null)
            {
                this.hash = hash;
            }


        }

        public int Number
        {
            get
            {
                return this.to_no;
            }
            set
            {
                this.to_no = value;
            }
        }

        public MoneyTransferType Type
        {
            get
            {
                return this.type;
            }
            set
            {
                this.type = value;
            }
        }

        public DateTime Date
        {
            get
            {
                return this.to_date;
            }
            set
            {
                this.to_date = value;
            }
        }

        public decimal Amount
        {
            get
            {
                return this.to_amount;
            }
            set
            {
                this.to_amount = value;
            }
        }

        public decimal FAmount
        {
            get
            {
                return this.to_famount;
            }
            set
            {
                this.to_famount = value;
            }
        }

        public decimal OutGoingTransferCommation
        {
            get
            {
                return this.to_trans_commation;
            }
            set
            {
                this.to_trans_commation = value;
            }
        }

        public decimal OutGoingTransferFCommation
        {
            get
            {
                return this.to_trans_fcommation;
            }
            set
            {
                this.to_trans_fcommation = value;
            }
        }

        public decimal OutGoingTransferReciverCommation
        {
            get
            {
                return this.to_reciver_commation;
            }
            set
            {
                this.to_reciver_commation = value;
            }
        }

        public decimal OutGoingTransferReciverFCommation
        {
            get
            {
                return this.to_reciver_fcommation;
            }
            set
            {
                this.to_reciver_fcommation = value;
            }
        }

        public string SenderName
        {
            get
            {
                return this.to_sender_name;
            }
            set
            {
                this.to_sender_name = value;
            }
        }

        public string ReciverName
        {
            get
            {
                return this.to_reciver_name;
            }
            set
            {
                this.to_reciver_name = value;
            }
        }


        public User UserInfo
        {
            get
            {
                return this.user;
            }
            set
            {
                this.user = value;
            }
        }

        public clsCurrencyInfo Currency
        {
            get
            {
                return this.currency;
            }
            set
            {
                this.currency = value;
            }
        }

        public decimal Exchange
        {
            get
            {
                return this.cur_exchange;
            }
            set
            {
                this.cur_exchange = value;
            }
        }


        public int OV_1
        {
            get
            {
                return this.ogt_v1;
            }
            set
            {
                this.ogt_v1 = value;
            }
        }


        public clsBranchInfo Branch
        {
            get
            {
                return this.branch;
            }
            set
            {
                this.branch = value;
            }
        }


        public clsBranchInfo DestinationBranch
        {
            get
            {
                return this.dest_branch;
            }
            set
            {
                this.dest_branch = value;
            }
        }

        public Exception ExceptionInfo
        {
            get
            {
                return this.exception_info;
            }
            set
            {
                this.exception_info = value;
            }
        }


        /// <summary>
        /// source  : MSDN
        /// </summary>
        /// <param name="ar"></param>
        /// <returns></returns>
        private string GetMD5Hash(byte[] ar)
        {

            using (MD5 md5Hash = MD5.Create())
            {
                // Convert the input string to a byte array and compute the hash. 
                byte[] data = md5Hash.ComputeHash(ar);

                StringBuilder sBuilder = new StringBuilder();

                // Loop through each byte of the hashed data  
                // and format each one as a hexadecimal string. 
                for (int i = 0; i < data.Length; i++)
                {
                    sBuilder.Append(data[i].ToString("x2"));
                }

                // Return the hexadecimal string. 
                return sBuilder.ToString();

            }
        }

        public string GetCurrentHASH
        {
            get
            {
                return this.GetMD5Hash(this.ToBytes());
            }
        }

        public string GetHash
        {
            get
            {
                return this.hash;
            }
        }



    }


    internal static class TransferOutGoingManager
    {
        public static bool CreateNewOutGoingTransction(TransferOutGoing ogt)
        {
            bool res = false;

            try
            {
                SocketCommender sc = new SocketCommender();
                byte[] ar = new byte[0];

                List<ParamInfo> lp = new List<ParamInfo>();

                lp.Add(new ParamInfo(Utilities.user.ToBytes()));
                lp.Add(new ParamInfo(ogt.ToBytes()));

                if (sc.GetObject(new Command(CommandType.AddNewMoneyTransction, lp), ref ar))
                {
                    res = BitConverter.ToBoolean(ar, 0);
                }
                else
                {

                }
            }
            catch
            {

            }

            return res;
        }

        internal static int GenerateNewTransctionID()
        {
            int res = 0;
            try
            {
                SocketCommender sc = new SocketCommender();
                byte[] ar = new byte[0];

                List<ParamInfo> lp = new List<ParamInfo>();
                lp.Add(new ParamInfo(Utilities.user.ToBytes()));

                if (sc.GetObject(new Command(CommandType.NewTransctionID, lp), ref ar))
                {
                    res = BitConverter.ToInt32(ar, 0);
                }
                else
                {
                    
                }
            }

            catch (Exception ex)
            {
               
            }

            return res;

        }
    }

}
