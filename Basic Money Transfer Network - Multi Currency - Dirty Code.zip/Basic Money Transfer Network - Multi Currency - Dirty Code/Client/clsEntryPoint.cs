﻿using System;
using System.Windows.Forms;
using System.Globalization;

namespace YMT
{
    public static class Program
    { 
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {

            Calendar defaultCalendar = CultureInfo.CurrentCulture.Calendar;

            if (!(defaultCalendar is GregorianCalendar))
            {
                MessageBox.Show("يجب ضبط تقويم نظام ويندوز كـ تقويم ميلادي (أنجليزي).", "", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RtlReading);
                return;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);


            frmLogin flogin = new frmLogin();
            flogin.ShowDialog();

            if (flogin.IsLogined)
            {
                Application.Run(new frmMain());
            }
        }
    }
}





















