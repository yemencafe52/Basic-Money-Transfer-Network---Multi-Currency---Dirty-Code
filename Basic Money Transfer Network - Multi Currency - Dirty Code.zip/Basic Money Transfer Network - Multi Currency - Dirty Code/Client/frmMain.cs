﻿using System;
using System.Windows.Forms;
using System.Threading;
namespace YMT
{
    public partial class frmMain : Form
    {
        delegate void DisplayPing();
        Thread th;

        public frmMain()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;

            th = new Thread(Ping);
            th.IsBackground = true;
            th.Start();
        }


        public void Ping()
        {
            while (true)
            {
                int tick = Environment.TickCount;
                SocketCommender sc = new SocketCommender();

                int res = 0;
                byte[] ar = new byte[0];
                if (sc.GetObject(new Command(CommandType.StartPing, new ParamInfo(Utilities.user.ToBytes())), ref ar))
                {
                    res = Environment.TickCount - tick;
                }
                else
                {
                    res = -1;
                }

                //if (this.InvokeRequired)
                //{
                //    DisplayPing dp = new DisplayPing(Ping);
                //    dp.Invoke();
                //    //break;
                //}

                if (res == -1)
                {
                   
                    toolStripStatusLabel1.Text = "OOPS -1 :(";
                    Utilities.is_connected = false;
                }
                else if (res == 0)
                {
                    Utilities.is_connected = true;
                    toolStripStatusLabel1.Text = "1ms<";
                }
                else
                {
                    Utilities.is_connected = true;
                    toolStripStatusLabel1.Text = res.ToString() + "ms";
                }
                Thread.Sleep(5000);
            }
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {

            if (keyData == (Keys.Shift | Keys.Escape))
            {

                this.Close();
                return true;

            }

            return base.ProcessCmdKey(ref msg, keyData);
        }


        protected override void WndProc(ref Message m)
        {

            base.WndProc(ref m);

            if (IsKeyLocked(Keys.CapsLock))
            {
                toolStripStatusLabel3.Text = "CAPS";
            }
            else
            {
                toolStripStatusLabel3.Text = "";
            }

            if (IsKeyLocked(Keys.NumLock))
            {
                toolStripStatusLabel4.Text = "NUM";
            }
            else
            {
                toolStripStatusLabel4.Text = "";
            }

        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAboutBox fa = new frmAboutBox();
            fa.ShowDialog();
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel2.Text = DateTime.Now.ToString();
            toolStripStatusLabel12.Text = Utilities.user.UserName;
        }
        private void TV_DoubleClick(object sender, EventArgs e)
        {
            TreeView tv = sender as TreeView;
            if(tv == null)
            {
                return;
            }

            switch(tv.SelectedNode.Name)
            {
               
                case "Node2":
                    {
                        frmReports fr = new frmReports();
                        fr.Show();
                     
                        break;
                    }

                case "Node8":
                    {
                        if (Utilities.is_connected==false)
                        {
                            MessageBox.Show("الشبكة غير متوفرة.", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                            return;
                        }

                        frmIncomingTransction fit = new frmIncomingTransction();
                        fit.Show();

                        break;
                    }


                case "Node1212":
                    {
                        if (Utilities.is_connected == false)
                        {
                            MessageBox.Show("الشبكة غير متوفرة.", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                            return;
                        }

                        frmChagePassword fcpwd = new frmChagePassword();
                        fcpwd.ShowDialog();

                        break;
                    }

                case "Node7":
                    {

                        if (Utilities.is_connected == false)
                        {
                            MessageBox.Show("الشبكة غير متوفرة.", "", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RightAlign);
                            return;
                        }


                        Form1 f = new Form1();
                       // f.MdiParent = this;
                        f.Show();
                   
                        break;
                    }
            }

        }

        private void TV_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                TV_DoubleClick(sender, new EventArgs());
            }
        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        {
            frmLogin fl = new frmLogin(true);
            fl.ShowDialog();
           
        }

        private void إغلاقToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {

            DialogResult res = MessageBox.Show("هل تُريد إغلاق النظام فعلاً؟" , " ", MessageBoxButtons.YesNo, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2, MessageBoxOptions.RtlReading);
            if (res == DialogResult.Yes)
            {
                e.Cancel = false;

            }
            else
            {
                e.Cancel = true;
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
           
        }
    }
}
