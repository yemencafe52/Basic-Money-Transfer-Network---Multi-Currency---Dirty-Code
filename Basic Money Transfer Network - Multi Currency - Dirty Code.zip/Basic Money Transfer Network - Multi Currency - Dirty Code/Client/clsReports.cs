﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace YMT
{
    internal class OugGoingReports
    {
        private object DeserializeX(byte[] ar)
        {

            Stream stream = new MemoryStream(ar);
            BinaryFormatter formatter = new BinaryFormatter();
            object ex = (object)formatter.Deserialize(stream);
            stream.Close();
            return ex;
        }

        private byte[] SerializeX<T>(T obj)
        {
            using (MemoryStream memStream = new MemoryStream())
            {
                BinaryFormatter binSerializer = new BinaryFormatter();
                binSerializer.Serialize(memStream, obj);
                return memStream.ToArray();
            }
        }

        internal DSet.OGTDataTable GetOutGoingTransction(DateTime from, DateTime to)
        {
            DSet.OGTDataTable ogt = new DSet.OGTDataTable();
            try
            {
                byte[] ar = new byte[0];
                SocketCommender sc = new SocketCommender();

                List<ParamInfo> lp = new List<ParamInfo>();
                lp.Add(new ParamInfo(Utilities.user.ToBytes()));
                lp.Add(new ParamInfo(BitConverter.GetBytes(from.ToOADate())));
                lp.Add(new ParamInfo(BitConverter.GetBytes(to.ToOADate())));
                 

                if (sc.GetObject(new Command(CommandType.GetReport1, lp),ref ar))
                {
                    ogt = (DSet.OGTDataTable)DeserializeX(ar);
                }
            }
            catch
            {
            }

            return ogt;
        }

        internal DSet.OGTDataTable GetOutGoingTransction(DateTime from, DateTime to, User user)
        {
            DSet.OGTDataTable ogt = new DSet.OGTDataTable();
            try
            {
                byte[] ar = new byte[0];
                SocketCommender sc = new SocketCommender();

                List<ParamInfo> lp = new List<ParamInfo>();
                lp.Add(new ParamInfo(Utilities.user.ToBytes()));
                lp.Add(new ParamInfo(BitConverter.GetBytes(from.ToOADate())));
                lp.Add(new ParamInfo(BitConverter.GetBytes(to.ToOADate())));
                //lp.Add(new ParamInfo(user.ToBytes()));
                lp.Add(new ParamInfo(Utilities.user.ToBytes()));


                if (sc.GetObject(new Command(CommandType.GetReport2, lp), ref ar))
                {
                    ogt = (DSet.OGTDataTable)DeserializeX(ar);
                }
            }
            catch
            {

            }

            return ogt;
        }

        internal DSet.OGTDataTable GetOutGoingTransction(DateTime from, DateTime to, clsBranchInfo branch, bool x)
        {
            DSet.OGTDataTable ogt = new DSet.OGTDataTable();
            try
            {
                byte[] ar = new byte[0];
                SocketCommender sc = new SocketCommender();

                List<ParamInfo> lp = new List<ParamInfo>();
                lp.Add(new ParamInfo(Utilities.user.ToBytes()));
                lp.Add(new ParamInfo(BitConverter.GetBytes(from.ToOADate())));
                lp.Add(new ParamInfo(BitConverter.GetBytes(to.ToOADate())));
                lp.Add(new ParamInfo(branch.ToBytes()));
                lp.Add(new ParamInfo(BitConverter.GetBytes(x)));

                if (sc.GetObject(new Command(CommandType.GetReport3, lp), ref ar))
                {
                    ogt = (DSet.OGTDataTable)DeserializeX(ar);
                }
            }
            catch
            { 
            }

            return ogt;
        }

        internal DSet.OGTDataTable GetOutGoingTransction(DateTime from, DateTime to, clsBranchInfo branch, User user, bool x)
        {
            DSet.OGTDataTable ogt = new DSet.OGTDataTable();
            try
            {
                byte[] ar = new byte[0];
                SocketCommender sc = new SocketCommender();

                List<ParamInfo> lp = new List<ParamInfo>();
                lp.Add(new ParamInfo(Utilities.user.ToBytes()));
                lp.Add(new ParamInfo(BitConverter.GetBytes(from.ToOADate())));
                lp.Add(new ParamInfo(BitConverter.GetBytes(to.ToOADate())));
                lp.Add(new ParamInfo(branch.ToBytes()));
                lp.Add(new ParamInfo(Utilities.user.ToBytes()));
                //lp.Add(new ParamInfo(user.ToBytes()));
                lp.Add(new ParamInfo(BitConverter.GetBytes(x)));
                

                if (sc.GetObject(new Command(CommandType.GetReport4, lp), ref ar))
                {
                    ogt = (DSet.OGTDataTable)DeserializeX(ar);
                }
                
            }
            catch
            {

            }

            return ogt;
        }


        internal DSet.OGTDataTable GetOutGoingTransction(DateTime from, DateTime to, clsBranchInfo src, clsBranchInfo dst)
        {
            DSet.OGTDataTable ogt = new DSet.OGTDataTable();
            try
            {
                byte[] ar = new byte[0];
                SocketCommender sc = new SocketCommender();

                List<ParamInfo> lp = new List<ParamInfo>();
                lp.Add(new ParamInfo(Utilities.user.ToBytes()));
                lp.Add(new ParamInfo(BitConverter.GetBytes(from.ToOADate())));
                lp.Add(new ParamInfo(BitConverter.GetBytes(to.ToOADate())));
                lp.Add(new ParamInfo(src.ToBytes()));
                lp.Add(new ParamInfo(dst.ToBytes()));
                

                if (sc.GetObject(new Command(CommandType.GetReport5, lp), ref ar))
                {
                    ogt = (DSet.OGTDataTable)DeserializeX(ar);
                }
                
            }
            catch
            {

            }

            return ogt;
        }

        internal DSet.OGTDataTable GetOutGoingTransction(DateTime from, DateTime to, clsBranchInfo src, clsBranchInfo dst, User user)
        {
            DSet.OGTDataTable ogt = new DSet.OGTDataTable();
            try
            {
                byte[] ar = new byte[0];
                SocketCommender sc = new SocketCommender();

                List<ParamInfo> lp = new List<ParamInfo>();
                lp.Add(new ParamInfo(Utilities.user.ToBytes()));
                lp.Add(new ParamInfo(BitConverter.GetBytes(from.ToOADate())));
                lp.Add(new ParamInfo(BitConverter.GetBytes(to.ToOADate())));
                lp.Add(new ParamInfo(src.ToBytes()));
                lp.Add(new ParamInfo(dst.ToBytes()));
                //lp.Add(new ParamInfo(user.ToBytes()));
                lp.Add(new ParamInfo(Utilities.user.ToBytes()));

                if (sc.GetObject(new Command(CommandType.GetReport6, lp), ref ar))
                {
                    ogt = (DSet.OGTDataTable)DeserializeX(ar);
                }
                
                
            }
            catch
            {

            }

            return ogt;
        }
    }

    internal class InComingReports
    {
        private object DeserializeX(byte[] ar)
        {

            Stream stream = new MemoryStream(ar);
            BinaryFormatter formatter = new BinaryFormatter();
            object ex = (object)formatter.Deserialize(stream);
            stream.Close();
            return ex;
        }

        private byte[] SerializeX<T>(T obj)
        {
            using (MemoryStream memStream = new MemoryStream())
            {
                BinaryFormatter binSerializer = new BinaryFormatter();
                binSerializer.Serialize(memStream, obj);
                return memStream.ToArray();
            }
        }


        internal DSet.ICTDataTable GetInComingTransction(DateTime from, DateTime to)
        {

            DSet.ICTDataTable ict = new DSet.ICTDataTable();
            try
            {
                byte[] ar = new byte[0];
                SocketCommender sc = new SocketCommender();

                List<ParamInfo> lp = new List<ParamInfo>();
                lp.Add(new ParamInfo(Utilities.user.ToBytes()));
                lp.Add(new ParamInfo(BitConverter.GetBytes(from.ToOADate())));
                lp.Add(new ParamInfo(BitConverter.GetBytes(to.ToOADate())));


                if (sc.GetObject(new Command(CommandType.GetReport7, lp), ref ar))
                {
                    ict = (DSet.ICTDataTable)DeserializeX(ar);
                }


            }
            catch
            {

            }

            return ict;
        }

        internal DSet.ICTDataTable GetInComingTransction(DateTime from, DateTime to, User user)
        {
            DSet.ICTDataTable ict = new DSet.ICTDataTable();
            try
            {
                byte[] ar = new byte[0];
                SocketCommender sc = new SocketCommender();

                List<ParamInfo> lp = new List<ParamInfo>();
                lp.Add(new ParamInfo(Utilities.user.ToBytes()));
                lp.Add(new ParamInfo(BitConverter.GetBytes(from.ToOADate())));
                lp.Add(new ParamInfo(BitConverter.GetBytes(to.ToOADate())));
                //lp.Add(new ParamInfo(user.ToBytes()));
                lp.Add(new ParamInfo(Utilities.user.ToBytes()));


                if (sc.GetObject(new Command(CommandType.GetReport8, lp), ref ar))
                {
                    ict = (DSet.ICTDataTable)DeserializeX(ar);
                }
            }
            catch
            {

            }

            return ict;
        }

        internal DSet.ICTDataTable GetInComingTransction(DateTime from, DateTime to, clsBranchInfo branch, bool x)
        {
            DSet.ICTDataTable ict = new DSet.ICTDataTable();
            try
            {
                byte[] ar = new byte[0];
                SocketCommender sc = new SocketCommender();

                List<ParamInfo> lp = new List<ParamInfo>();
                lp.Add(new ParamInfo(Utilities.user.ToBytes()));
                lp.Add(new ParamInfo(BitConverter.GetBytes(from.ToOADate())));
                lp.Add(new ParamInfo(BitConverter.GetBytes(to.ToOADate())));
                lp.Add(new ParamInfo(branch.ToBytes()));
                lp.Add(new ParamInfo(BitConverter.GetBytes(x)));

                if (sc.GetObject(new Command(CommandType.GetReport9, lp), ref ar))
                {
                    ict = (DSet.ICTDataTable)DeserializeX(ar);
                }
            }
            catch
            {

            }

            return ict;
        }

        internal DSet.ICTDataTable GetInComingTransction(DateTime from, DateTime to, clsBranchInfo branch, User user, bool x)
        {
            DSet.ICTDataTable ict = new DSet.ICTDataTable();
            try
            {
                byte[] ar = new byte[0];
                SocketCommender sc = new SocketCommender();

                List<ParamInfo> lp = new List<ParamInfo>();
                lp.Add(new ParamInfo(Utilities.user.ToBytes()));
                lp.Add(new ParamInfo(BitConverter.GetBytes(from.ToOADate())));
                lp.Add(new ParamInfo(BitConverter.GetBytes(to.ToOADate())));
                lp.Add(new ParamInfo(branch.ToBytes()));
                lp.Add(new ParamInfo(Utilities.user.ToBytes()));
                //lp.Add(new ParamInfo(user.ToBytes()));
                lp.Add(new ParamInfo(BitConverter.GetBytes(x)));


                if (sc.GetObject(new Command(CommandType.GetReport10, lp), ref ar))
                {
                    ict = (DSet.ICTDataTable)DeserializeX(ar);
                }

            }
            catch
            {

            }

            return ict;
        }

        internal DSet.ICTDataTable GetInComingTransction(DateTime from, DateTime to, clsBranchInfo src, clsBranchInfo dst)
        {
            DSet.ICTDataTable ict = new DSet.ICTDataTable();
            try
            {
                byte[] ar = new byte[0];
                SocketCommender sc = new SocketCommender();

                List<ParamInfo> lp = new List<ParamInfo>();
                lp.Add(new ParamInfo(Utilities.user.ToBytes()));
                lp.Add(new ParamInfo(BitConverter.GetBytes(from.ToOADate())));
                lp.Add(new ParamInfo(BitConverter.GetBytes(to.ToOADate())));
                lp.Add(new ParamInfo(src.ToBytes()));
                lp.Add(new ParamInfo(dst.ToBytes()));

                if (sc.GetObject(new Command(CommandType.GetReport11, lp), ref ar))
                {
                    ict = (DSet.ICTDataTable)DeserializeX(ar);
                }
            }
            catch
            {

            }

            return ict;
        }

        internal DSet.ICTDataTable GetInComingTransction(DateTime from, DateTime to, clsBranchInfo src, clsBranchInfo dst, User user)
        {
            DSet.ICTDataTable ict = new DSet.ICTDataTable();
            try
            {
                byte[] ar = new byte[0];
                SocketCommender sc = new SocketCommender();

                List<ParamInfo> lp = new List<ParamInfo>();
                lp.Add(new ParamInfo(Utilities.user.ToBytes()));
                lp.Add(new ParamInfo(BitConverter.GetBytes(from.ToOADate())));
                lp.Add(new ParamInfo(BitConverter.GetBytes(to.ToOADate())));
                lp.Add(new ParamInfo(src.ToBytes()));
                lp.Add(new ParamInfo(dst.ToBytes()));
                //lp.Add(new ParamInfo(user.ToBytes()));
                lp.Add(new ParamInfo(Utilities.user.ToBytes()));

                if (sc.GetObject(new Command(CommandType.GetReport12, lp), ref ar))
                {
                    ict = (DSet.ICTDataTable)DeserializeX(ar);
                }


            }
            catch
            {

            }

            return ict;
        }

   }


}

