﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace YMT
{
    public partial class frmReports : Form
    {
        public frmReports()
        {
            InitializeComponent();
        }

        private object DeserializeX(byte[] ar)
        {

            Stream stream = new MemoryStream(ar);
            BinaryFormatter formatter = new BinaryFormatter();
            object ex = (object)formatter.Deserialize(stream);
            stream.Close();

            return ex;

        }

        private static byte[] SerializeX<T>(T obj)
        {
            using (MemoryStream memStream = new MemoryStream())
            {
                BinaryFormatter binSerializer = new BinaryFormatter();
                binSerializer.Serialize(memStream, obj);
                return memStream.ToArray();
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {


            try
            {
                frmReportViewer frmRV = new frmReportViewer();
                DSet ds = new DSet();

                SocketCommender sc = new SocketCommender();
                byte[] ar = new byte[0];

                List<ParamInfo> lp = new List<ParamInfo>();
                lp.Add(new ParamInfo(Utilities.user.ToBytes()));
                //lp.Add(new ParamInfo(BitConverter.GetBytes(com_id)));

                if (sc.GetObject(new Command(CommandType.GetReport1, lp), ref ar))
                {
                    DataTable tbl = DeserializeX(ar) as DataTable;

                    //if (ds.Tables["OGT"].Rows.Count == 0)
                    //{
                    //    MessageBox.Show("لا توجد نتائج لعرضها.", "واي", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information, System.Windows.Forms.MessageBoxDefaultButton.Button1, System.Windows.Forms.MessageBoxOptions.RtlReading);
                    //    return;
                    //}

                    Microsoft.Reporting.WinForms.ReportDataSource rpt = new Microsoft.Reporting.WinForms.ReportDataSource("OGT", tbl);

                    frmRV.reportViewer1.LocalReport.DataSources.Clear();

                    frmRV.reportViewer1.LocalReport.ReportEmbeddedResource = "YMT.rptTotalOGTReport.rdlc";
                    frmRV.reportViewer1.LocalReport.DataSources.Add(rpt);
                    frmRV.reportViewer1.RefreshReport();
                    frmRV.Show();
                }

            }

            catch
            {
            }
        }


        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {

            if (keyData == (Keys.Shift | Keys.Escape))
            {

                {
                    this.Close();
                }
                return true;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void frmReports_Load(object sender, EventArgs e)
        {


            dateTimePicker5.Format = DateTimePickerFormat.Custom;
            dateTimePicker5.CustomFormat = "yyyy/MM/dd";

            dateTimePicker6.Format = DateTimePickerFormat.Custom;
            dateTimePicker6.CustomFormat = "yyyy/MM/dd";

            dateTimePicker6.Enabled = false;
            dateTimePicker5.Enabled = false;

            dateTimePicker6.Value = new DateTime(DateTime.Now.Year, 1, 1);
            dateTimePicker5.Value = new DateTime(DateTime.Now.Year, 12, 31);//DateTime.Parse(DateTime.Now.ToString("yyyy/MM/dd"));

            comboBox3.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox3.Items.Add("تحليلي");
            comboBox3.Items.Add("تفصيلي");
            comboBox3.SelectedIndex = 0;

            List<clsBranchInfo> branchies = BranchInfoManager.GetALLBranchInfo();

            comboBox4.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox4.Items.Add("الكل");

            foreach (clsBranchInfo b in branchies)
            {
                comboBox4.Items.Add(b.BranchNumber);
            }

            if (comboBox4.Items.Count > 0)
            {
                comboBox4.SelectedIndex = 0;
            }

            comboBox5.DropDownStyle = ComboBoxStyle.DropDownList;

            comboBox5.Items.Add("الكل");

            foreach (clsBranchInfo b in branchies)
            {
                comboBox5.Items.Add(b.BranchNumber);
            }

            if (comboBox5.Items.Count > 0)
            {
                comboBox5.SelectedIndex = 0;
            }


            List<User> users = new List<User>();
            users.Add(Utilities.user);

            comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;

            foreach (User u in users)
            {
                comboBox2.Items.Add(u.Number);
            }

            if (comboBox2.Items.Count > 0)
            {
                comboBox2.SelectedIndex = 0;
            }


            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.Items.Add("صادر");
            comboBox1.Items.Add("وارد");
            comboBox1.SelectedIndex = 0;
        }

        private void Print()
        {
            frmReportViewer frmRV = new frmReportViewer();

            DataTable dt = new DataTable();

            try
            {
                if (comboBox1.SelectedIndex == 0)
                {
                    OugGoingReports r = new OugGoingReports();

                    if (comboBox4.SelectedIndex == 0)
                    {
                        if (comboBox5.SelectedIndex == 0)
                        {
                            if (comboBox2.SelectedIndex == 0)
                            {
                                dt = r.GetOutGoingTransction(dateTimePicker6.Value, dateTimePicker5.Value);
                            }
                            else
                            {
                                dt = r.GetOutGoingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new User(byte.Parse(comboBox2.Text)));
                            }
                        }
                        else
                        {
                            if (comboBox2.SelectedIndex == 0)
                            {
                                dt = r.GetOutGoingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new clsBranchInfo(byte.Parse(comboBox5.Text)), false);
                            }
                            else
                            {
                                dt = r.GetOutGoingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new clsBranchInfo(byte.Parse(comboBox5.Text)), new User(byte.Parse(comboBox2.Text)), false);
                            }
                        }
                    }

                    else
                    {
                        if (comboBox5.SelectedIndex == 0)
                        {
                            if (comboBox2.SelectedIndex == 0)
                            {
                                dt = r.GetOutGoingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new clsBranchInfo(byte.Parse(comboBox4.Text)), true);
                            }
                            else
                            {
                                dt = r.GetOutGoingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new clsBranchInfo(byte.Parse(comboBox4.Text)), new User(byte.Parse(comboBox2.Text)), true);
                            }
                        }
                        else
                        {
                            if (comboBox2.SelectedIndex == 0)
                            {
                                dt = r.GetOutGoingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new clsBranchInfo(byte.Parse(comboBox4.Text)), new clsBranchInfo(byte.Parse(comboBox5.Text)));
                            }
                            else
                            {
                                dt = r.GetOutGoingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new clsBranchInfo(byte.Parse(comboBox4.Text)), new clsBranchInfo(byte.Parse(comboBox5.Text)), new User(byte.Parse(comboBox2.Text)));
                            }
                        }
                    }

                    if (dt.Rows.Count == 0)
                    {
                        MessageBox.Show("لا توجد نتائج لعرضها.", "", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information, System.Windows.Forms.MessageBoxDefaultButton.Button1, System.Windows.Forms.MessageBoxOptions.RtlReading);
                        return;
                    }


                    Microsoft.Reporting.WinForms.ReportDataSource rpt = new Microsoft.Reporting.WinForms.ReportDataSource("OGT", dt);

                    frmRV.reportViewer1.LocalReport.DataSources.Clear();

                    if (comboBox3.SelectedIndex == 0)
                    {
                        frmRV.reportViewer1.LocalReport.ReportEmbeddedResource = "YMT.rptOGTDetials.rdlc";
                    }
                    else
                    {
                        frmRV.reportViewer1.LocalReport.ReportEmbeddedResource = "YMT.rptTotalOGTReport.rdlc";
                    }

                    frmRV.reportViewer1.LocalReport.DataSources.Add(rpt);
                    frmRV.reportViewer1.RefreshReport();
                    frmRV.Show();
                }
                else
                {
                    InComingReports r = new InComingReports();

                    if (comboBox4.SelectedIndex == 0)
                    {
                        if (comboBox5.SelectedIndex == 0)
                        {
                            if (comboBox2.SelectedIndex == 0)
                            {
                                dt = r.GetInComingTransction(dateTimePicker6.Value, dateTimePicker5.Value);
                            }
                            else
                            {
                                dt = r.GetInComingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new User(byte.Parse(comboBox2.Text)));
                            }
                        }
                        else
                        {
                            if (comboBox2.SelectedIndex == 0)
                            {
                                dt = r.GetInComingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new clsBranchInfo(byte.Parse(comboBox5.Text)), false);
                            }
                            else
                            {
                                dt = r.GetInComingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new clsBranchInfo(byte.Parse(comboBox5.Text)), new User(byte.Parse(comboBox2.Text)), false);
                            }
                        }
                    }

                    else
                    {
                        if (comboBox5.SelectedIndex == 0)
                        {
                            if (comboBox2.SelectedIndex == 0)
                            {
                                dt = r.GetInComingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new clsBranchInfo(byte.Parse(comboBox4.Text)), true);
                            }
                            else
                            {
                                dt = r.GetInComingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new clsBranchInfo(byte.Parse(comboBox4.Text)), new User(byte.Parse(comboBox2.Text)), true);
                            }
                        }
                        else
                        {
                            if (comboBox2.SelectedIndex == 0)
                            {
                                dt = r.GetInComingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new clsBranchInfo(byte.Parse(comboBox4.Text)), new clsBranchInfo(byte.Parse(comboBox5.Text)));
                            }
                            else
                            {
                                dt = r.GetInComingTransction(dateTimePicker6.Value, dateTimePicker5.Value, new clsBranchInfo(byte.Parse(comboBox4.Text)), new clsBranchInfo(byte.Parse(comboBox5.Text)), new User(byte.Parse(comboBox2.Text)));
                            }
                        }
                    }

                    if (dt.Rows.Count == 0)
                    {
                        MessageBox.Show("لا توجد نتائج لعرضها.", "", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Information, System.Windows.Forms.MessageBoxDefaultButton.Button1, System.Windows.Forms.MessageBoxOptions.RtlReading);
                        return;
                    }


                    Microsoft.Reporting.WinForms.ReportDataSource rpt = new Microsoft.Reporting.WinForms.ReportDataSource("ICT", dt);

                    frmRV.reportViewer1.LocalReport.DataSources.Clear();

                    if (comboBox3.SelectedIndex == 0)
                    {
                        frmRV.reportViewer1.LocalReport.ReportEmbeddedResource = "YMT.rptICTDetials.rdlc";
                    }
                    else
                    {
                        frmRV.reportViewer1.LocalReport.ReportEmbeddedResource = "YMT.rptTotalICTReport.rdlc";
                    }

                    frmRV.reportViewer1.LocalReport.DataSources.Add(rpt);
                    frmRV.reportViewer1.RefreshReport();
                    frmRV.Show();
                }

            }
            catch
            {
                MessageBox.Show("تعذر عرض التقرير..", "", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error, System.Windows.Forms.MessageBoxDefaultButton.Button1, System.Windows.Forms.MessageBoxOptions.RtlReading);
            }

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Print();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                comboBox4.Text = BranchInfoManager.GetBranchInfo.BranchNumber.ToString();
                comboBox5.SelectedIndex = 0;
            }
            else
            {
                comboBox4.SelectedIndex = 0;// BranchInfoManager.GetBranchInfo.BranchNumber.ToString();
                comboBox5.Text = BranchInfoManager.GetBranchInfo.BranchNumber.ToString();
            }
        }
    }
}
